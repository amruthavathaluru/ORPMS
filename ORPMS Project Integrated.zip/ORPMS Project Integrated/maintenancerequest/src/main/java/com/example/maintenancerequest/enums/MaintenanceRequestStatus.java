package com.example.maintenancerequest.enums;

public enum MaintenanceRequestStatus {
    request_submitted,
    request_received,
    assigned_to_service_provider,
    request_closed;
}


