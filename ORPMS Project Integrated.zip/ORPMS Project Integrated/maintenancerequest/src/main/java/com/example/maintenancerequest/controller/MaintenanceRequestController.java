package com.example.maintenancerequest.controller;

import com.example.maintenancerequest.dto.MaintenanceRequestDTO;
import com.example.maintenancerequest.dto.MaintenanceRequestResponseDTO;
import com.example.maintenancerequest.service.MaintenanceRequestService;
import com.example.maintenancerequest.utils.ResultResponse;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/maintenance-requests")
public class MaintenanceRequestController {

    private static final Logger logger = LoggerFactory.getLogger(MaintenanceRequestController.class);

    @Autowired
    private MaintenanceRequestService maintenanceRequestService;

    // Create a new maintenance request
    @PostMapping("/create")
    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> createRequest(@RequestBody @Valid MaintenanceRequestDTO dto) {
        logger.info("Creating a new maintenance request: {}", dto);

        MaintenanceRequestResponseDTO response = maintenanceRequestService.createRequest(dto);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
                        .success(true)
                        .data(response)
                        .timestamp(LocalDateTime.now())
                        .build());
    }

    // Retrieve all maintenance requests
    @GetMapping("/all")
    public ResponseEntity<ResultResponse<List<MaintenanceRequestResponseDTO>>> getAllRequests() {
        logger.info("Fetching all maintenance requests.");

        List<MaintenanceRequestResponseDTO> responses = maintenanceRequestService.getAllRequests();

        return ResponseEntity.ok(ResultResponse.<List<MaintenanceRequestResponseDTO>>builder()
                .success(true)
                .data(responses)
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Retrieve a specific maintenance request by ID
    @GetMapping("/{id}")
    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> getRequestById(@PathVariable String id) {
        logger.info("Fetching maintenance request with ID: {}", id);

        // Delegate to the service
        MaintenanceRequestResponseDTO response = maintenanceRequestService.getRequestById(id);

        return ResponseEntity.ok(ResultResponse.<MaintenanceRequestResponseDTO>builder()
                .success(true)
                .data(response)
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Update an existing maintenance request
    @PutMapping("/update/{id}")
    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> updateRequest(
            @PathVariable String id, @RequestBody @Valid MaintenanceRequestDTO dto) {
        logger.info("Updating maintenance request with ID: {}", id);

        // Delegate to the service
        MaintenanceRequestResponseDTO updatedResponse = maintenanceRequestService.updateRequest(id, dto);

        return ResponseEntity.ok(ResultResponse.<MaintenanceRequestResponseDTO>builder()
                .success(true)
                .data(updatedResponse)
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Delete a specific maintenance request by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<ResultResponse<Void>> deleteRequest(@PathVariable String id) {
        logger.info("Deleting maintenance request with ID: {}", id);

        // Delegate to the service
        maintenanceRequestService.deleteRequest(id);

        return ResponseEntity.ok(ResultResponse.<Void>builder()
                .success(true)
                .timestamp(LocalDateTime.now())
                .build());
    }
}


































//package com.example.maintenancerequest.controller;
//
//import com.example.maintenancerequest.dto.MaintenanceRequestDTO;
//import com.example.maintenancerequest.dto.MaintenanceRequestResponseDTO;
//import com.example.maintenancerequest.exceptions.DuplicateRequestException;
//import com.example.maintenancerequest.exceptions.RequestNotFoundException;
//import com.example.maintenancerequest.service.MaintenanceRequestService;
//import com.example.maintenancerequest.utils.ResultResponse;
//
//import jakarta.validation.Valid;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.time.LocalDateTime;
//import java.util.List;
//import java.util.UUID;
//
//@RestController
//@RequestMapping("/api/maintenance-requests")
//public class MaintenanceRequestController {
//
//    // Manual Logger setup
//    private static final Logger logger = LoggerFactory.getLogger(MaintenanceRequestController.class);
//
//    @Autowired
//    private MaintenanceRequestService maintenanceRequestService;
//
//    //1. Create a new maintenance request
//    @PostMapping("/create")
//    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> createRequest(@RequestBody @Valid MaintenanceRequestDTO dto) {
//        logger.info("Creating maintenance request: {}", dto);
//        try {
//            // Generate a unique requestID
//            dto.setRequestID(UUID.randomUUID().toString());
//
//            // Log the generated requestID
//            logger.info("Generated requestID: {}", dto.getRequestID());
//
//            // Call the service layer to create the request
//            MaintenanceRequestResponseDTO response = maintenanceRequestService.createRequest(dto);
//            
//            // Build and return the response
//            return ResponseEntity.status(HttpStatus.CREATED).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(true)
//                    .data(response)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (DuplicateRequestException e) {
//            logger.error("Duplicate request: {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message(e.getMessage())
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (Exception e) {
//            logger.error("Error creating request: {}", e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Internal server error")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
//
//
//    // Retrieve all maintenance requests
//    @GetMapping("/all")
//    public ResponseEntity<ResultResponse<List<MaintenanceRequestResponseDTO>>> getAllRequests() {
//        logger.info("Getting all maintenance requests");
//        try {
//            List<MaintenanceRequestResponseDTO> responses = maintenanceRequestService.getAllRequests();
//            return ResponseEntity.ok(ResultResponse.<List<MaintenanceRequestResponseDTO>>builder()
//                    .success(true)
//                    .data(responses)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (Exception e) {
//            logger.error("Error getting all requests: {}", e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<MaintenanceRequestResponseDTO>>builder()
//                    .success(false)
//                    .message("Internal server error")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
//
//    // Retrieve a specific maintenance request by ID
//    @GetMapping("/{id}")
//    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> getRequestById(@PathVariable String id) {
//        logger.info("Getting maintenance request for ID: {}", id);
//        try {
//            UUID.fromString(id); // Validate UUID format
//            MaintenanceRequestResponseDTO response = maintenanceRequestService.getRequestById(id);
//            return ResponseEntity.ok(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(true)
//                    .data(response)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.badRequest().body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Invalid UUID format")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (RequestNotFoundException e) {
//            logger.error("Request not found: {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message(e.getMessage())
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (Exception e) {
//            logger.error("Error getting request: {}", e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Internal server error")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
//
//    // Update an existing maintenance request
//    @PutMapping("/update/{id}")
//    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> updateRequest(
//            @PathVariable String id, @RequestBody @Valid MaintenanceRequestDTO dto) {
//        logger.info("Updating maintenance request with ID: {}", id);
//        try {
//            UUID.fromString(id); // Validate UUID format
//            dto.setRequestID(UUID.fromString(id));
//            MaintenanceRequestResponseDTO updatedResponse = maintenanceRequestService.updateRequest(id, dto);
//            return ResponseEntity.ok(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(true)
//                    .data(updatedResponse)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.badRequest().body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Invalid UUID format")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (RequestNotFoundException e) {
//            logger.error("Request not found: {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message(e.getMessage())
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (Exception e) {
//            logger.error("Error updating request: {}", e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Internal server error")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
//
//    // Delete a specific maintenance request by ID
//    @DeleteMapping("/delete/{id}")
//    public ResponseEntity<ResultResponse<Void>> deleteRequest(@PathVariable String id) {
//        logger.info("Deleting maintenance request with ID: {}", id);
//        try {
//            UUID.fromString(id); // Validate UUID format
//            boolean deleted = maintenanceRequestService.deleteRequest(id);
//            if (deleted) {
//                return ResponseEntity.ok(ResultResponse.<Void>builder()
//                        .success(true)
//                        .timestamp(LocalDateTime.now())
//                        .build());
//            } else {
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
//                        .success(false)
//                        .message("Request not found")
//                        .timestamp(LocalDateTime.now())
//                        .build());
//            }
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.badRequest().body(ResultResponse.<Void>builder()
//                    .success(false)
//                    .message("Invalid UUID format")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (RequestNotFoundException e) {
//            logger.error("Request not found: {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
//                    .success(false)
//                    .message(e.getMessage())
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
//}































//package com.example.maintenancerequest.controller;
//
//import com.example.maintenancerequest.dto.MaintenanceRequestDTO;
//import com.example.maintenancerequest.dto.MaintenanceRequestResponseDTO;
//import com.example.maintenancerequest.exceptions.DuplicateRequestException;
//import com.example.maintenancerequest.exceptions.RequestNotFoundException;
//import com.example.maintenancerequest.service.MaintenanceRequestService;
//import com.example.maintenancerequest.utils.ResultResponse;
////import com.example.maintenancerequest.exception.RequestNotFoundException;
////import com.example.maintenancerequest.exception.DuplicateRequestException;
//
//import jakarta.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import lombok.extern.slf4j.Slf4j;
//
//import java.time.LocalDateTime;
//import java.util.List;
//import java.util.UUID;
//
//@Slf4j
//@RestController
//@RequestMapping("/api/maintenance-requests")
//public class MaintenanceRequestController {
//
//    @Autowired
//    private MaintenanceRequestService maintenanceRequestService;
//
//    // Create a new maintenance request
//    @PostMapping("/create")
//    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> createRequest(@RequestBody @Valid MaintenanceRequestDTO dto) {
//        log.info("Creating maintenance request: {}", dto);
//        try {
//            MaintenanceRequestResponseDTO response = maintenanceRequestService.createRequest(dto);
//            return ResponseEntity.status(HttpStatus.CREATED).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(true)
//                    .data(response)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (DuplicateRequestException e) {
//            log.error("Duplicate request: {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message(e.getMessage())
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (Exception e) {
//            log.error("Error creating request: {}", e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Internal server error")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
//
//    // Retrieve all maintenance requests
//    @GetMapping("/all")
//    public ResponseEntity<ResultResponse<List<MaintenanceRequestResponseDTO>>> getAllRequests() {
//        log.info("Getting all maintenance requests");
//        try {
//            List<MaintenanceRequestResponseDTO> responses = maintenanceRequestService.getAllRequests();
//            return ResponseEntity.ok(ResultResponse.<List<MaintenanceRequestResponseDTO>>builder()
//                    .success(true)
//                    .data(responses)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (Exception e) {
//            log.error("Error getting all requests: {}", e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<MaintenanceRequestResponseDTO>>builder()
//                    .success(false)
//                    .message("Internal server error")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
//
//    // Retrieve a specific maintenance request by ID
//    @GetMapping("/{id}")
//    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> getRequestById(@PathVariable String id) {
//        log.info("Getting maintenance request for ID: {}", id);
//        try {
//            UUID.fromString(id); // Validate UUID format
//            MaintenanceRequestResponseDTO response = maintenanceRequestService.getRequestById(id);
//            return ResponseEntity.ok(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(true)
//                    .data(response)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.badRequest().body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Invalid UUID format")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (RequestNotFoundException e) {
//            log.error("Request not found: {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message(e.getMessage())
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (Exception e) {
//            log.error("Error getting request: {}", e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Internal server error")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
//
//    // Update an existing maintenance request
//    @PutMapping("/update/{id}")
//    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> updateRequest(
//            @PathVariable String id, @RequestBody @Valid MaintenanceRequestDTO dto) {
//        log.info("Updating maintenance request with ID: {}", id);
//        try {
//            UUID.fromString(id); // Validate UUID format
//            dto.setRequestID(UUID.fromString(id));
//            MaintenanceRequestResponseDTO updatedResponse = maintenanceRequestService.updateRequest(id, dto);
//            return ResponseEntity.ok(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(true)
//                    .data(updatedResponse)
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.badRequest().body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Invalid UUID format")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (RequestNotFoundException e) {
//            log.error("Request not found: {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message(e.getMessage())
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (Exception e) {
//            log.error("Error updating request: {}", e.getMessage(), e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
//                    .success(false)
//                    .message("Internal server error")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//    }
//
//    // Delete a specific maintenance request by ID
//    @DeleteMapping("/delete/{id}")
//    public ResponseEntity<ResultResponse<Void>> deleteRequest(@PathVariable String id) {
//        log.info("Deleting maintenance request with ID: {}", id);
//        try {
//            UUID.fromString(id); // Validate UUID format
//            boolean deleted = maintenanceRequestService.deleteRequest(id);
//            if (deleted) {
//                return ResponseEntity.ok(ResultResponse.<Void>builder()
//                        .success(true)
//                        .timestamp(LocalDateTime.now())
//                        .build());
//            } else {
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
//                        .success(false)
//                        .message("Request not found")
//                        .timestamp(LocalDateTime.now())
//                        .build());
//            }
//        } catch (IllegalArgumentException e) {
//            return ResponseEntity.badRequest().body(ResultResponse.<Void>builder()
//                    .success(false)
//                    .message("Invalid UUID format")
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        } catch (RequestNotFoundException e) {
//            log.error("Request not found: {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
//                    .success(false)
//                    .message(e.getMessage())
//                    .timestamp(LocalDateTime.now())
//                    .build());
//        }
//   
























