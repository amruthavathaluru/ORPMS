package com.example.maintenancerequest.dto;

import java.util.UUID;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class MaintenanceRequestDTO {
    private UUID requestID;

   // @jakarta.validation.constraints.NotNull(message = "Tenant ID cannot be null")
    private UUID tenantID;

    //@NotNull(message = "Property ID cannot be null")
    private UUID propertyID;

    @NotNull(message = "Issue description cannot be null")
    @Size(min = 10, max = 200, message = "Issue description must be between 10 and 200 characters")
    private String issueDescription;

    @NotNull(message = "Status cannot be null")
    private String status;

    // Getters and Setters
    public UUID getRequestID() { return requestID; }
    public void setRequestID(UUID requestID) { this.requestID = requestID; }

    public UUID getTenantID() { return tenantID; }
    public void setTenantID(UUID tenantID) { this.tenantID = tenantID; }

    public UUID getPropertyID() { return propertyID; }
    public void setPropertyID(UUID propertyID) { this.propertyID = propertyID; }

    public String getIssueDescription() { return issueDescription; }
    public void setIssueDescription(String issueDescription) { this.issueDescription = issueDescription; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    
}




//package com.example.maintenancerequest.dto;
//
//public class MaintenanceRequestDTO {
//    private String requestID;
//    private String tenantID;
//    private String propertyID;
//    private String issueDescription;
//    private String status;
//
//    // Getters and Setters
//    public String getRequestID() { return requestID; }
//    public void setRequestID(String requestID) { this.requestID = requestID; }
//
//    public String getTenantID() { return tenantID; }
//    public void setTenantID(String tenantID) { this.tenantID = tenantID; }
//
//    public String getPropertyID() { return propertyID; }
//    public void setPropertyID(String propertyID) { this.propertyID = propertyID; }
//
//    public String getIssueDescription() { return issueDescription; }
//    public void setIssueDescription(String issueDescription) { this.issueDescription = issueDescription; }
//
//    public String getStatus() { return status; }
//    public void setStatus(String status) { this.status = status; }
//}
