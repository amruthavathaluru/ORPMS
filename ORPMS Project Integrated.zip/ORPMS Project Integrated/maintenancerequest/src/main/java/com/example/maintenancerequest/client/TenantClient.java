package com.example.maintenancerequest.client;

import java.util.UUID;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.maintenancerequest.dto.ResultResponse;
import com.example.maintenancerequest.dto.TenantDTO;

@FeignClient(name = "tenantmanagementmodule")
public interface TenantClient {

    @GetMapping("tenant/{tenantId}")
    ResponseEntity<ResultResponse<TenantDTO>> getTenantById(@PathVariable("tenantId") UUID tenantID);
}
