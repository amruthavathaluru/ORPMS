package com.example.maintenancerequest.advice;

import com.example.maintenancerequest.exceptions.DuplicateRequestException;
import com.example.maintenancerequest.exceptions.RequestNotFoundException;
import com.example.maintenancerequest.utils.ResultResponse;

import jakarta.validation.ValidationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;

@RestControllerAdvice // Combines @ControllerAdvice and @ResponseBody to handle exceptions for REST controllers
public class GlobalExceptionHandler {

    // Handle RequestNotFoundException
    @ExceptionHandler(RequestNotFoundException.class)
    public ResponseEntity<ResultResponse<Void>> handleRequestNotFoundException(RequestNotFoundException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
                .success(false)
                .message(e.getMessage())
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Handle ValidationException
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ResultResponse<Void>> handleValidationException(ValidationException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResultResponse.<Void>builder()
                .success(false)
                .message(e.getMessage())
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Handle IllegalArgumentException
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ResultResponse<Void>> handleIllegalArgumentException(IllegalArgumentException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResultResponse.<Void>builder()
                .success(false)
                .message("Invalid UUID format")
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Handle DuplicateRequestException
    @ExceptionHandler(DuplicateRequestException.class)
    public ResponseEntity<ResultResponse<Void>> handleDuplicateRequestException(DuplicateRequestException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<Void>builder()
                .success(false)
                .message(e.getMessage())
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Handle Generic Exceptions
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResultResponse<Void>> handleGenericException(Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<Void>builder()
                .success(false)
                .message("An unexpected error occurred. Please contact support.")
                .timestamp(LocalDateTime.now())
                .build());
    }
}


































//package com.example.maintenancerequest.exceptions;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ControllerAdvice;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.context.request.WebRequest;
//
//import com.example.maintenancerequest.utils.ResultResponse;
//
//import jakarta.validation.ValidationException;
//
//import java.time.LocalDateTime;
//
//@ControllerAdvice
//public class GlobalExceptionHandler {
//
//    // Handle RequestNotFoundException
//    @ExceptionHandler(RequestNotFoundException.class)
//    public ResponseEntity<ResultResponse<String>> handleRequestNotFoundException(RequestNotFoundException ex, WebRequest request) {
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<String>builder()
//                .success(false)
//                .message(ex.getMessage())
//                .timestamp(LocalDateTime.now())
//                .build());
//    }
//
//    // Handle DuplicateRequestException
//    @ExceptionHandler(DuplicateRequestException.class)
//    public ResponseEntity<ResultResponse<String>> handleDuplicateRequestException(DuplicateRequestException ex, WebRequest request) {
//        return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<String>builder()
//                .success(false)
//                .message(ex.getMessage())
//                .timestamp(LocalDateTime.now())
//                .build());
//    }
//
//    // Handle ValidationException
//    @ExceptionHandler(ValidationException.class)
//    public ResponseEntity<ResultResponse<String>> handleValidationException(ValidationException ex, WebRequest request) {
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResultResponse.<String>builder()
//                .success(false)
//                .message(ex.getMessage())
//                .timestamp(LocalDateTime.now())
//                .build());
//    }
//
//    // Handle all other exceptions
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<ResultResponse<String>> handleGlobalException(Exception ex, WebRequest request) {
//        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<String>builder()
//                .success(false)
//                .message("Internal server error")
//                .timestamp(LocalDateTime.now())
//                .build());
//    }
//}











//package com.example.maintenancerequest.exceptions;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ControllerAdvice;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.context.request.WebRequest;
//
//import com.example.maintenancerequest.utils.ResultResponse;
//
//import jakarta.validation.ValidationException;
//
//import java.time.LocalDateTime;
//
//@ControllerAdvice
//public class GlobalExceptionHandler {
//
//  @ExceptionHandler(RequestNotFoundException.class)
//  public ResponseEntity<ResultResponse<String>> handleRequestNotFoundException(RequestNotFoundException ex, WebRequest request) {
//      return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<String>builder()
//              .success(false)
//              .message(ex.getMessage())
//              .timestamp(LocalDateTime.now())
//              .build());
//  }
//
//  @ExceptionHandler(DuplicateRequestException.class)
//  public ResponseEntity<ResultResponse<String>> handleDuplicateRequestException(DuplicateRequestException ex, WebRequest request) {
//      return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<String>builder()
//              .success(false)
//              .message(ex.getMessage())
//              .timestamp(LocalDateTime.now())
//              .build());
//  }
//
//  @ExceptionHandler(ValidationException.class)
//  public ResponseEntity<ResultResponse<String>> handleValidationException(ValidationException ex, WebRequest request) {
//      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResultResponse.<String>builder()
//              .success(false)
//              .message(ex.getMessage())
//              .timestamp(LocalDateTime.now())
//              .build());
//  }
//
//  @ExceptionHandler(Exception.class)
//  public ResponseEntity<ResultResponse<String>> handleGlobalException(Exception ex, WebRequest request) {
//      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<String>builder()
//              .success(false)
//              .message("Internal server error")
//              .timestamp(LocalDateTime.now())
//              .build());
//  }
//}
















//package com.example.maintenancerequest.exceptions;
//
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.ControllerAdvice;
//import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.context.request.WebRequest;
//
//import com.example.maintenancerequest.utils.ResultResponse;
//
//import jakarta.validation.ValidationException;
//
//import java.time.LocalDateTime;
//
//@ControllerAdvice
//public class GlobalExceptionHandler {
//
//    @ExceptionHandler(RequestNotFoundException.class)
//    public ResponseEntity<ResultResponse<String>> handleRequestNotFoundException(RequestNotFoundException ex, WebRequest request) {
//        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<String>builder()
//                .success(false)
//                .message(ex.getMessage())
//                .timestamp(LocalDateTime.now())
//               ExceptionHandler(DuplicateRequestException.class)
//    public ResponseEntity<ResultResponse<String>> handleDuplicateRequestException(DuplicateRequestException ex, WebRequest request) {
//        return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<String>builder()
//                .success(false)
//                .message(ex.getMessage())
//                .timestamp(LocalDateTime.now())
//                .build());
//    }
//
//    @ExceptionHandler(ValidationException.class)
//    public ResponseEntity<ResultResponse<String>> handleValidationException(ValidationException ex, WebRequest request) {
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResultResponse.<String>builder()
//                .success(false)
//                .message(ex.getMessage())
//                .timestamp(LocalDateTime.now())
//                .build());
//    }
//
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<ResultResponse<String>> handleGlobalException(Exception ex, WebRequest request) {
//        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<String>builder()
//                .success(false)
//                .message("Internal server error")
//                .timestamp(LocalDateTime.now())
//                .build());
//    }

