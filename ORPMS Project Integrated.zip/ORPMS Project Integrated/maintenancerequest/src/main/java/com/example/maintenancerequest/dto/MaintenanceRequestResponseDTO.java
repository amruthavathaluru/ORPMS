package com.example.maintenancerequest.dto;

import java.util.UUID;

public class MaintenanceRequestResponseDTO {
    private UUID requestID;
    private UUID tenantID; // Now displaying Tenant ID
    private UUID propertyID; // Now displaying Property ID
    private String issueDescription;
    private String status; // Enum value as a string

    // Constructor
    public MaintenanceRequestResponseDTO(UUID requestID, UUID tenantID, UUID propertyID, 
                                         String issueDescription, String status) {
        this.requestID = requestID;
        this.tenantID = tenantID;
        this.propertyID = propertyID;
        this.issueDescription = issueDescription;
        this.status = status;
    }

    // Getters and Setters
    public UUID getRequestID() {
        return requestID;
    }

    public void setRequestID(UUID requestID) {
        this.requestID = requestID;
    }

    public UUID getTenantID() {
        return tenantID;
    }

    public void setTenantID(UUID tenantID) {
        this.tenantID = tenantID;
    }

    public UUID getPropertyID() {
        return propertyID;
    }

    public void setPropertyID(UUID propertyID) {
        this.propertyID = propertyID;
    }

    public String getIssueDescription() {
        return issueDescription;
    }

    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
