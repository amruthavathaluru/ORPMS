package com.example.maintenancerequest.service;

import com.example.maintenancerequest.dto.MaintenanceRequestDTO;
import com.example.maintenancerequest.dto.MaintenanceRequestResponseDTO;
import com.example.maintenancerequest.entity.MaintenanceRequest;
import com.example.maintenancerequest.enums.MaintenanceRequestStatus;
import com.example.maintenancerequest.exceptions.RequestNotFoundException;
import com.example.maintenancerequest.repository.MaintenanceRequestRepository;

import jakarta.validation.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class MaintenanceRequestService {

    @Autowired
    private MaintenanceRequestRepository maintenanceRequestRepository;

    // Create a maintenance request
    public MaintenanceRequestResponseDTO createRequest(MaintenanceRequestDTO dto) {
        MaintenanceRequest request = new MaintenanceRequest();
        request.setTenantID(dto.getTenantID().toString());
        request.setPropertyID(dto.getPropertyID().toString());
        request.setIssueDescription(dto.getIssueDescription());

        // Handle the status field
        if (dto.getStatus() != null) {
            try {
                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus());
                request.setStatus(status);
            } catch (IllegalArgumentException e) {
                throw new ValidationException("Invalid status: " + dto.getStatus());
            }
        } else {
            request.setStatus(MaintenanceRequestStatus.request_received);
        }

        // Save the entity
        MaintenanceRequest savedRequest = maintenanceRequestRepository.save(request);

        // Map entity to response DTO
        return mapToResponseDTO(savedRequest);
    }

    // Retrieve all maintenance requests
    public List<MaintenanceRequestResponseDTO> getAllRequests() {
        return maintenanceRequestRepository.findAll().stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
    }

    // Retrieve a maintenance request by ID
    public MaintenanceRequestResponseDTO getRequestById(String requestID) {
        UUID uuid = validateUUID(requestID);

        MaintenanceRequest request = maintenanceRequestRepository.findById(uuid.toString())
                .orElseThrow(() -> new RequestNotFoundException("Request not found with ID: " + requestID));

        return mapToResponseDTO(request);
    }

    // Update a maintenance request
    public MaintenanceRequestResponseDTO updateRequest(String requestID, MaintenanceRequestDTO dto) {
        UUID uuid = validateUUID(requestID);

        MaintenanceRequest request = maintenanceRequestRepository.findById(uuid.toString())
                .orElseThrow(() -> new RequestNotFoundException("Request not found with ID: " + requestID));

        // Update fields if provided
        if (dto.getIssueDescription() != null) {
            request.setIssueDescription(dto.getIssueDescription());
        }
        if (dto.getStatus() != null) {
            try {
                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus());
                request.setStatus(status);
            } catch (IllegalArgumentException e) {
                throw new ValidationException("Invalid status: " + dto.getStatus());
            }
        }

        // Save the updated entity
        MaintenanceRequest updatedRequest = maintenanceRequestRepository.save(request);

        // Map entity to response DTO
        return mapToResponseDTO(updatedRequest);
    }

    // Delete a maintenance request
    public boolean deleteRequest(String requestID) {
        UUID uuid = validateUUID(requestID);

        MaintenanceRequest request = maintenanceRequestRepository.findById(uuid.toString())
                .orElseThrow(() -> new RequestNotFoundException("Request not found with ID: " + requestID));

        maintenanceRequestRepository.delete(request);
        return true;
    }

    // Helper method to validate UUID format
    private UUID validateUUID(String uuid) {
        try {
            return UUID.fromString(uuid);
        } catch (IllegalArgumentException e) {
            throw new ValidationException("Invalid UUID format: " + uuid);
        }
    }

    // Helper method to map entity to response DTO
    private MaintenanceRequestResponseDTO mapToResponseDTO(MaintenanceRequest request) {
        return new MaintenanceRequestResponseDTO(
                UUID.fromString(request.getRequestID()),
                UUID.fromString(request.getTenantID()),
                UUID.fromString(request.getPropertyID()),
                request.getIssueDescription(),
                request.getStatus().name()
        );
    }
}




































////Working code before microservices
//package com.example.maintenancerequest.service;
//
//import com.example.maintenancerequest.dto.MaintenanceRequestDTO;
//import com.example.maintenancerequest.dto.MaintenanceRequestResponseDTO;
//import com.example.maintenancerequest.entity.MaintenanceRequest;
//import com.example.maintenancerequest.entity.Property;
//import com.example.maintenancerequest.entity.Tenant;
//import com.example.maintenancerequest.enums.MaintenanceRequestStatus;
//import com.example.maintenancerequest.exceptions.RequestNotFoundException;
//import com.example.maintenancerequest.repository.MaintenanceRequestRepository;
//import com.example.maintenancerequest.repository.PropertyRepository;
//import com.example.maintenancerequest.repository.TenantRepository;
//
//import jakarta.validation.ValidationException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.UUID;
//import java.util.stream.Collectors;
//
//@Service
//public class MaintenanceRequestService {
//
//    @Autowired
//    private MaintenanceRequestRepository maintenanceRequestRepository;
//
//    @Autowired
//    private PropertyRepository propertyRepository;
//
//    @Autowired
//    private TenantRepository tenantRepository;
//
//    public MaintenanceRequestResponseDTO createRequest(MaintenanceRequestDTO dto) {
//        Property property = propertyRepository.findById(dto.getPropertyID())
//                .orElseThrow(() -> new RequestNotFoundException("Property not found with ID: " + dto.getPropertyID()));
//
//        Tenant tenant = tenantRepository.findById(dto.getTenantID())
//                .orElseThrow(() -> new RequestNotFoundException("Tenant not found with ID: " + dto.getTenantID()));
//
//        MaintenanceRequest request = new MaintenanceRequest();
//        request.setProperty(property);
//        request.setTenant(tenant);
//        request.setIssueDescription(dto.getIssueDescription());
//
//        if (dto.getStatus() != null) {
//            try {
//                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus());
//                request.setStatus(status);
//            } catch (IllegalArgumentException e) {
//                throw new ValidationException("Invalid status: " + dto.getStatus() +
//                        ". Allowed values are: request_submitted, request_received, assigned_to_service_provider, request_closed.");
//            }
//        } else {
//            request.setStatus(MaintenanceRequestStatus.request_received);
//        }
//
//        MaintenanceRequest savedRequest = maintenanceRequestRepository.save(request);
//
//        return new MaintenanceRequestResponseDTO(
//                savedRequest.getRequestID(),
//                tenant.getName(),
//                property.getPropertyName(),
//                savedRequest.getIssueDescription(),
//                savedRequest.getStatus().name()
//        );
//    }
//
//    public List<MaintenanceRequestResponseDTO> getAllRequests() {
//        List<MaintenanceRequest> requests = maintenanceRequestRepository.findAll();
//        return requests.stream().map(request -> new MaintenanceRequestResponseDTO(
//                request.getRequestID(),
//                request.getTenant().getName(),
//                request.getProperty().getPropertyName(),
//                request.getIssueDescription(),
//                request.getStatus().name()
//        )).collect(Collectors.toList());
//    }
//
//    public MaintenanceRequestResponseDTO getRequestById(String requestID) {
//        UUID.fromString(requestID);
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID)
//                .orElseThrow(() -> new RequestNotFoundException("Request not found with ID: " + requestID));
//
//        return new MaintenanceRequestResponseDTO(
//                request.getRequestID(),
//                request.getTenant().getName(),
//                request.getProperty().getPropertyName(),
//                request.getIssueDescription(),
//                request.getStatus().name()
//        );
//    }
//
//    public MaintenanceRequestResponseDTO updateRequest(String requestID, MaintenanceRequestDTO dto) {
//        UUID.fromString(requestID);
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID)
//                .orElseThrow(() -> new RequestNotFoundException("Request not found with ID: " + requestID));
//
//        if (dto.getIssueDescription() != null) {
//            request.setIssueDescription(dto.getIssueDescription());
//        }
//        if (dto.getStatus() != null) {
//            try {
//                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus());
//                request.setStatus(status);
//            } catch (IllegalArgumentException e) {
//                throw new ValidationException("Invalid status: " + dto.getStatus() +
//                        ". Allowed values are: request_submitted, request_received, assigned_to_service_provider, request_closed.");
//            }
//        }
//
//        MaintenanceRequest updatedRequest = maintenanceRequestRepository.save(request);
//
//        return new MaintenanceRequestResponseDTO(
//                updatedRequest.getRequestID(),
//                updatedRequest.getTenant().getName(),
//                updatedRequest.getProperty().getPropertyName(),
//                updatedRequest.getIssueDescription(),
//                updatedRequest.getStatus().name()
//        );
//    }
//
//    public boolean deleteRequest(String requestID) {
//        UUID.fromString(requestID);
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID).orElseThrow(() ->
//                new RequestNotFoundException("Request not found with ID: " + requestID));
//
//        maintenanceRequestRepository.delete(request);
//        return true;
//    }
//}






































//package com.example.maintenancerequest.service;
//
//import com.example.maintenancerequest.dto.MaintenanceRequestDTO;
//import com.example.maintenancerequest.dto.MaintenanceRequestResponseDTO;
//import com.example.maintenancerequest.entity.MaintenanceRequest;
//import com.example.maintenancerequest.entity.Property;
//import com.example.maintenancerequest.entity.Tenant;
//import com.example.maintenancerequest.enums.MaintenanceRequestStatus;
//import com.example.maintenancerequest.exceptions.RequestNotFoundException;
//import com.example.maintenancerequest.repository.MaintenanceRequestRepository;
//import com.example.maintenancerequest.repository.PropertyRepository;
//import com.example.maintenancerequest.repository.TenantRepository;
//
//import jakarta.validation.ValidationException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.stream.Collectors;
//import java.util.UUID;
//
//@Service
//public class MaintenanceRequestService {
//
//    @Autowired
//    private MaintenanceRequestRepository maintenanceRequestRepository;
//
//    @Autowired
//    private PropertyRepository propertyRepository;
//
//    @Autowired
//    private TenantRepository tenantRepository;
//
//    // 1. Create a new maintenance request
//    public MaintenanceRequestResponseDTO createRequest(MaintenanceRequestDTO dto) {
//        // Fetch and validate Property	
//        Property property = propertyRepository.findById(dto.getPropertyID()).orElse(null);
//        if (property == null) {
//            throw new RequestNotFoundException("Property not found with ID: " + dto.getPropertyID());
//        }
//
//        // Fetch and validate Tenant
//        Tenant tenant = tenantRepository.findById(dto.getTenantID()).orElse(null);
//        if (tenant == null) {
//            throw new RequestNotFoundException("Tenant not found with ID: " + dto.getTenantID());
//        }
//
//        // Create and populate MaintenanceRequest
//        MaintenanceRequest request = new MaintenanceRequest();
//        request.setProperty(property);
//        request.setTenant(tenant);
//        request.setIssueDescription(dto.getIssueDescription());
//
//        // Validate and set status
//        if (dto.getStatus() != null) {
//            try {
//                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus());
//                request.setStatus(status);
//            } catch (IllegalArgumentException e) {
//                throw new ValidationException("Invalid status: " + dto.getStatus() +
//                    ". Allowed values are: request_submitted, request_received, assigned_to_service_provider, request_closed.");
//            }
//        } else {
//            request.setStatus(MaintenanceRequestStatus.request_received); // Default value
//        }
//
//        MaintenanceRequest savedRequest = maintenanceRequestRepository.save(request);
//
//        // Build and return the response DTO
//        return new MaintenanceRequestResponseDTO(
//            savedRequest.getRequestID(),
//            tenant.getName(),
//            property.getPropertyName(),
//            savedRequest.getIssueDescription(),
//            savedRequest.getStatus().name()
//        );
//    }
//
//    // 2. Retrieve all maintenance requests
//    public List<MaintenanceRequestResponseDTO> getAllRequests() {
//        List<MaintenanceRequest> requests = maintenanceRequestRepository.findAll();
//        return requests.stream().map(request -> new MaintenanceRequestResponseDTO(
//            request.getRequestID(),
//            request.getTenant().getName(),
//            request.getProperty().getPropertyName(),
//            request.getIssueDescription(),
//            request.getStatus().name()
//        )).collect(Collectors.toList());
//    }
//
//    // 3. Retrieve a specific maintenance request by ID
//    public MaintenanceRequestResponseDTO getRequestById(String requestID) {
//        UUID.fromString(requestID); // Validate UUID format
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID)
//            .orElseThrow(() -> new RequestNotFoundException("Request not found with ID: " + requestID));
//        return new MaintenanceRequestResponseDTO(
//            request.getRequestID(),
//            request.getTenant().getName(),
//            request.getProperty().getPropertyName(),
//            request.getIssueDescription(),
//            request.getStatus().name()
//        );
//    }
//
//    // 4. Update an existing maintenance request
//    public MaintenanceRequestResponseDTO updateRequest(String requestID, MaintenanceRequestDTO dto) {
//        UUID.fromString(requestID); // Validate UUID format
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID)
//            .orElseThrow(() -> new RequestNotFoundException("Request not found with ID: " + requestID));
//
//        // Update fields if provided
//        if (dto.getIssueDescription() != null) {
//            request.setIssueDescription(dto.getIssueDescription());
//        }
//        
//        //validating the status
//        if (dto.getStatus() != null) {
//            try {
//                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus());
//                request.setStatus(status);
//            } catch (IllegalArgumentException e) {
//                throw new ValidationException("Invalid status: " + dto.getStatus() +
//                    ". Allowed values are: request_submitted, request_received, assigned_to_service_provider, request_closed.");
//            }
//        }
//
//        MaintenanceRequest updatedRequest = maintenanceRequestRepository.save(request);
//
//        // Build and return the response DTO
//        return new MaintenanceRequestResponseDTO(
//            updatedRequest.getRequestID(),
//            updatedRequest.getTenant().getName(),
//            updatedRequest.getProperty().getPropertyName(),
//            updatedRequest.getIssueDescription(),
//            updatedRequest.getStatus().name()
//        );
//    }
//
//    // 5. Delete an existing request
//    public boolean deleteRequest(String requestID) {
//        UUID.fromString(requestID); // Validate UUID format
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID).orElse(null);
//
//        // Throw exception if the request is not found
//        if (request == null) {
//            throw new RequestNotFoundException("Request not found with ID: " + requestID);
//        }
//
//        // Delete the found request
//        maintenanceRequestRepository.delete(request);
//        return true;
//    }
//}










































//package com.example.maintenancerequest.service;
//
//import com.example.maintenancerequest.dto.MaintenanceRequestDTO;
//import com.example.maintenancerequest.dto.MaintenanceRequestResponseDTO;
//import com.example.maintenancerequest.entity.MaintenanceRequest;
//import com.example.maintenancerequest.entity.Property;
//import com.example.maintenancerequest.entity.Tenant;
//import com.example.maintenancerequest.exceptions.ResourceNotFoundException;
//import com.example.maintenancerequest.repository.MaintenanceRequestRepository;
//import com.example.maintenancerequest.repository.PropertyRepository;
//import com.example.maintenancerequest.repository.TenantRepository;
//import com.example.maintenancerequest.utils.MaintenanceRequestStatus;
//import jakarta.validation.ValidationException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//@Service
//public class MaintenanceRequestService {
//
//    @Autowired
//    private MaintenanceRequestRepository maintenanceRequestRepository;
//
//    @Autowired
//    private PropertyRepository propertyRepository;
//
//    @Autowired
//    private TenantRepository tenantRepository;
//
//    // 1. Create a new maintenance request
//    public MaintenanceRequestResponseDTO createRequest(MaintenanceRequestDTO dto) {
//        // Fetch and validate Property
//        Property property = propertyRepository.findById(dto.getPropertyID()).orElse(null);
//        if (property == null) {
//            throw new ResourceNotFoundException("Property not found with ID: " + dto.getPropertyID());
//        }
//
//        // Fetch and validate Tenant
//        Tenant tenant = tenantRepository.findById(dto.getTenantID()).orElse(null);
//        if (tenant == null) {
//            throw new ResourceNotFoundException("Tenant not found with ID: " + dto.getTenantID());
//        }
//
//        // Create and populate MaintenanceRequest
//        MaintenanceRequest request = new MaintenanceRequest();
//        request.setProperty(property);
//        request.setTenant(tenant);
//        request.setIssueDescription(dto.getIssueDescription());
//
//        // Validate and set status
//        if (dto.getStatus() != null) {
//            try {
//                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus().toUpperCase());
//                request.setStatus(status);
//            } catch (IllegalArgumentException e) {
//                throw new ValidationException("Invalid status: " + dto.getStatus() + ". Allowed values are: request_submitted, request_received, assigned_to_service_provider, request_closed.");
//            }
//        } else {
//            request.setStatus(MaintenanceRequestStatus.request_received); // Default value
//        }
//
//        MaintenanceRequest savedRequest = maintenanceRequestRepository.save(request);
//
//        // Build and return the response DTO
//        return new MaintenanceRequestResponseDTO(
//                savedRequest.getRequestID(),
//                tenant.getName(), // Extract name from Tenant
//                property.getPropertyName(), // Extract property name from Property
//                savedRequest.getIssueDescription(),
//                savedRequest.getStatus().name()
//        );
//    }
//
//    // 2. Retrieve all maintenance requests
//    public List<MaintenanceRequestResponseDTO> getAllRequests() {
//        List<MaintenanceRequest> requests = maintenanceRequestRepository.findAll();
//        return requests.stream().map(request -> new MaintenanceRequestResponseDTO(
//                request.getRequestID(),
//                request.getTenant().getName(),
//                request.getProperty().getPropertyName(),
//                request.getIssueDescription(),
//                request.getStatus().name()
//        )).collect(Collectors.toList());
//    }
//
//    // 3. Retrieve a specific maintenance request by ID
//    public MaintenanceRequestResponseDTO getRequestById(String requestID) {
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID)
//                .orElseThrow(() -> new ResourceNotFoundException("Request not found with ID: " + requestID));
//        return new MaintenanceRequestResponseDTO(
//                request.getRequestID(),
//                request.getTenant().getName(),
//                request.getProperty().getPropertyName(),
//                request.getIssueDescription(),
//                request.getStatus().name()
//        );
//    }
//
//    // 4. Update an existing maintenance request
//    public MaintenanceRequestResponseDTO updateRequest(String requestID, MaintenanceRequestDTO dto) {
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID)
//                .orElseThrow(() -> new ResourceNotFoundException("Request not found with ID: " + requestID));
//
//        // Update fields if provided
//        if (dto.getIssueDescription() != null) {
//            request.setIssueDescription(dto.getIssueDescription());
//        }
//        if (dto.getStatus() != null) {
//            try {
//                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus().toUpperCase());
//                request.setStatus(status);
//            } catch (IllegalArgumentException e) {
//                throw new ValidationException("Invalid status: " + dto.getStatus() + ". Allowed values are: request_submitted, request_received, assigned_to_service_provider, request_closed.");
//            }
//        }
//
//        MaintenanceRequest updatedRequest = maintenanceRequestRepository.save(request);
//
//        // Build and return the response DTO
//        return new MaintenanceRequestResponseDTO(
//                updatedRequest.getRequestID(),
//                updatedRequest.getTenant().getName(),
//                updatedRequest.getProperty().getPropertyName(),
//                updatedRequest.getIssueDescription(),
//                updatedRequest.getStatus().name()
//        );
//    }
//
//    // 5. Delete an existing request
//    public void deleteRequest(String requestID) {
//        // Find the maintenance request by ID
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID).orElse(null);
//
//        // Throw exception if the request is not found
//        if (request == null) {
//            throw new ResourceNotFoundException("Request not found with ID: " + requestID);
//        }
//
//        // Delete the found request
//        maintenanceRequestRepository.delete(request);
//    }
//}









































//package com.example.maintenancerequest.service;
//
//import com.example.maintenancerequest.dto.MaintenanceRequestDTO;
//import com.example.maintenancerequest.dto.MaintenanceRequestResponseDTO;
//import com.example.maintenancerequest.entity.MaintenanceRequest;
//import com.example.maintenancerequest.entity.Property;
//import com.example.maintenancerequest.entity.Tenant;
//import com.example.maintenancerequest.exceptions.ResourceNotFoundException;
//import com.example.maintenancerequest.repository.MaintenanceRequestRepository;
//import com.example.maintenancerequest.repository.PropertyRepository;
//import com.example.maintenancerequest.repository.TenantRepository;
//import com.example.maintenancerequest.utils.MaintenanceRequestStatus;
//import jakarta.validation.ValidationException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//@Service
//public class MaintenanceRequestService {
//
//    @Autowired
//    private MaintenanceRequestRepository maintenanceRequestRepository;
//
//    @Autowired
//    private PropertyRepository propertyRepository;
//
//    @Autowired
//    private TenantRepository tenantRepository;
//
//    // 1. Create a new maintenance request
//    public MaintenanceRequestResponseDTO createRequest(MaintenanceRequestDTO dto) {
//        // Fetch and validate Property
//        Property property = propertyRepository.findById(dto.getPropertyID()).orElse(null);
//        if (property == null) {
//            throw new ResourceNotFoundException("Property not found with ID: " + dto.getPropertyID());
//        }
//
//        // Fetch and validate Tenant
//        
//        Tenant tenant = tenantRepository.findById(dto.getTenantID()).orElse(null);
//        if (tenant == null) {
//            throw new ResourceNotFoundException("Tenant not found with ID: " + dto.getTenantID());
//        }
//
//        // Create and populate MaintenanceRequest
//        MaintenanceRequest request = new MaintenanceRequest();
//        request.setProperty(property);
//        request.setTenant(tenant);
//        request.setIssueDescription(dto.getIssueDescription());
//
//        // Validate and set status
//        if (dto.getStatus() != null) {
//            try {
//                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus().toLowerCase());
//                request.setStatus(status);
//            } catch (IllegalArgumentException e) {
//                throw new ValidationException("Invalid status: " + dto.getStatus() + ". Allowed values are: request_submitted, request_received, assigned_to_service_provider, request_closed.");
//            }
//        } else {
//            request.setStatus(MaintenanceRequestStatus.request_received); // Default value
//        }
//
//        MaintenanceRequest savedRequest = maintenanceRequestRepository.save(request);
//
//        // Build and return the response DTO
//        return new MaintenanceRequestResponseDTO(
//                savedRequest.getRequestID(),
//                tenant.getName(), // Extract name from Tenant
//                property.getPropertyName(), // Extract property name from Property
//                savedRequest.getIssueDescription(),
//                savedRequest.getStatus().name()
//        );
//    }
//
//    // 2. Retrieve all maintenance requests
//    public List<MaintenanceRequestResponseDTO> getAllRequests() {
//        List<MaintenanceRequest> requests = maintenanceRequestRepository.findAll();
//        return requests.stream().map(request -> new MaintenanceRequestResponseDTO(
//                request.getRequestID(),
//                request.getTenant().getName(),
//                request.getProperty().getPropertyName(),
//                request.getIssueDescription(),
//                request.getStatus().name()
//        )).collect(Collectors.toList());
//    }
//
//    // 3. Retrieve a specific maintenance request by ID
//    public MaintenanceRequestResponseDTO getRequestById(String requestID) {
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID)
//                .orElseThrow(() -> new ResourceNotFoundException("Request not found with ID: " + requestID));
//        return new MaintenanceRequestResponseDTO(
//                request.getRequestID(),
//                request.getTenant().getName(),
//                request.getProperty().getPropertyName(),
//                request.getIssueDescription(),
//                request.getStatus().name()
//        );
//    }
//
//    // 4. Update an existing maintenance request
//    public MaintenanceRequestResponseDTO updateRequest(String requestID, MaintenanceRequestDTO dto) {
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID)
//                .orElseThrow(() -> new ResourceNotFoundException("Request not found with ID: " + requestID));
//
//        // Update fields if provided
//        if (dto.getIssueDescription() != null) {
//            request.setIssueDescription(dto.getIssueDescription());
//        }
//        if (dto.getStatus() != null) {
//            try {
//                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus().toLowerCase());
//                request.setStatus(status);
//            } catch (IllegalArgumentException e) {
//                throw new ValidationException("Invalid status: " + dto.getStatus() + ". Allowed values are: request_submitted, request_received, assigned_to_service_provider, request_closed.");
//            }
//        }
//
//        MaintenanceRequest updatedRequest = maintenanceRequestRepository.save(request);
//
//        // Build and return the response DTO
//        return new MaintenanceRequestResponseDTO(
//                updatedRequest.getRequestID(),
//                updatedRequest.getTenant().getName(),
//                updatedRequest.getProperty().getPropertyName(),
//                updatedRequest.getIssueDescription(),
//                updatedRequest.getStatus().name()
//        );
//    }
//
//  //	5.Deleting the existing request
//    public void deleteRequest(String requestID) {
//        // Find the maintenance request by ID
//        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID).orElse(null);
//
//        // Throw exception if the request is not found
//        if (request == null) {
//            throw new ResourceNotFoundException("Request not found with ID: " + requestID);
//        }
//
//        // Delete the found request
//        maintenanceRequestRepository.delete(request);
//    }
//
//}




