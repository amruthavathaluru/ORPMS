package com.example.maintenancerequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication // Allow scanning of the entire project
@EnableDiscoveryClient // Enables Eureka or other service discovery clients
@EnableFeignClients // Specify Feign client package if needed
public class MaintenancerequestApplication {
    public static void main(String[] args) {
        SpringApplication.run(MaintenancerequestApplication.class, args);
    }
}
