package com.example.maintenancerequest.utils;

import java.time.LocalDateTime;

public class ResultResponse<T> {

    private boolean success;
    private String message;
    private T data;
    private LocalDateTime timestamp;

    // Default Constructor
    public ResultResponse() {}

    // Parameterized Constructor
    public ResultResponse(boolean success, String message, T data, LocalDateTime timestamp) {
        this.success = success;
        this.message = message;
        this.data = data;
        this.timestamp = timestamp;
    }

    // Getters and Setters
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    // Static Builder Method
    public static <T> ResultResponseBuilder<T> builder() {
        return new ResultResponseBuilder<>();
    }

    // Builder Class
    public static class ResultResponseBuilder<T> {
        private boolean success;
        private String message;
        private T data;
        private LocalDateTime timestamp;

        public ResultResponseBuilder() {}

        public ResultResponseBuilder<T> success(boolean success) {
            this.success = success;
            return this;
        }

        public ResultResponseBuilder<T> message(String message) {
            this.message = message;
            return this;
        }

        public ResultResponseBuilder<T> data(T data) {
            this.data = data;
            return this;
        }

        public ResultResponseBuilder<T> timestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public ResultResponse<T> build() {
            return new ResultResponse<>(success, message, data, timestamp);
        }

        @Override
        public String toString() {
            return "ResultResponseBuilder(success=" + this.success + ", message=" + this.message + ", data=" + this.data + ", timestamp=" + this.timestamp + ")";
        }
    }
}






























//package com.example.maintenancerequest.utils;
//
//import java.time.LocalDateTime;
//
//import lombok.Builder;
//import lombok.Data;
//
//@Data
//@Builder
//public class ResultResponse<T> {
// 
//    private boolean success;
//    private String message;
//    private T data;
//    private LocalDateTime timestamp;
// 
//    public static <T> ResultResponseBuilder<T> builder() {
//        return new ResultResponseBuilder<>();
//    }
// 
//    public static class ResultResponseBuilder<T> {
//        private boolean success;
//        private String message;
//        private T data;
//        private LocalDateTime timestamp;
// 
//        ResultResponseBuilder() {
//        }
// 
//        public ResultResponseBuilder<T> success(boolean success) {
//            this.success = success;
//            return this;
//        }
// 
//        public ResultResponseBuilder<T> message(String message) {
//            this.message = message;
//            return this;
//        }
// 
//        public ResultResponseBuilder<T> data(T data) {
//            this.data = data;
//            return this;
//        }
// 
//        public ResultResponseBuilder<T> timestamp(LocalDateTime timestamp) {
//            this.timestamp = timestamp;
//            return this;
//        }
// 
//        public ResultResponse<T> build() {
//            return new ResultResponse<>(success, message, data, timestamp);
//        }
// 
//        public String toString() {
//            return "ResultResponse.ResultResponseBuilder(success=" + this.success + ", message=" + this.message + ", data=" + this.data + ", timestamp=" + this.timestamp + ")";
//        }
//    }
//}
