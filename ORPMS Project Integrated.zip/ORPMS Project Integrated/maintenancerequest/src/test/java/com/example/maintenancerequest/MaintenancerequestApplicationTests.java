package com.example.maintenancerequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaintenancerequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
