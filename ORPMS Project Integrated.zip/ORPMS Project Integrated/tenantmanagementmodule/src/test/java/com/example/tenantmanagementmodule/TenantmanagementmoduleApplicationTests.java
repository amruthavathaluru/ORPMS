package com.example.tenantmanagementmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TenantmanagementmoduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
