package com.example.tenantmanagementmodule.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Data
public class Tenant {
    @Id
    @Column(name = "tenantID")
    private String tenantID;

    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

//    @OneToMany(mappedBy = "tenant", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    private List<MaintenanceRequest> requests;
    
//    @OneToMany(mappedBy = "tenant", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    private List<Lease> leases;
    
    @OneToMany(mappedBy = "tenant", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Interest> interests;

    @Column(name = "name")
    private String name;

    @Column(name = "contactNo", unique = true)
    private String contactNo;

    @Column(name = "email", unique = true)
    private String email;

    @Column(name = "gender")
    private String gender;

    @PrePersist
    public void onCreate() {
        //this.tenantID = UUID.randomUUID().toString();
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void updateAtMethod() {
        this.updatedAt = LocalDateTime.now();
    }
}