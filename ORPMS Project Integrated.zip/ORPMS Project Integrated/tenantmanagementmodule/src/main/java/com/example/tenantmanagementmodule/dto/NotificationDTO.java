package com.example.tenantmanagementmodule.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


@Data
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown=true)
public class NotificationDTO {
	
	@NotNull
    private UUID notificationID;
    
    @NotNull(message="TenantID must not be Null")
    private UUID tenantID;
    
    @NotNull(message="Message must not be Null")
    @NotBlank(message="Message must not be blank")
    private String message;
    
    @NotNull(message="Date must not be Null")
    private LocalDateTime generatedDate;
    
}