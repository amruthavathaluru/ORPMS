package com.example.tenantmanagementmodule.service;

import com.example.tenantmanagementmodule.dao.InterestRepository;
import com.example.tenantmanagementmodule.dao.TenantRepository;
import com.example.tenantmanagementmodule.dto.LeaseDTO;
import com.example.tenantmanagementmodule.dto.NotificationDTO;
import com.example.tenantmanagementmodule.dto.TenantDTO;
import com.example.tenantmanagementmodule.dto.TenantProfileDTO;
import com.example.tenantmanagementmodule.entity.Tenant;
import com.example.tenantmanagementmodule.exceptions.DuplicateTenantException;
import com.example.tenantmanagementmodule.exceptions.TenantNotFoundException;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service class for managing tenant-related operations.
 */
@Slf4j
@Service
public class TenantService {

    @Autowired
    private TenantRepository tenantRepository;

    @Autowired
    private InterestRepository interestRepository;


    /**
     * Registers a new tenant.
     *
     * @param tenantDTO The TenantDTO containing tenant details.
     * @return The saved TenantDTO.
     * @throws DuplicateTenantException if tenant already exists.
     */
    public TenantDTO registerTenant(TenantDTO tenantDTO) {
        log.info("Registering new tenant: {}", tenantDTO);
        try {
            Tenant tenant = convertToEntity(tenantDTO);
            Tenant savedTenant = tenantRepository.save(tenant);
            log.info("Tenant registered successfully: {}", savedTenant.getTenantID());
            return convertToDTO(savedTenant);
        } catch (DataIntegrityViolationException e) {
            log.error("Duplicate tenant ID: {}", tenantDTO.getTenantID());
            throw new DuplicateTenantException("Tenant already exists.");
        }
    }

    /**
     * Retrieves tenant profile by ID.
     *
     * @param tenantID The ID of the tenant.
     * @return The TenantProfileDTO containing tenant profile details.
     * @throws TenantNotFoundException If the tenant is not found.
     */
    public TenantProfileDTO getTenantProfileById(String tenantID) {
        log.info("Getting tenant profile for ID: {}", tenantID);
        Optional<Tenant> tenantOptional = tenantRepository.findById(tenantID);
        if (tenantOptional.isPresent()) {
            Tenant tenant = tenantOptional.get();
            TenantProfileDTO tenantProfile = new TenantProfileDTO(tenant);
           // tenantProfile.setLeases(getLeaseDTOsByTenantId(tenantID));
           // tenantProfile.setNotifications(getNotificationDTOsByTenantId(tenantID));
           // tenantProfile.setMaintenanceRequests(getMaintenanceRequestDTOsByTenantId(tenantID));
            return tenantProfile;
        } else {
            log.error("Tenant not found with ID: {}", tenantID);
            throw new TenantNotFoundException("Tenant not found with ID: " + tenantID);
        }
    }

    /**
     * Retrieves all tenants.
     *
     * @return A list of TenantDTO objects.
     */
    public List<TenantDTO> getAllTenants() {
        log.info("Getting all tenants");
        try {
            List<Tenant> tenantList = tenantRepository.findAll();
            log.info("Retrieved {} tenants", tenantList.size());
            return tenantList.stream().map(this::convertToDTO).collect(Collectors.toList());
        } catch (Exception e) {
            log.error("Error getting all tenants: {}", e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Updates tenant details.
     *
     * @param tenantDTO The TenantDTO containing updated tenant details.
     * @return The updated TenantDTO.
     * @throws TenantNotFoundException If the tenant is not found.
     */
    public TenantDTO updateTenantDetails(TenantDTO tenantDTO) {
        log.info("Updating tenant details for ID: {}", tenantDTO.getTenantID());
        Optional<Tenant> tenantOptional = tenantRepository.findById(tenantDTO.getTenantID().toString());
        if (tenantOptional.isPresent()) {
            Tenant existingTenant = tenantOptional.get();
            updateEntityFields(existingTenant, tenantDTO);
            Tenant updatedTenant = tenantRepository.save(existingTenant);
            log.info("Tenant details updated successfully: {}", updatedTenant.getTenantID());
            return convertToDTO(updatedTenant);
        } else {
            log.error("Tenant not found with ID: {}", tenantDTO.getTenantID());
            throw new TenantNotFoundException("Tenant not found with ID: " + tenantDTO.getTenantID());
        }
    }

    /**
     * Deletes a tenant by ID.
     *
     * @param tenantID The ID of the tenant to delete.
     * @return true if the tenant is deleted successfully, false otherwise.
     * @throws TenantNotFoundException If the tenant is not found.
     */
    @Transactional
    public boolean deleteTenantById(String tenantID) {
        interestRepository.deleteByTenantTenantID(tenantID);
        log.info("Deleting tenant with ID: {}", tenantID);
        if (tenantRepository.existsById(tenantID)) {
            tenantRepository.deleteById(tenantID);
            log.info("Tenant deleted successfully: {}", tenantID);
            return true;
        } else {
            log.error("Tenant not found with ID: {}", tenantID);
            throw new TenantNotFoundException("Tenant not found with ID: " + tenantID);
        }
    }

//    /**
//     * Retrieves maintenance requests by tenant ID.
//     *
//     * @param tenantID The ID of the tenant.
//     * @return A list of MaintenanceRequestDTO objects.
//     */
//    public List<MaintenanceRequestDTO> getMaintenanceRequestDTOsByTenantId(String tenantID) {
//        log.info("Getting maintenance requests for tenant ID: {}", tenantID);
//        try {
//            List<MaintenanceRequestDTO> maintenanceRequests = maintenanceRequestServiceClient.getMaintenanceRequestsByTenantId(tenantID);
//            log.info("Retrieved {} maintenance requests", maintenanceRequests.size());
//            return maintenanceRequests;
//        } catch (Exception e) {
//            log.error("Error getting maintenance requests: {}", e.getMessage(), e);
//            throw e;
//        }
//    }

   
   

    private Tenant convertToEntity(TenantDTO dto) {
        Tenant tenant = new Tenant();
        if (dto.getTenantID() != null) {
            tenant.setTenantID(dto.getTenantID().toString());
        }
        tenant.setName(dto.getName());
        tenant.setContactNo(dto.getContactNo());
        tenant.setEmail(dto.getEmail());
        tenant.setGender(dto.getGender());
        return tenant;
    }

    private TenantDTO convertToDTO(Tenant tenant) {
        return new TenantDTO(tenant);
    }

    private void updateEntityFields(Tenant existingTenant, TenantDTO dto) {
        if (dto.getName() != null) {
            existingTenant.setName(dto.getName());
        }
        if (dto.getContactNo() != null) {
            existingTenant.setContactNo(dto.getContactNo());
        }
        if (dto.getEmail() != null) {
            existingTenant.setEmail(dto.getEmail());
        }
        if (dto.getGender() != null) {
            existingTenant.setGender(dto.getGender());
        }
    }
}