package com.example.tenantmanagementmodule.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Data
public class Interest {
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Id
    private String interestID;

    private String propertyID;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tenantID", nullable = false)
    private Tenant tenant;

    @Column(name = "interestStatus")
    @Enumerated(EnumType.STRING)
    private InterestStatus status = InterestStatus.submitted;

    @PrePersist
    public void onCreate() {
        this.interestID = UUID.randomUUID().toString();
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void updateAtMethod() {
        this.updatedAt = LocalDateTime.now();
    }
}