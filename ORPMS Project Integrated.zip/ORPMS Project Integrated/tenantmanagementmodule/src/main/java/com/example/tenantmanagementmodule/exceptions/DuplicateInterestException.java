package com.example.tenantmanagementmodule.exceptions;

public class DuplicateInterestException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public DuplicateInterestException(String message)
	{
		super(message);
	}

}
