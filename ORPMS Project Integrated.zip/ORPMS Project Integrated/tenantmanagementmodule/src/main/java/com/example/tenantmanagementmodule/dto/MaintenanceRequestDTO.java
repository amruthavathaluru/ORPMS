package com.example.tenantmanagementmodule.dto;


import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown=true)
public class MaintenanceRequestDTO {
	@NotNull
    private UUID requestID;
    
    @NotNull(message="TenantID must not be Null")
    private UUID tenantID;
    
    @NotNull(message="PropertyID must not be Null")
    private UUID propertyID;
    
    @NotNull(message="IssueDescription must not be Null")
    @NotBlank(message="IssueDescription must not be blank")
    private String issueDescription;
    
   
}