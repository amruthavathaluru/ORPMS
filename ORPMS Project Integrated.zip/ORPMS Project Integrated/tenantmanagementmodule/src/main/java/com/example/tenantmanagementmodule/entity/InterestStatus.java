package com.example.tenantmanagementmodule.entity;

public enum InterestStatus {
	submitted,
	accepted,
	rejected;
}