package com.example.tenantmanagementmodule.utils;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Builder
public class ResultResponse<T> {

    private boolean success;
    private String message;
    private T data;
    private LocalDateTime timestamp;

    public static <T> ResultResponseBuilder<T> builder() {
        return new ResultResponseBuilder<>();
    }

    public static class ResultResponseBuilder<T> {
        private boolean success;
        private String message;
        private T data;
        private LocalDateTime timestamp;

        ResultResponseBuilder() {
        }

        public ResultResponseBuilder<T> success(boolean success) {
            this.success = success;
            return this;
        }

        public ResultResponseBuilder<T> message(String message) {
            this.message = message;
            return this;
        }

        public ResultResponseBuilder<T> data(T data) {
            this.data = data;
            return this;
        }

        public ResultResponseBuilder<T> timestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public ResultResponse<T> build() {
            return new ResultResponse<>(success, message, data, timestamp);
        }

        public String toString() {
            return "ResultResponse.ResultResponseBuilder(success=" + this.success + ", message=" + this.message + ", data=" + this.data + ", timestamp=" + this.timestamp + ")";
        }
    }
}