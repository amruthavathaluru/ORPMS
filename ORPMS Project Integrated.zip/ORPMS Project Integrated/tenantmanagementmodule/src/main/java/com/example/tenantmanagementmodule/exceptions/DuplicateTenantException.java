package com.example.tenantmanagementmodule.exceptions;

public class DuplicateTenantException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public DuplicateTenantException(String message)
	{
		super(message);
	}

}
