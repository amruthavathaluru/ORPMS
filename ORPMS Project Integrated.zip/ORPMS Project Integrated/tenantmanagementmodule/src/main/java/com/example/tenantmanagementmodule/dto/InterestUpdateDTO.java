package com.example.tenantmanagementmodule.dto;

import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.example.tenantmanagementmodule.entity.Interest;
import com.example.tenantmanagementmodule.entity.InterestStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class InterestUpdateDTO {

    @NotNull(message = "Interest ID cannot be null")
    private UUID interestID;

    @NotNull(message = "InterestStatus cannot be null")
    private InterestStatus status;

    public InterestUpdateDTO(Interest interest) {
        this.interestID = UUID.fromString(interest.getInterestID());
        this.status = interest.getStatus();
    }
}