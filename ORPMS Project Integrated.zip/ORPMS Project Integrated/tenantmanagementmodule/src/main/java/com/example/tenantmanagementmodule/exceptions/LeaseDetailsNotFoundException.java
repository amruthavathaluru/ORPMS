package com.example.tenantmanagementmodule.exceptions;

public class LeaseDetailsNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public LeaseDetailsNotFoundException(String message)
	{
		super(message);
	}
}