package com.example.tenantmanagementmodule.dao;

import com.example.tenantmanagementmodule.entity.Tenant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface TenantRepository extends JpaRepository<Tenant, String> {

    Optional<Tenant> findById(String tenantID);

    boolean existsById(String tenantID);

    void deleteById(String tenantID);
}