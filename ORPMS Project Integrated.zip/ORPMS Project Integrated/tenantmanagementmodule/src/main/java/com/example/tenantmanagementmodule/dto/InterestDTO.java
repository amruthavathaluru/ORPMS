package com.example.tenantmanagementmodule.dto;

import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.example.tenantmanagementmodule.entity.Interest;
import com.example.tenantmanagementmodule.entity.InterestStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class InterestDTO {

    private UUID interestID;

    @NotNull(message = "Tenant ID cannot be null")
    private UUID tenantID;

    @NotNull(message = "Property ID cannot be null")
    private UUID propertyID;

    private InterestStatus status=InterestStatus.submitted;

    public InterestDTO(Interest interest) {
        this.interestID = UUID.fromString(interest.getInterestID());
        this.tenantID = UUID.fromString(interest.getTenant().getTenantID());
        this.propertyID = UUID.fromString(interest.getPropertyID());
        this.status = interest.getStatus();
    }
}