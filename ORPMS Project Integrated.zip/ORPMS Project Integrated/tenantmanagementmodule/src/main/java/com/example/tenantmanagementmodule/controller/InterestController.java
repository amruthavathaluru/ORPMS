package com.example.tenantmanagementmodule.controller;

import com.example.tenantmanagementmodule.dto.InterestDTO;
import com.example.tenantmanagementmodule.dto.InterestUpdateDTO;
import com.example.tenantmanagementmodule.exceptions.DuplicateInterestException;
import com.example.tenantmanagementmodule.exceptions.InterestNotFoundException;
import com.example.tenantmanagementmodule.exceptions.PropertyNotFoundException;
import com.example.tenantmanagementmodule.exceptions.TenantNotFoundException;
import com.example.tenantmanagementmodule.exceptions.UnauthorizedAccessException;
import com.example.tenantmanagementmodule.service.InterestService;
import com.example.tenantmanagementmodule.utils.ResultResponse;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * REST controller for managing tenant interests.
 */
@Slf4j
@RestController
@RequestMapping("/interest")
public class InterestController {

    @Autowired
    private InterestService interestService;

    /**
     * Records a new interest.
     *
     * @param interestDTO The InterestDTO containing the details of the interest.
     * @return ResponseEntity containing the recorded InterestDTO or an error response.
     */
    @PostMapping("/post")
    public ResponseEntity<ResultResponse<InterestDTO>> recordInterest(@RequestBody InterestDTO interestDTO) {
        log.info("Received request to record interest: {}", interestDTO);
        try {
            InterestDTO recordedInterest = interestService.recordInterest(interestDTO);
            log.info("Interest recorded successfully: {}", recordedInterest);
            return ResponseEntity.ok(ResultResponse.<InterestDTO>builder()
                    .success(true)
                    .data(recordedInterest)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (TenantNotFoundException | PropertyNotFoundException e) {
            log.error("Error recording interest: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Resource not found.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (DuplicateInterestException e) {
            log.error("Duplicate interest error: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Interest already exists.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error recording interest: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Updates the status of an existing interest.
     *
     * @param updateDTO The InterestUpdateDTO containing the updated status.
     * @param ownerId   The ID of the owner making the update.
     * @return ResponseEntity containing the updated InterestDTO or an error response.
     */
    @PutMapping("/update")
    public ResponseEntity<ResultResponse<InterestDTO>> updateInterestStatus(
            @Valid @RequestBody InterestUpdateDTO updateDTO,
            @RequestParam("ownerId") UUID ownerId) {
        log.info("Received request to update interest status: {}", updateDTO);

        // Validation for UUIDs will be handled by GlobalExceptionHandler

        try {
            InterestDTO updatedInterest = interestService.updateInterestStatus(updateDTO, ownerId);
            log.info("Interest status updated successfully: {}", updatedInterest);
            return ResponseEntity.ok(ResultResponse.<InterestDTO>builder()
                    .success(true)
                    .data(updatedInterest)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (InterestNotFoundException e) {
            log.error("Error updating interest status: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Interest not found.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (UnauthorizedAccessException e) {
            log.error("Unauthorized access to update interest status: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Unauthorized access.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error updating interest status: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Retrieves an interest by its ID.
     *
     * @param interestID The ID of the interest to retrieve.
     * @return ResponseEntity containing the retrieved InterestDTO or an error response.
     */
    @GetMapping("/{interestID}")
    public ResponseEntity<ResultResponse<InterestDTO>> getInterestById(@PathVariable String interestID) {
        log.info("Received request to get interest by ID: {}", interestID);

        // Validation for UUIDs will be handled by GlobalExceptionHandler

        try {
            InterestDTO interestDTO = interestService.getInterestById(interestID);
            log.info("Interest found: {}", interestDTO);
            return ResponseEntity.ok(ResultResponse.<InterestDTO>builder()
                    .success(true)
                    .data(interestDTO)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (InterestNotFoundException e) {
            log.error("Error getting interest by ID: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Interest not found.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting interest by ID: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
}