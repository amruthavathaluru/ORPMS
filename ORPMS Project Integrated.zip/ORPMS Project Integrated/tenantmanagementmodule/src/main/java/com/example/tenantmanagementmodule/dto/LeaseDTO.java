package com.example.tenantmanagementmodule.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;


@Data
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown=true)
public class LeaseDTO {

    @NotNull
    private UUID leaseID;

    @NotNull
    private UUID propertyID;

    @NotNull
    private UUID tenantID;

    @NotNull(message = "Lease Start date must not be null")
    private LocalDate startDate;

    @NotNull(message = "Lease End date must not be null")
    private LocalDate endDate;

    @Positive(message = "Rent amount must be a positive number")
    private double rentAmount;

}