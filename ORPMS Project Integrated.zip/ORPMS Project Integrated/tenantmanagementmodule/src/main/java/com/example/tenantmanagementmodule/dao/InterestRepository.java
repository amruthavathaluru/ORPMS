package com.example.tenantmanagementmodule.dao;

import com.example.tenantmanagementmodule.entity.Interest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InterestRepository extends JpaRepository<Interest, String> {

    Optional<Interest> findByTenant_TenantIDAndPropertyID(String tenantID, String propertyID);

    Optional<Interest> findById(String interestID);
    
    void deleteByTenantTenantID(String tenantID);
}