package com.example.tenantmanagementmodule.controller;

import com.example.tenantmanagementmodule.dto.TenantDTO;
import com.example.tenantmanagementmodule.dto.TenantProfileDTO;
import com.example.tenantmanagementmodule.exceptions.DuplicateTenantException;
import com.example.tenantmanagementmodule.exceptions.TenantNotFoundException;
import com.example.tenantmanagementmodule.service.TenantService;
import com.example.tenantmanagementmodule.utils.ResultResponse;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Slf4j
@RestController
@RequestMapping("/tenant")
public class TenantController {

    @Autowired
    private TenantService tenantService;

    @PostMapping("/register")
    public ResponseEntity<ResultResponse<TenantDTO>> registerTenant(@Valid @RequestBody TenantDTO tenantDTO) {
        log.info("Registering tenant: {}", tenantDTO);
        try {
            TenantDTO registeredTenant = tenantService.registerTenant(tenantDTO);
            return ResponseEntity.ok(ResultResponse.<TenantDTO>builder()
                    .success(true)
                    .data(registeredTenant)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (DuplicateTenantException e) {
            log.error("Duplicate tenant: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<TenantDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error registering tenant: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<TenantDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @GetMapping("/profile/{tenantID}")
    public ResponseEntity<ResultResponse<TenantProfileDTO>> getTenantProfile(@PathVariable String tenantID) {
        log.info("Getting tenant profile for ID: {}", tenantID);
        try {
            UUID.fromString(tenantID); // Validate UUID format
            TenantProfileDTO tenantProfile = tenantService.getTenantProfileById(tenantID);
            return ResponseEntity.ok(ResultResponse.<TenantProfileDTO>builder()
                    .success(true)
                    .data(tenantProfile)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ResultResponse.<TenantProfileDTO>builder()
                    .success(false)
                    .message("Invalid UUID format")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (TenantNotFoundException e) {
            log.error("Tenant not found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<TenantProfileDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting tenant profile: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<TenantProfileDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @GetMapping("/all")
    public ResponseEntity<ResultResponse<List<TenantDTO>>> getAllTenants() {
        log.info("Getting all tenants");
        try {
            List<TenantDTO> tenants = tenantService.getAllTenants();
            return ResponseEntity.ok(ResultResponse.<List<TenantDTO>>builder()
                    .success(true)
                    .data(tenants)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting all tenants: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<TenantDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @PutMapping("/update/{tenantID}")
    public ResponseEntity<ResultResponse<TenantDTO>> updateTenant(@PathVariable String tenantID, @Valid @RequestBody TenantDTO tenantDTO) {
        log.info("Updating tenant with ID: {}", tenantID);
        try {
            UUID.fromString(tenantID); // Validate UUID format
            tenantDTO.setTenantID(UUID.fromString(tenantID));
            TenantDTO updatedTenant = tenantService.updateTenantDetails(tenantDTO);
            return ResponseEntity.ok(ResultResponse.<TenantDTO>builder()
                    .success(true)
                    .data(updatedTenant)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ResultResponse.<TenantDTO>builder()
                    .success(false)
                    .message("Invalid UUID format")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (TenantNotFoundException e) {
            log.error("Tenant not found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<TenantDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error updating tenant: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<TenantDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @DeleteMapping("/delete/{tenantID}")
    public ResponseEntity<ResultResponse<Void>> deleteTenant(@PathVariable String tenantID) {
        log.info("Deleting tenant with ID: {}", tenantID);
        try {
            UUID.fromString(tenantID); // Validate UUID format
            boolean deleted = tenantService.deleteTenantById(tenantID);
            if (deleted) {
                return ResponseEntity.ok(ResultResponse.<Void>builder()
                        .success(true)
                        .timestamp(LocalDateTime.now())
                        .build());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
                        .success(false)
                        .message("Tenant not found")
                        .timestamp(LocalDateTime.now())
                        .build());
            }
        } 
        catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(ResultResponse.<Void>builder()
                    .success(false)
                    .message("Invalid UUID format")
                    .timestamp(LocalDateTime.now())
                    .build());
        } 
        catch (TenantNotFoundException e) {
            log.error("Tenant not found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

   
}