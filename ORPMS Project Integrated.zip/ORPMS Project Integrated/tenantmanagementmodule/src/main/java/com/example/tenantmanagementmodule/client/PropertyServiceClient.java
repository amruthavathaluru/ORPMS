package com.example.tenantmanagementmodule.client; // Adjust package name

import java.util.UUID;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.tenantmanagementmodule.dto.PropertyDTO; // Assuming you have a PropertyDTO
import com.example.tenantmanagementmodule.utils.ResultResponse;

@FeignClient(name = "propertylisting")
public interface PropertyServiceClient {

    @GetMapping("/properties/{propertyId}")
    ResponseEntity<ResultResponse<PropertyDTO>> getPropertyById(@PathVariable("propertyId") UUID propertyId);
    //response entity should be returned in other module
   // ResponseEntity<PropertyDTO>
}