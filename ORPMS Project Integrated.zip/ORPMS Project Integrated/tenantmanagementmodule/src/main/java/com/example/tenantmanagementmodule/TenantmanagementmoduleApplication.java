package com.example.tenantmanagementmodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
public class TenantmanagementmoduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TenantmanagementmoduleApplication.class, args);
	}

}
