package com.example.loginmodule.exception;

import com.example.loginmodule.dto.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * GlobalExceptionHandler provides centralized exception handling for the application.
 * It catches various exceptions and returns appropriate HTTP responses with error messages.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Logger for this class.
     */
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handles BadCredentialsException, which occurs when authentication fails due to incorrect credentials.
     *
     * @param ex The BadCredentialsException.
     * @return ResponseEntity containing an error message and HTTP status 401 (Unauthorized).
     */
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ApiResponse<Object>> handleBadCredentialsException(BadCredentialsException ex) {
        logger.error("Bad credentials: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
                new ApiResponse<>(false, "Invalid email or password.", null));
    }

    /**
     * Handles AuthenticationException, which occurs during general authentication failures.
     *
     * @param ex The AuthenticationException.
     * @return ResponseEntity containing an error message and HTTP status 401 (Unauthorized).
     */
    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<ApiResponse<Object>> handleAuthenticationException(AuthenticationException ex) {
        logger.error("Authentication failed: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
                new ApiResponse<>(false, "Authentication failed.", null));
    }

    /**
     * Handles MethodArgumentNotValidException, which occurs when request body validation fails.
     *
     * @param ex The MethodArgumentNotValidException.
     * @return ResponseEntity containing a map of field errors and HTTP status 400 (Bad Request).
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Map<String, String>>> handleValidationException(MethodArgumentNotValidException ex) {
        logger.error("Validation error: {}", ex.getMessage());
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage())
        );
        return ResponseEntity.badRequest().body(new ApiResponse<>(false, "Validation error", errors));
    }

    /**
     * Handles MissingServletRequestParameterException, which occurs when a required request parameter is missing.
     *
     * @param ex The MissingServletRequestParameterException.
     * @return ResponseEntity containing an error message and HTTP status 400 (Bad Request).
     */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ApiResponse<String>> handleMissingServletRequestParameterException(MissingServletRequestParameterException ex) {
        logger.error("Missing request parameter: {}", ex.getMessage());
        return ResponseEntity.badRequest().body(
                new ApiResponse<>(false, "Missing required parameter: " + ex.getParameterName(), null));
    }

    /**
     * Handles MethodArgumentTypeMismatchException, which occurs when a request parameter has an invalid type.
     *
     * @param ex The MethodArgumentTypeMismatchException.
     * @return ResponseEntity containing an error message and HTTP status 400 (Bad Request).
     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ApiResponse<String>> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex) {
        logger.error("Type mismatch: {}", ex.getMessage());
        return ResponseEntity.badRequest().body(
                new ApiResponse<>(false, "Invalid parameter type.", null));
    }

    /**
     * Handles HttpMessageNotReadableException, which occurs when the request body is invalid or unreadable.
     *
     * @param ex The HttpMessageNotReadableException.
     * @return ResponseEntity containing an error message and HTTP status 400 (Bad Request).
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiResponse<String>> handleHttpMessageNotReadableException(HttpMessageNotReadableException ex) {
        logger.error("Invalid request body: {}", ex.getMessage());
        return ResponseEntity.badRequest().body(
                new ApiResponse<>(false, "Invalid request body.", null));
    }

    /**
     * Handles IllegalArgumentException, which occurs when an invalid argument is passed to a method.
     *
     * @param ex The IllegalArgumentException.
     * @return ResponseEntity containing an error message and HTTP status 400 (Bad Request).
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ApiResponse<String>> handleIllegalArgumentException(IllegalArgumentException ex) {
        logger.error("Invalid argument: {}", ex.getMessage());
        return ResponseEntity.badRequest().body(
                new ApiResponse<>(false, "Invalid argument.", null));
    }

    /**
     * Handles UserAlreadyExistsException.
     * @param ex
     * @return
     */
    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<ApiResponse<String>> handleUserAlreadyExistsException(UserAlreadyExistsException ex){
        logger.error("User already exists: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.CONFLICT).body(new ApiResponse<>(false, ex.getMessage(), null));
    }

    /**
     * Handles UserNotFoundException.
     * @param ex
     * @return
     */
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ApiResponse<String>> handleUserNotFoundException(UserNotFoundException ex){
        logger.error("User not found: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse<>(false, ex.getMessage(), null));
    }

    /**
     * Handles generic Exception, which catches any unhandled exceptions.
     *
     * @param ex The Exception.
     * @return ResponseEntity containing an error message and HTTP status 500 (Internal Server Error).
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<String>> handleGenericException(Exception ex) {
        logger.error("Internal server error: {}", ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                new ApiResponse<>(false, "Internal server error.", null));
    }
}