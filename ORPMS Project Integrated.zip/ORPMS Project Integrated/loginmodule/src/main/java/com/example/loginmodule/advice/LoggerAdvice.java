package com.example.loginmodule.advice;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * LoggerAdvice is an AspectJ aspect that provides logging functionality for application methods.
 * It logs the entry and exit points of methods in the service and controller layers.
 */
@Aspect
@Component
public class LoggerAdvice {

    /**
     * Logger for this class.
     */
    private static final Logger log = LoggerFactory.getLogger(LoggerAdvice.class);

    /**
     * Pointcut definition for methods in the service and controller packages.
     * This pointcut targets all methods in the service and controller packages.
     */
    @Pointcut(value = "execution(* com.example.loginmodule.service.*.*(..)) || execution(* com.example.loginmodule.controller.*.*(..))")
    public void pointCut() {
        // Pointcut method, implementation is empty as it's only used to define the pointcut
    }

    /**
     * Advice that logs the entry and exit of methods matching the pointcut.
     *
     * @param joinPoint The ProceedingJoinPoint representing the method execution.
     * @return The result of the method execution.
     * @throws Throwable If an exception occurs during method execution.
     */
    @Around("pointCut()")
    public Object applicationLogger(ProceedingJoinPoint joinPoint) throws Throwable {
        // Get the class name and method name from the join point
        String className = joinPoint.getTarget().getClass().toString();
        String methodName = joinPoint.getSignature().getName();

        // Log the entry of the method
        log.info("{}::{}: Entry", className, methodName);

        // Proceed with the method execution
        Object obj = joinPoint.proceed();

        // Log the exit of the method
        log.info("{}::{}: Exit", className, methodName);

        // Return the result of the method execution
        return obj;
    }
}