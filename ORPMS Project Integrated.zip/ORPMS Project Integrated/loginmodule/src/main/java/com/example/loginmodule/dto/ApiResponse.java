package com.example.loginmodule.dto;

import lombok.Data;

/**
 * ApiResponse is a generic DTO used to encapsulate API responses.
 * It provides a consistent structure for returning success status, messages, and data.
 *
 * @param <T> The type of the data contained in the response.
 */
@Data
public class ApiResponse<T> {

    /**
     * Indicates whether the API request was successful.
     */
    private boolean success;

    /**
     * A message providing additional information about the API response.
     */
    private String message;

    /**
     * The data returned by the API.
     */
    private T data;

    /**
     * Constructs an ApiResponse with success status, message, and data.
     *
     * @param success Indicates whether the API request was successful.
     * @param message A message providing additional information.
     * @param data    The data returned by the API.
     */
    public ApiResponse(boolean success, String message, T data) {
        this.success = success;
        this.message = message;
        this.data = data;
    }

    /**
     * Constructs an ApiResponse with success status and message.
     * This constructor is used when there is no data to return.
     *
     * @param success Indicates whether the API request was successful.
     * @param message A message providing additional information.
     */
    public ApiResponse(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    /**
     * Default constructor for ApiResponse.
     */
    public ApiResponse() {
    }
}