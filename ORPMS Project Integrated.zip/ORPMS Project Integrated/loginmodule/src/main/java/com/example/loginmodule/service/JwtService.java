package com.example.loginmodule.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * JwtService provides functionalities for generating, extracting, and validating JWT tokens.
 * It is used for authentication and authorization purposes.
 */
@Service
@Slf4j
public class JwtService {

    /**
     * Expiration time for JWT tokens in milliseconds (1 hour).
     */
    private static final long EXPIRATION_MS = 3600000; // 1 hour

    /**
     * Secret key for signing and verifying JWT tokens.
     */
    private final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS512);

    /**
     * Generates a JWT token for the given userId and email.
     *
     * @param userId The user ID for which the token is generated.
     * @param email  The email for which the token is generated.
     * @return The generated JWT token.
     */
    public String generateToken(String userId, String email) {
        log.info("Generating token for userId: {} and email: {}", userId, email);
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + EXPIRATION_MS);

        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", userId); // Add userId to claims

        String token = Jwts.builder()
                .setClaims(claims) // Add claims
                .setSubject(email)
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(key, SignatureAlgorithm.HS512)
                .compact();

        log.info("Token generated successfully for userId: {} and email: {}", userId, email);
        return token;
    }

    /**
     * Extracts the username (email) from the given JWT token.
     *
     * @param token The JWT token from which to extract the username.
     * @return The extracted username (email).
     */
    public String extractUserName(String token) {
        log.info("Extracting username from token");
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();

        String username = claims.getSubject();
        log.info("Username extracted: {}", username);
        return username;
    }

    /**
     * Validates the given JWT token against the user details.
     *
     * @param token     The JWT token to validate.
     * @param userDetails The user details to validate against.
     * @return True if the token is valid, false otherwise.
     */
    public boolean validateToken(String token, UserDetails userDetails) {
        log.info("Validating token for user: {}", userDetails.getUsername());
        final String email = extractUserName(token);
        boolean isValid = (email.equals(userDetails.getUsername()) && !isTokenExpired(token));
        log.info("Token validation result: {}", isValid);
        return isValid;
    }

    /**
     * Extracts all claims from the given JWT token.
     *
     * @param token The JWT token from which to extract claims.
     * @return The extracted claims.
     */
    private Claims extractAllClaims(String token) {
        log.info("Extracting all claims from token");
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
        log.info("All claims extracted");
        return claims;
    }

    /**
     * Extracts the expiration date from the given JWT token.
     *
     * @param token The JWT token from which to extract the expiration date.
     * @return The extracted expiration date.
     */
    private Date extractExpiration(String token) {
        log.info("Extracting token expiration");
        Claims claims = extractAllClaims(token);
        Date expiration = claims.getExpiration();
        log.info("Token expiration extracted: {}", expiration);
        return expiration;
    }

    /**
     * Checks if the given JWT token is expired.
     *
     * @param token The JWT token to check.
     * @return True if the token is expired, false otherwise.
     */
    public boolean isTokenExpired(String token) {
        log.info("Checking if token is expired");
        boolean isExpired = extractExpiration(token).before(new Date());
        log.info("Token is expired: {}", isExpired);
        return isExpired;
    }

    /**
     * Extracts the userId from the given JWT token.
     *
     * @param token The JWT token from which to extract the user ID.
     * @return The extracted user ID.
     */
    public String extractUserId(String token) {
        log.info("Extracting userId from token");
        Claims claims = extractAllClaims(token);
        String userId = claims.get("userId", String.class);
        log.info("userId extracted: {}", userId);
        return userId;
    }
}