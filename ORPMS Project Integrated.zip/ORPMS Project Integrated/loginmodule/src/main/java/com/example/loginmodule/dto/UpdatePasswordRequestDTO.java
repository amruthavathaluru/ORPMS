package com.example.loginmodule.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * PasswordUpdateRequestDTO represents the data required to update a user's password.
 * It includes the user's email and the new password.
 */
@Data
public class UpdatePasswordRequestDTO {

    /**
     * The email address of the user whose password is to be updated.
     * Must be a valid email address and cannot be blank.
     */
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Invalid email format")
    private String email;

    /**
     * The new password to be set for the user.
     * Cannot be blank.
     */
    @NotBlank(message = "Password cannot be blank")
    private String newPassword;
}