package com.example.loginmodule.dto;

import com.example.loginmodule.enums.UserType;
import lombok.Data;

/**
 * DTO for user registration requests.
 */
@Data
public class RegisterRequestFullDTO {
    private String email;
    private String password;
    private UserType userType;
    private Object details;
}