package com.example.loginmodule.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.Builder;
import java.time.LocalDateTime;
import java.util.UUID;

import com.example.loginmodule.enums.UserType;

/**
 * Represents a user in the system, which can be either an owner or a tenant.
 * This entity maps to the 'users' table in the database.
 */
@Entity
@Table(name = "users")
@Data
@Builder
@AllArgsConstructor
public class User {

    /**
     * The unique identifier for the user.
     * It is generated as a UUID and stored as a string.
     */
    @Id
    private String userId;

    /**
     * The timestamp indicating when the user account was created.
     */
    @Column(name = "createdAt")
    private LocalDateTime createdAt;

    /**
     * The timestamp indicating when the user account was last updated.
     */
    @Column(name = "updatedAt")
    private LocalDateTime updatedAt;

    /**
     * The email address of the user.
     * It must be unique across all users.
     */
    @Column(unique = true)
    private String email;

    /**
     * The hashed password of the user.
     * Passwords should always be stored in an encoded form for security.
     */
    private String password;

    /**
     * The type of user: "OWNER" or "TENANT".
     * This field is used to differentiate between different types of users.
     */
    @Column(nullable = false)
    @Enumerated(EnumType.STRING) // Store enum as string in DB
    private UserType userType; // Use UserType enu
    /**
     * Pre-persist lifecycle callback method.
     * It generates a UUID for the userId and sets the createdAt and updatedAt timestamps.
     * This method is automatically called before the entity is persisted to the database.
     */
    @PrePersist
    public void onCreate() {
        this.userId = UUID.randomUUID().toString();
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Pre-update lifecycle callback method.
     * It updates the updatedAt timestamp.
     * This method is automatically called before the entity is updated in the database.
     */
    @PreUpdate
    public void updateAtMethod() {
        this.updatedAt = LocalDateTime.now();
    }
    
    public User() {
    }
}