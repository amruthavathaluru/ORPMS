package com.example.loginmodule.exception;

/**
 * UserNotFoundException is a custom exception that is thrown when a user is not found.
 * It extends RuntimeException, making it an unchecked exception.
 */
public class UserNotFoundException extends RuntimeException {

    /**
     * Serial version UID for serialization.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new UserNotFoundException with the specified detail message.
     *
     * @param message The detail message explaining the reason for the exception.
     */
    public UserNotFoundException(String message) {
        super(message);
    }
}