package com.example.loginmodule.enums;

/**
 * Enumeration representing the types of users in the system.
 */
public enum UserType {

    /**
     * Represents an owner user.
     */
    OWNER,

    /**
     * Represents a tenant user.
     */
    TENANT
}