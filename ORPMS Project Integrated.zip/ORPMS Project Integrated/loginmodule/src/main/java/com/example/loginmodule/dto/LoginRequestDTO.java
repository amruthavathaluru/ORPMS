package com.example.loginmodule.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * LoginRequestDTO represents the data required for user login.
 * It includes the user's email and password.
 */
@Data
public class LoginRequestDTO {

    /**
     * The email address of the user attempting to log in.
     * Must be a valid email address and cannot be blank.
     */
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Invalid email format")
    private String email;

    /**
     * The password of the user attempting to log in.
     * Cannot be blank.
     */
    @NotBlank(message = "Password cannot be blank")
    private String password;
}