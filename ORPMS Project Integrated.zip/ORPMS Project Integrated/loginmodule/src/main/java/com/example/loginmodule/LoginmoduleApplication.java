package com.example.loginmodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Main application class for the Login Module service.
 * This class is responsible for bootstrapping the Spring Boot application.
 * It also enables discovery client and Feign clients for microservice communication.
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
public class LoginmoduleApplication {

    /**
     * Main method to start the Spring Boot application.
     *
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        SpringApplication.run(LoginmoduleApplication.class, args);
    }
}