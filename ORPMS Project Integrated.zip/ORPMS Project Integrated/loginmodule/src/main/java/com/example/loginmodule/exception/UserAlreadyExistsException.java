package com.example.loginmodule.exception;

/**
 * UserAlreadyExistsException is a custom exception that is thrown when a user with the given email already exists.
 * It extends RuntimeException, making it an unchecked exception.
 */
public class UserAlreadyExistsException extends RuntimeException {

    /**
     * Serial version UID for serialization.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new UserAlreadyExistsException with the specified detail message.
     *
     * @param message The detail message explaining that a user with the given email already exists.
     */
    public UserAlreadyExistsException(String message) {
        super(message);
    }
}