package com.example.loginmodule.dto;

import lombok.Data;

/**
 * AuthenticationResponse represents the response containing the authentication token.
 * It is used to return the JWT token after successful user login.
 */
@Data
public class AuthenticationResponse {

    /**
     * The JWT authentication token.
     */
    private String token;
}