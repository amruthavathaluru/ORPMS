package com.example.loginmodule.dto;

import com.example.loginmodule.enums.UserType;
import lombok.Data;

/**
 * DTO for user representation in responses.
 */
@Data
public class UserDTO {
    private String userId;
    private String email;
    private UserType userType;
}