package com.example.loginmodule.utils;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * ResultResponse is a generic utility class for constructing API responses.
 * It provides a consistent structure for returning success status, messages, data, and a timestamp.
 *
 * @param <T> The type of the data contained in the response.
 */
@Data
@Builder
public class ResultResponse<T> {

    /**
     * Indicates whether the operation was successful.
     */
    private boolean success;

    /**
     * A message providing additional information about the result.
     */
    private String message;

    /**
     * The data returned as a result of the operation.
     */
    private T data;

    /**
     * The timestamp indicating when the response was created.
     */
    private LocalDateTime timestamp;

    /**
     * Returns a new ResultResponseBuilder instance.
     * This method is used to create a builder for constructing ResultResponse objects.
     *
     * @param <T> The type of the data contained in the response.
     * @return A new ResultResponseBuilder instance.
     */
    public static <T> ResultResponseBuilder<T> builder() {
        return new ResultResponseBuilder<>();
    }

    /**
     * Creates a successful ResultResponse with the given data and message.
     *
     * @param data    The data to be included in the response.
     * @param message The message to be included in the response.
     * @param <T>     The type of the data.
     * @return A ResultResponse object.
     */
    public static <T> ResultResponse<T> success(T data, String message) {
        return ResultResponse.<T>builder()
                .success(true)
                .data(data)
                .message(message)
                .timestamp(LocalDateTime.now())
                .build();
    }

    /**
     * Creates an error ResultResponse with the given message.
     *
     * @param message The error message to be included in the response.
     * @param <T>     The type of the data (can be Object or any other type).
     * @return A ResultResponse object.
     */
    public static <T> ResultResponse<T> error(String message) {
        return ResultResponse.<T>builder()
                .success(false)
                .message(message)
                .timestamp(LocalDateTime.now())
                .build();
    }

    /**
     * ResultResponseBuilder is a builder class for constructing ResultResponse objects.
     * It allows for fluent setting of the response's properties.
     *
     * @param <T> The type of the data contained in the response.
     */
    public static class ResultResponseBuilder<T> {
        private boolean success;
        private String message;
        private T data;
        private LocalDateTime timestamp;

        /**
         * Default constructor for ResultResponseBuilder.
         */
        ResultResponseBuilder() {
        }

        /**
         * Sets the success status of the response.
         *
         * @param success Indicates whether the operation was successful.
         * @return The ResultResponseBuilder instance.
         */
        public ResultResponseBuilder<T> success(boolean success) {
            this.success = success;
            return this;
        }

        /**
         * Sets the message of the response.
         *
         * @param message A message providing additional information.
         * @return The ResultResponseBuilder instance.
         */
        public ResultResponseBuilder<T> message(String message) {
            this.message = message;
            return this;
        }

        /**
         * Sets the data of the response.
         *
         * @param data The data returned as a result of the operation.
         * @return The ResultResponseBuilder instance.
         */
        public ResultResponseBuilder<T> data(T data) {
            this.data = data;
            return this;
        }

        /**
         * Sets the timestamp of the response.
         *
         * @param timestamp The timestamp indicating when the response was created.
         * @return The ResultResponseBuilder instance.
         */
        public ResultResponseBuilder<T> timestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        /**
         * Builds and returns a new ResultResponse object.
         *
         * @return A new ResultResponse object with the set properties.
         */
        public ResultResponse<T> build() {
            if (this.timestamp == null) {
                this.timestamp = LocalDateTime.now();
            }
            return new ResultResponse<>(success, message, data, timestamp);
        }

        /**
         * Returns a string representation of the ResultResponseBuilder.
         *
         * @return A string representation of the ResultResponseBuilder.
         */
        public String toString() {
            return "ResultResponse.ResultResponseBuilder(success=" + this.success + ", message=" + this.message + ", data=" + this.data + ", timestamp=" + this.timestamp + ")";
        }
    }
}