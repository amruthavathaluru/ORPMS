package com.example.loginmodule.service;

import com.example.loginmodule.client.OwnerClient;
import com.example.loginmodule.client.TenantClient;
import com.example.loginmodule.dto.OwnerDTO;
import com.example.loginmodule.dto.TenantDTO;
import com.example.loginmodule.entity.User;
import com.example.loginmodule.enums.UserType;
import com.example.loginmodule.entity.UserPrincipal;
import com.example.loginmodule.dao.UserRepository;
import com.example.loginmodule.exception.UserAlreadyExistsException;
import com.example.loginmodule.exception.UserNotFoundException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Lazy
    @Autowired
    private AuthenticationManager authManager;

    @Autowired
    private TenantClient tenantClient;

    @Autowired
    private OwnerClient ownerClient;

    @Transactional
    public User registerUser(String email, String password, UserType userType, Object details) {
        log.info("Registering user with email: {}", email);
        log.debug("Register details - Email: {}, UserType: {}, Details: {}", email, userType, details);

        if (userRepository.findByEmail(email).isPresent()) {
            log.warn("User with email {} already exists", email);
            throw new UserAlreadyExistsException("User with this email already exists!");
        }

        User user = User.builder()
                .email(email)
                .password(passwordEncoder.encode(password))
                .userType(userType)
                .build();

        log.debug("Saving user to repository: {}", user);
        User savedUser = userRepository.save(user);
        log.debug("User saved successfully with ID: {}", savedUser.getUserId());

        try {
            ObjectMapper objectMapper = new ObjectMapper();

            if (userType == UserType.TENANT) {
                TenantDTO tenantDetailsDTO = objectMapper.convertValue(details, TenantDTO.class);
                tenantDetailsDTO.setTenantID(savedUser.getUserId());
                log.debug("Sending tenant registration request: {}", tenantDetailsDTO);
                ResponseEntity<?> response = tenantClient.registerTenant(tenantDetailsDTO);
                log.debug("Tenant registration response: {}", response);

                if (response.getStatusCode() != HttpStatus.OK) {
                    log.error("Failed to register tenant with ID: {}. Response: {}", savedUser.getUserId(), response);
                    throw new RuntimeException("Failed to register tenant");
                }
                log.info("Tenant registered successfully with ID: {}", savedUser.getUserId());
            } else if (userType == UserType.OWNER) {
                OwnerDTO ownerDetailsDTO = objectMapper.convertValue(details, OwnerDTO.class);
                ownerDetailsDTO.setOwnerID(savedUser.getUserId());
                log.debug("Sending owner creation request: {}", ownerDetailsDTO);
                ResponseEntity<?> response = ownerClient.createOwner(ownerDetailsDTO);
                log.debug("Owner creation response: {}", response);

                if (response.getStatusCode() != HttpStatus.OK) {
                    log.error("Failed to create owner with ID: {}. Response: {}", savedUser.getUserId(), response);
                    throw new RuntimeException("Failed to create owner");
                }
                log.info("Owner created successfully with ID: {}", savedUser.getUserId());
            }
        } catch (Exception e) {
            log.error("Error during microservice call: {}", e.getMessage());
            throw e; // Rethrow to rollback transaction
        }

        return savedUser;
    }

    public String loginUser(String email, String password) {
        log.info("Logging in user with email: {}", email);
        log.debug("Attempting authentication for email: {}", email);

        Authentication authentication = authManager
                .authenticate(new UsernamePasswordAuthenticationToken(email, password));

        if (!authentication.isAuthenticated()) {
            log.warn("Invalid login credentials for email: {}", email);
            throw new UserNotFoundException("Invalid Login Credentials!");
        }

        User user = userRepository.findByEmail(email).orElseThrow(() -> {
            log.warn("User not found with email: {}", email);
            return new UserNotFoundException("User not found");
        });

        String token = jwtService.generateToken(user.getUserId(), email);
        log.debug("Generated JWT token for user ID: {}", user.getUserId());
        return token;
    }

    public User updatePassword(String userId, String newPassword) {
        log.info("Updating password for user ID: {}", userId);
        log.debug("Attempting to update password for user ID: {}", userId);

        User user = userRepository.findById(userId).orElseThrow(() -> {
            log.warn("User not found with ID: {}", userId);
            return new UserNotFoundException("User not found");
        });

        user.setPassword(passwordEncoder.encode(newPassword));
        log.debug("Password encoded and set for user ID: {}", userId);

        User updatedUser = userRepository.save(user);
        log.debug("Password updated successfully for user ID: {}", userId);
        return updatedUser;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        log.debug("Loading user by username: {}", username);

        User user = userRepository.findByEmail(username)
                .orElseThrow(() -> {
                    log.warn("User not found with username: {}", username);
                    return new UsernameNotFoundException("User not found: " + username);
                });

        log.debug("User found: {}", user);
        return new UserPrincipal(user);
    }
}