package com.example.loginmodule.client;

import com.example.loginmodule.dto.OwnerDTO;
import com.example.loginmodule.utils.ResultResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Feign client interface for communicating with the propertylisting (owner) microservice.
 */
@FeignClient(name = "propertylisting")
public interface OwnerClient {

    /**
     * Sends an OwnerDTO to the propertylisting microservice to create a new owner.
     *
     * @param ownerDTO The OwnerDTO containing owner details.
     * @return ResponseEntity containing the ResultResponse with OwnerDTO.
     */
    @PostMapping("/owners/create")
    ResponseEntity<ResultResponse<OwnerDTO>> createOwner(@RequestBody OwnerDTO ownerDTO);
}