package com.example.loginmodule.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

/**
 * Data Transfer Object (DTO) representing a Tenant user for registration and information exchange.
 * This DTO includes validation constraints to ensure data integrity.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class TenantDTO {

    /**
     * The unique identifier for the tenant user.
     */
    private String tenantID;

    /**
     * The username of the tenant user.
     */
    private String username;

    /**
     * The name of the tenant user.
     * Must not be blank and must be between 2 and 100 characters.
     */
    @NotBlank(message = "Tenant name cannot be blank")
    @Size(min = 2, max = 100, message = "Tenant name must be between 2 and 100 characters")
    private String name;

    /**
     * The contact number of the tenant user.
     * Must not be blank and must be a 10-digit number.
     */
    @NotBlank(message = "Contact number cannot be blank")
    @Pattern(regexp = "^[1-9][0-9]{9}$", message = "Contact number must be 10 digits")
    private String contactNo;

    /**
     * The email address of the tenant user.
     * Must not be blank and must be a valid email format.
     */
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Invalid email format")
    private String email;

    /**
     * The gender of the tenant user.
     * Must not be blank and must be one of "Male", "Female", or "Other" (case-insensitive).
     */
    @NotBlank(message = "Gender cannot be blank")
    @Pattern(regexp = "(?i)^(Male|Female|Other)$", message = "Gender must be Male, Female, or Other")
    private String gender;
}