package com.example.loginmodule.client;

import com.example.loginmodule.dto.TenantDTO;
import com.example.loginmodule.utils.ResultResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Feign client interface for communicating with the tenantmanagementmodule microservice.
 */
@FeignClient(name = "tenantmanagementmodule")
public interface TenantClient {

    /**
     * Sends a TenantDTO to the tenantmanagementmodule microservice to register a new tenant.
     *
     * @param tenantDTO The TenantDTO containing tenant details.
     * @return ResponseEntity containing the ResultResponse with TenantDTO.
     */
    @PostMapping("/tenant/register")
    ResponseEntity<ResultResponse<TenantDTO>> registerTenant(@RequestBody TenantDTO tenantDTO);
}