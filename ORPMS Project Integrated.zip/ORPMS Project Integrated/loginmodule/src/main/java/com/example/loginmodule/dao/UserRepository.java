package com.example.loginmodule.dao;

import com.example.loginmodule.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for accessing and managing {@link User} entities in the database.
 * This interface extends {@link JpaRepository}, providing standard CRUD operations and
 * additional query methods for the {@link User} entity.
 */
@Repository
public interface UserRepository extends JpaRepository<User, String> {

    /**
     * Finds a user by their email address.
     *
     * @param email The email address of the user to find.
     * @return An {@link Optional} containing the found user, or an empty {@link Optional} if not found.
     */
    Optional<User> findByEmail(String email);

    /**
     * Finds a user by their user ID.
     *
     * @param userId The unique identifier of the user to find.
     * @return An {@link Optional} containing the found user, or an empty {@link Optional} if not found.
     */
    Optional<User> findById(String userId);

}