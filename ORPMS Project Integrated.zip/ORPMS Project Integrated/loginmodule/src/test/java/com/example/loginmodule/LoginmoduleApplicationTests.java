package com.example.loginmodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginmoduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
