package com.example.propertylisting.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
//import java.util.HashSet;
import java.util.List;
//import java.util.Set;
import java.util.UUID;


@Entity
@Data
public class Property {

    @Id
    @Column(name = "propertyID", updatable = false, nullable = false)
    private String propertyID;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ownerID", nullable = false)
    private Owner owner;

//    @Column(name = "ownerID", insertable = false, updatable = false)
//    private String ownerID;

    @Column(name = "tenantID", insertable = false, updatable = false)
    private String tenantID;

    @Column(name = "propertyName", nullable = false)
    private String propertyName;

    @Column(name = "address", nullable = false)
    private String address;

    @Column(name = "type", nullable = false)
    private String type;

    @Column(name = "price", nullable = false)
    private Double price;

    @Column(name = "rentalTerms", nullable = false)
    private String rentalTerms;

    @ElementCollection
    @CollectionTable(name = "property_image_urls", joinColumns = @JoinColumn(name = "propertyID"))
    @Column(name = "image_url", nullable = false)
    @OrderColumn(name = "image_order") // Optional for ordering
    private List<String> imageUrls;

    @Column(name = "availabilityStatus", nullable = false)
    @Enumerated(EnumType.STRING)
    private PropertyAvailabilityStatus availabilityStatus = PropertyAvailabilityStatus.available;

//    @OneToMany(mappedBy = "property", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
//    private List<Lease> leases;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    public void onCreate() {
        this.propertyID = UUID.randomUUID().toString();
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

//    public List<Lease> getLeases() {
//        return leases;
//    }
}
