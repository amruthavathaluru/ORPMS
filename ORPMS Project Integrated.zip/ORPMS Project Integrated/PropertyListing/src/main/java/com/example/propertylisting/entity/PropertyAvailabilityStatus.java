package com.example.propertylisting.entity;
public enum PropertyAvailabilityStatus {
	available,
	rented;
}
