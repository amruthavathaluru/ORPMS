package com.example.propertylisting.controller;

import com.example.propertylisting.dto.PropertyDTO;
import com.example.propertylisting.Service.PropertyService;
import com.example.propertylisting.exception.ResourceNotFoundException;
import com.example.propertylisting.utils.ResultResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.time.LocalDateTime;
import java.util.List;

/**
 * The PropertyController class provides RESTful API endpoints to manage properties.
 * This includes adding, updating, retrieving, deleting, and searching properties with filters.
 */
@RestController
@RequestMapping("/properties")
public class PropertyController {

    private static final Logger logger = LoggerFactory.getLogger(PropertyController.class);

    @Autowired
    private PropertyService propertyService;

    /**
     * Add a new property for a specific owner.
     *
     * @param ownerId      The unique identifier of the owner.
     * @param propertyDTO  The details of the property to be added.
     * @return ResponseEntity containing the added property's details or error message.
     */
    @PostMapping("/owner/{ownerId}")
    public ResponseEntity<ResultResponse<PropertyDTO>> addProperty(@PathVariable String ownerId, @Valid @RequestBody PropertyDTO propertyDTO) {
        logger.info("Adding property for ownerId: {}", ownerId);
        try {
            PropertyDTO addedProperty = propertyService.addProperty(propertyDTO, ownerId);
            return ResponseEntity.ok(ResultResponse.<PropertyDTO>builder()
                    .success(true)
                    .data(addedProperty)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (ResourceNotFoundException e) {
            logger.error("Error adding property: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            logger.error("Unexpected error while adding property: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Retrieve property details by its unique ID.
     *
     * @param propertyId  The unique identifier of the property.
     * @return ResponseEntity containing the property's details or error message.
     */
    @GetMapping("/{propertyId}")
    public ResponseEntity<ResultResponse<PropertyDTO>> getPropertyById(@PathVariable String propertyId) {
        logger.info("Fetching property with ID: {}", propertyId);
        try {
            PropertyDTO property = propertyService.getPropertyById(propertyId);
            return ResponseEntity.ok(ResultResponse.<PropertyDTO>builder()
                    .success(true)
                    .data(property)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (ResourceNotFoundException e) {
            logger.error("Error fetching property: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            logger.error("Unexpected error while fetching property: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Retrieve all properties.
     *
     * @return ResponseEntity containing a list of all properties or an error message.
     */
    @GetMapping
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> getAllProperties() {
        logger.info("Fetching all properties");
        try {
            List<PropertyDTO> properties = propertyService.getAllProperties();
            return ResponseEntity.ok(ResultResponse.<List<PropertyDTO>>builder()
                    .success(true)
                    .data(properties)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            logger.error("Unexpected error while fetching all properties: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<PropertyDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Update the details of a property for a specific owner.
     *
     * @param ownerId      The unique identifier of the owner.
     * @param propertyId   The unique identifier of the property.
     * @param propertyDTO  The updated property details.
     * @return ResponseEntity containing the updated property's details or error message.
     */
    @PutMapping("/owner/{ownerId}/{propertyId}")
    public ResponseEntity<ResultResponse<PropertyDTO>> updateProperty(@PathVariable String ownerId, @PathVariable String propertyId, @Valid @RequestBody PropertyDTO propertyDTO) {
        logger.info("Updating property with ID: {} for ownerId: {}", propertyId, ownerId);
        try {
            PropertyDTO updatedProperty = propertyService.updateProperty(propertyId, propertyDTO, ownerId);
            return ResponseEntity.ok(ResultResponse.<PropertyDTO>builder()
                    .success(true)
                    .data(updatedProperty)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (ResourceNotFoundException e) {
            logger.error("Error updating property: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            logger.error("Unexpected error while updating property: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Delete a property by its unique ID and associated owner.
     *
     * @param ownerId     The unique identifier of the owner.
     * @param propertyId  The unique identifier of the property.
     * @return ResponseEntity with a success or error message.
     */
    @DeleteMapping("/owner/{ownerId}/{propertyId}")
    public ResponseEntity<ResultResponse<Void>> deleteProperty(@PathVariable String ownerId, @PathVariable String propertyId) {
        logger.info("Deleting property with ID: {} for ownerId: {}", propertyId, ownerId);
        try {
            propertyService.deleteProperty(propertyId, ownerId);
            return ResponseEntity.ok(ResultResponse.<Void>builder()
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (ResourceNotFoundException e) {
            logger.error("Error deleting property: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            logger.error("Unexpected error while deleting property: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<Void>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Retrieve all properties associated with a specific owner.
     *
     * @param ownerId  The unique identifier of the owner.
     * @return ResponseEntity containing a list of properties or an error message.
     */
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> getPropertiesByOwner(@PathVariable String ownerId) {
        logger.info("Fetching properties for ownerId: {}", ownerId);
        try {
            List<PropertyDTO> properties = propertyService.getPropertiesByOwner(ownerId);
            return ResponseEntity.ok(ResultResponse.<List<PropertyDTO>>builder()
                    .success(true)
                    .data(properties)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (ResourceNotFoundException e) {
            logger.error("Error fetching properties for ownerId: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<List<PropertyDTO>>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            logger.error("Unexpected error while fetching properties for ownerId: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<PropertyDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Search properties based on filters like location, type, price range, etc.
     *
     * @param location   Optional filter for property location.
     * @param type       Optional filter for property type.
     * @param minPrice   Optional filter for minimum price.
     * @param maxPrice   Optional filter for maximum price.
     * @return ResponseEntity containing filtered properties or error message.
     */
    @GetMapping("/search")
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> searchProperties(
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice) {
        logger.info("Received request to search properties with filters: location={}, type={}, minPrice={}, maxPrice={}", location, type, minPrice, maxPrice);
        try {
            List<PropertyDTO> filteredProperties = propertyService.searchProperties(location, type, minPrice, maxPrice);
            logger.info("Fetched {} properties matching search filters", filteredProperties.size());
            return ResponseEntity.ok(ResultResponse.<List<PropertyDTO>>builder()
                    .success(true)
                    .data(filteredProperties)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            logger.error("Unexpected error while searching properties: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<PropertyDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

}

