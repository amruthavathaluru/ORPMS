package com.example.propertylisting.Service;

import com.example.propertylisting.dto.OwnerDTO;
import org.springframework.transaction.annotation.Transactional;

import com.example.propertylisting.dto.PropertyDTO;
import com.example.propertylisting.dto.RentPaymentDTO;
import com.example.propertylisting.dto.NotificationDTO;
import com.example.propertylisting.entity.Owner;
import com.example.propertylisting.entity.Property;
import com.example.propertylisting.entity.PropertyAvailabilityStatus;
import com.example.propertylisting.exception.DuplicateResourceException;
import com.example.propertylisting.exception.OwnerNotFound;
import com.example.propertylisting.client.RentPaymentClient;
import com.example.propertylisting.dao.OwnerDAO;
import com.example.propertylisting.dao.PropertyDAO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class OwnerServiceImpl implements OwnerService {

    private static final Logger logger = LoggerFactory.getLogger(OwnerServiceImpl.class);

    @Autowired
    private OwnerDAO ownerDAO;

    @Autowired
    private PropertyDAO propertyDAO;

    @Autowired
    private RentPaymentClient rentPaymentClient;

    @Override
    @Transactional
    public OwnerDTO createOwner(OwnerDTO ownerDTO) {
        try {
            Owner owner = new Owner();
            owner.setOwnerID(ownerDTO.getOwnerID().toString()); // Set the provided UUID as String
            owner.setName(ownerDTO.getName());
            owner.setGender(ownerDTO.getGender());
            owner.setContactNo(ownerDTO.getContactNo().trim().toLowerCase());
            owner.setEmail(ownerDTO.getEmail().trim().toLowerCase());

            Owner savedOwner = ownerDAO.save(owner);

            logger.info("Owner created successfully: {}", savedOwner);

            return new OwnerDTO(savedOwner);

        } catch (Exception e) {
            if (e.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {
                throw new DuplicateResourceException("Duplicate entry: Contact number or email already exists.");
            }
            throw e;
        }
    }

    @Override
    public OwnerDTO getOwnerById(String ownerId) {
        Owner owner = ownerDAO.findById(ownerId)
                .orElseThrow(() -> new OwnerNotFound("Owner with ID " + ownerId + " not found."));

        return new OwnerDTO(owner); // Use the constructor that converts Owner to OwnerDTO
    }

    @Override
    public List<OwnerDTO> getAllOwners() {
        return ownerDAO.findAll().stream()
                .map(OwnerDTO::new) // Use the constructor that converts Owner to OwnerDTO
                .collect(Collectors.toList());
    }

    @Override
    public OwnerDTO updateOwner(String ownerId, OwnerDTO ownerDTO) {
        Owner owner = ownerDAO.findById(ownerId)
                .orElseThrow(() -> new OwnerNotFound("Owner with ID " + ownerId + " not found."));

        owner.setName(ownerDTO.getName());
        owner.setGender(ownerDTO.getGender());
        owner.setContactNo(ownerDTO.getContactNo());
        owner.setEmail(ownerDTO.getEmail());

        ownerDAO.save(owner);

        logger.info("Owner updated successfully: {}", ownerId);

        return ownerDTO;
    }

    @Override
    public void deleteOwner(String ownerId) {
        if (!ownerDAO.existsById(ownerId)) {
            throw new OwnerNotFound("Owner with ID " + ownerId + " not found.");
        }

        ownerDAO.deleteById(ownerId);

        logger.info("Owner deleted successfully: {}", ownerId);
    }

    @Override
    public OwnerDTO getOwnerWithProperties(String ownerId) {
        Owner owner = ownerDAO.findById(ownerId)
                .orElseThrow(() -> new OwnerNotFound("Owner with ID " + ownerId + " not found."));

        List<Property> properties = propertyDAO.findByOwnerId(ownerId);

        List<PropertyDTO> propertyDTOs = properties.stream().map(property -> {
            PropertyDTO propertyDTO = new PropertyDTO(property);
            return propertyDTO;
        }).collect(Collectors.toList());

        OwnerDTO ownerDTO = new OwnerDTO(owner); // Use the constructor that converts Owner to OwnerDTO
        ownerDTO.setProperties(propertyDTOs);

        logger.info("Fetched owner with properties and leases for ownerId: {}", ownerId);

        return ownerDTO;
    }

    @Override
    public PropertyDTO postProperty(String ownerId, PropertyDTO propertyDTO) {
        Owner owner = ownerDAO.findById(ownerId)
                .orElseThrow(() -> new OwnerNotFound("Owner with ID " + ownerId + " not found."));

        Property property = new Property();
        property.setPropertyID(propertyDTO.getPropertyID().toString());
        property.setOwner(owner);
        property.setPropertyName(propertyDTO.getPropertyName());
        property.setAddress(propertyDTO.getAddress());
        property.setType(propertyDTO.getType());
        property.setPrice(propertyDTO.getPrice());
        property.setRentalTerms(propertyDTO.getRentalTerms());
        property.setImageUrls(propertyDTO.getImageUrls());
        property.setAvailabilityStatus(PropertyAvailabilityStatus.valueOf(propertyDTO.getAvailabilityStatus()));

        property = propertyDAO.save(property);

        logger.info("Property posted successfully for ownerId: {}", ownerId);

        return new PropertyDTO(property);
    }

    @Override
    public List<NotificationDTO> getNotificationsForOwner(String ownerId) {
        try {
            return rentPaymentClient.getNotificationsByOwnerId(ownerId);
        } catch (Exception e) {
            logger.error("Failed to fetch notifications for owner ID {}: {}", ownerId, e.getMessage(), e);
            throw new RuntimeException("Error fetching notifications for owner");
        }
    }

    @Override
    public List<RentPaymentDTO> getRentPaymentsForOwner(String ownerId) {
        try {
            return rentPaymentClient.getRentPaymentsByOwnerId(ownerId);
        } catch (Exception e) {
            logger.error("Error fetching rent payments for owner ID {}: {}", ownerId, e.getMessage(), e);
            throw new RuntimeException("Failed to fetch rent payments for owner");
        }
    }
}