package com.example.propertylisting.Service;
 
import com.example.propertylisting.dto.OwnerDTO;
import com.example.propertylisting.dto.PropertyDTO;
import com.example.propertylisting.entity.Owner;
import com.example.propertylisting.entity.Property;
import com.example.propertylisting.entity.PropertyAvailabilityStatus;
import com.example.propertylisting.exception.PropertyNotFound;
import com.example.propertylisting.exception.ResourceNotFoundException;
import com.example.propertylisting.dao.OwnerDAO;
import com.example.propertylisting.dao.PropertyDAO;
import com.example.propertylisting.Service.PropertyService;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
 
@Service
public class PropertyServiceImpl implements PropertyService {
 
    // Logger instance for recording information, warnings, and errors
    private static final Logger logger = LoggerFactory.getLogger(PropertyServiceImpl.class);
 
    @Autowired
    private PropertyDAO propertyDAO; // Data Access Object for Property entity
 
    @Autowired
    private OwnerDAO ownerDAO; // Data Access Object for Owner entity
 
    // Add a new Property for a given owner
    @Override
    public PropertyDTO addProperty(PropertyDTO propertyDTO, String ownerId) {
        logger.info("Attempting to add property for ownerId: {}", ownerId);

        // Find the owner by ID
        Owner owner = ownerDAO.findById(ownerId)
                .orElseThrow(() -> new PropertyNotFound("Owner with ID " + ownerId + " not found."));

        // Map the PropertyDTO to a Property entity and associate it with the owner
        Property property = new Property();
        property.setPropertyName(propertyDTO.getPropertyName());
        property.setAddress(propertyDTO.getAddress());
        property.setType(propertyDTO.getType());
        property.setPrice(propertyDTO.getPrice());
        property.setRentalTerms(propertyDTO.getRentalTerms());
        property.setImageUrls(propertyDTO.getImageUrls());
        property.setAvailabilityStatus(PropertyAvailabilityStatus.valueOf(propertyDTO.getAvailabilityStatus()));

        // Set the owner relationship
        property.setOwner(owner);

        // Save the Property entity and log success
        property = propertyDAO.save(property);
        logger.info("Property added successfully for ownerId: {}", ownerId);

        // Return the PropertyDTO, including ownerID from the saved entity
        PropertyDTO result = new PropertyDTO(property);
        result.setOwnerID(UUID.fromString(owner.getOwnerID())); // Populate the ownerID field in PropertyDTO
        return result;
    }

 
    // Update an existing Property for a given owner
    @Override
    public PropertyDTO updateProperty(String propertyId, PropertyDTO propertyDTO, String ownerId) {
        logger.info("Attempting to update property with ID: {} for ownerId: {}", propertyId, ownerId);
 
        // Find the property by ID
        Property property = propertyDAO.findById(propertyId)
                .orElseThrow(() -> new PropertyNotFound("Property with ID " + propertyId + " not found."));
 
        // Check if the owner owns the property, throw exception if mismatch
        if (!property.getOwner().getOwnerID().equals(ownerId)) {
            throw new PropertyNotFound("Owner with ID " + ownerId + " does not own the property with ID " + propertyId + ".");
        }
 
        // Update property fields with the new details from PropertyDTO
        property.setPropertyName(propertyDTO.getPropertyName());
        property.setAddress(propertyDTO.getAddress());
        property.setType(propertyDTO.getType());
        property.setPrice(propertyDTO.getPrice());
        property.setRentalTerms(propertyDTO.getRentalTerms());
        property.setImageUrls(propertyDTO.getImageUrls());
        property.setAvailabilityStatus(PropertyAvailabilityStatus.valueOf(propertyDTO.getAvailabilityStatus()));
 
        // Save the updated Property entity and log success
        property = propertyDAO.save(property);
        logger.info("Property updated successfully for propertyId: {}", propertyId);
 
        return new PropertyDTO(property);
    }
 
    // Delete a Property for a given owner
    @Override
    public void deleteProperty(String propertyId, String ownerId) {
        logger.info("Attempting to delete property with ID: {} for ownerId: {}", propertyId, ownerId);
 
        // Find the property by ID
        Property property = propertyDAO.findById(propertyId)
                .orElseThrow(() -> new PropertyNotFound("Property with ID " + propertyId + " not found."));
 
        // Check if the owner owns the property, throw exception if mismatch
        if (!property.getOwner().getOwnerID().equals(ownerId)) {
            throw new PropertyNotFound("Owner with ID " + ownerId + " does not own the property with ID " + propertyId + ".");
        }
 
        // Delete the Property entity and log success
        propertyDAO.delete(property);
        logger.info("Property deleted successfully for propertyId: {}", propertyId);
    }
 
    // Retrieve a Property by ID
    @Override
    public PropertyDTO getPropertyById(String propertyId) {
        logger.info("Fetching property with ID: {}", propertyId);
 
        // Find the property by ID
        Property property = propertyDAO.findById(propertyId)
                .orElseThrow(() -> new PropertyNotFound("Property with ID " + propertyId + " not found."));
 
        logger.info("Property fetched successfully with ID: {}", propertyId);
        return new PropertyDTO(property);
    }
 
    // Retrieve all Properties
    @Override
    public List<PropertyDTO> getAllProperties() {
        logger.info("Fetching all properties");
 
        // Retrieve all properties from the database
        List<Property> properties = propertyDAO.findAll();
        logger.info("Fetched {} properties", properties.size());
 
        // Convert each Property entity to a PropertyDTO and return the list
        return properties.stream().map(PropertyDTO::new).collect(Collectors.toList());
    }
 
    // Retrieve Properties by ownerId
    @Override
    public List<PropertyDTO> getPropertiesByOwner(String ownerId) {
        logger.info("Fetching properties for ownerId: {}", ownerId);
 
        // Retrieve properties for the given owner ID
        List<Property> properties = propertyDAO.findByOwnerId(ownerId);
 
        // Log if no properties found or log success
        if (properties.isEmpty()) {
            logger.warn("No properties found for ownerId: {}", ownerId);
        } else {
            logger.info("Fetched {} properties for ownerId: {}", properties.size(), ownerId);
        }
 
        // Convert each Property entity to a PropertyDTO and return the list
        return properties.stream().map(PropertyDTO::new).collect(Collectors.toList());
    }
 
    // Search for Properties based on filters
    @Override
    public List<PropertyDTO> searchProperties(String location, String type, Double minPrice, Double maxPrice) {
        logger.info("Searching properties with filters - location: {}, type: {}, minPrice: {}, maxPrice: {}", location, type, minPrice, maxPrice);
 
        // Retrieve properties matching the given filters
        List<Property> properties = propertyDAO.searchProperties(location, type, minPrice, maxPrice);
 
        // Log the number of properties fetched and return as DTOs
        logger.info("Fetched {} properties matching filters", properties.size());
        return properties.stream().map(PropertyDTO::new).collect(Collectors.toList());
    }
}