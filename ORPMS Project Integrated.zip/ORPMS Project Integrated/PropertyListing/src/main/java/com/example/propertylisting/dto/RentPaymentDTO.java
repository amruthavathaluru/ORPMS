package com.example.propertylisting.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RentPaymentDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotBlank(message = "Payment ID cannot be blank")
    private UUID paymentID;

    @NotBlank(message = "Owner ID cannot be blank")
    private UUID ownerID;
    
    @NotNull
    private UUID tenantID;

    @NotNull(message = "Amount cannot be null")
    @Min(value = 1, message = "Amount must be greater than or equal to 1")
    private Double amount;

    @NotNull(message = "Payment Date cannot be null")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime paymentDate;

    @NotBlank(message = "Payment Status cannot be blank")
    private String paymentStatus;
}
