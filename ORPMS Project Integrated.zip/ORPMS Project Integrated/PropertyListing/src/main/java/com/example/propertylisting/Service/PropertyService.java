package com.example.propertylisting.Service;

import com.example.propertylisting.dto.PropertyDTO;

import java.util.List;

public interface PropertyService {
    PropertyDTO addProperty(PropertyDTO propertyDTO, String ownerId);
    PropertyDTO updateProperty(String propertyId, PropertyDTO propertyDTO, String ownerId);
    void deleteProperty(String propertyId, String ownerId);
    PropertyDTO getPropertyById(String propertyId);
    List<PropertyDTO> getAllProperties();
    List<PropertyDTO> getPropertiesByOwner(String ownerId);
    List<PropertyDTO> searchProperties(String location, String type, Double minPrice, Double maxPrice);
	//PropertyDTO addProperty(PropertyDTO propertyDTO);
}
