package com.example.propertylisting.Service;

import com.example.propertylisting.dto.NotificationDTO;
import com.example.propertylisting.dto.OwnerDTO;
import com.example.propertylisting.dto.PropertyDTO;
import com.example.propertylisting.dto.RentPaymentDTO;

import java.util.List;

public interface OwnerService {
    OwnerDTO createOwner(OwnerDTO ownerDTO);
    OwnerDTO getOwnerById(String ownerId);
    List<OwnerDTO> getAllOwners();
    OwnerDTO updateOwner(String ownerId, OwnerDTO ownerDTO);
    void deleteOwner(String ownerId);
    // Additional Features
    OwnerDTO getOwnerWithProperties(String ownerId); // Fetch owner details with properties and leases
    PropertyDTO postProperty(String ownerId, PropertyDTO propertyDTO); // Post a new property for the owner
    List<NotificationDTO> getNotificationsForOwner(String ownerId); // Fetch notifications for the owner
    List<RentPaymentDTO> getRentPaymentsForOwner(String ownerId);
    //boolean validateCredentials(String email, String passwordHash);
}





































/*package com.example.propertylisting.Service;

//import com.example.propertylisting.dto.LeaseDTO;
import com.example.propertylisting.dto.OwnerDTO;
import com.example.propertylisting.dto.PropertyDTO;
import com.example.propertylisting.entity.Owner;
import com.example.propertylisting.entity.Property;
import com.example.propertylisting.entity.Tenant;
import com.example.propertylisting.exception.ResourceNotFoundException;
import com.example.propertylisting.exception.DuplicateResourceException;
import com.example.propertylisting.dao.OwnerDAO;
import com.example.propertylisting.dao.PropertyDAO;
import com.example.propertylisting.dao.TenantDAO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

public interface OwnerService {
    OwnerDTO createOwner(OwnerDTO ownerDTO);
    OwnerDTO getOwnerById(String ownerId);
    List<OwnerDTO> getAllOwners();
    OwnerDTO updateOwner(String ownerId, OwnerDTO ownerDTO);
    void deleteOwner(String ownerId);
   // void postRent(String ownerId, Double rentAmount);
   // void assignServiceProviderToRequest(String ownerId, String requestId, String serviceProviderId);
   // PropertyDTO postProperty(String ownerId, PropertyDTO propertyDTO);
    
    // Implementation of the service
    @Service
    class OwnerServiceImpl implements OwnerService {

        private static final Logger logger = LoggerFactory.getLogger(OwnerServiceImpl.class);

        @Autowired
        private OwnerDAO ownerDAO;

        @Autowired
        private PropertyDAO propertyDAO;
        
        @Autowired
        private TenantDAO tenantDAO;
        
        @Override
        public OwnerDTO createOwner(OwnerDTO ownerDTO) {
            if (ownerDAO.existsById(ownerDTO.getOwnerID())) {
                throw new DuplicateResourceException("Owner with ID " + ownerDTO.getOwnerID() + " already exists.");
            }

            Owner owner = new Owner(); // Use no-args constructor
            owner.setOwnerID(ownerDTO.getOwnerID());
            owner.setName(ownerDTO.getName());
            owner.setGender(ownerDTO.getGender());
            owner.setContactNo(ownerDTO.getContactNo());
            owner.setEmail(ownerDTO.getEmail());
            owner.setPasswordHash(ownerDTO.getPasswordHash());

            owner = ownerDAO.save(owner);

            logger.info("Owner created successfully: {}", ownerDTO);

            return ownerDTO;
        
        }

        @Override
        public OwnerDTO getOwnerById(String ownerId) {
            Owner owner = ownerDAO.findById(ownerId)
                    .orElseThrow(() -> new ResourceNotFoundException("Owner with ID " + ownerId + " not found."));
            return new OwnerDTO(owner.getOwnerID(), owner.getName(), owner.getGender(),
                    owner.getContactNo(), owner.getEmail(), owner.getPasswordHash());
        }

        @Override
        public List<OwnerDTO> getAllOwners() {
            return ownerDAO.findAll().stream()
                    .map(owner -> new OwnerDTO(owner.getOwnerID(), owner.getName(), owner.getGender(),
                            owner.getContactNo(), owner.getEmail(), owner.getPasswordHash()))
                    .collect(Collectors.toList());
        }

        @Override
        public OwnerDTO updateOwner(String ownerId, OwnerDTO ownerDTO) {
            Owner owner = ownerDAO.findById(ownerId)
                    .orElseThrow(() -> new ResourceNotFoundException("Owner with ID " + ownerId + " not found."));
            owner.setName(ownerDTO.getName());
            owner.setGender(ownerDTO.getGender());
            owner.setContactNo(ownerDTO.getContactNo());
            owner.setEmail(ownerDTO.getEmail());
            owner.setPasswordHash(ownerDTO.getPasswordHash());
            ownerDAO.save(owner);
            logger.info("Owner updated successfully: {}", ownerId);
            return ownerDTO;
        }

        @Override
        public void deleteOwner(String ownerId) {
            if (!ownerDAO.existsById(ownerId)) {
                throw new ResourceNotFoundException("Owner with ID " + ownerId + " not found.");
            }
            ownerDAO.deleteById(ownerId);
            logger.info("Owner deleted successfully: {}", ownerId);
        }

//        @Override
//        public void postRent(String ownerId, Double rentAmount) {
//            throw new UnsupportedOperationException("Not implemented yet.");
//        }

//        @Override
//        public void assignServiceProviderToRequest(String ownerId, String requestId, String serviceProviderId) {
//            throw new UnsupportedOperationException("Not implemented yet.");
//        }

//        @Override
//        public PropertyDTO postProperty(String ownerId, PropertyDTO propertyDTO) {
//            // Fetch the Owner entity using ownerId
//            Owner owner = ownerDAO.findById(ownerId)
//                    .orElseThrow(() -> new ResourceNotFoundException("Owner with ID " + ownerId + " not found."));
//
//            // Fetch the Tenant entity using tenantID (if provided)
//            Tenant tenant = propertyDTO.getTenantID() != null
//                    ? tenantDAO.findById(propertyDTO.getTenantID())
//                            .orElseThrow(() -> new ResourceNotFoundException("Tenant with ID " + propertyDTO.getTenantID() + " not found."))
//                    : null;
//
//            // Create a new Property entity
//            Property property = new Property();
//            property.setPropertyID(propertyDTO.getPropertyID());
//            property.setOwner(owner); // Set the Owner object
//           // property.setTenant(tenant); // Set the Tenant object (can be null)
//            property.setPropertyName(propertyDTO.getPropertyName());
//            property.setAddress(propertyDTO.getAddress());
//            property.setType(propertyDTO.getType());
//            property.setPrice(propertyDTO.getPrice());
//            property.setRentalTerms(propertyDTO.getRentalTerms());
//            property.setImageUrls(propertyDTO.getImageUrls());
//            property.setAvailabilityStatus(propertyDTO.getAvailabilityStatus());
//
//            // Save the Property entity
//            property = propertyDAO.save(property);
//
//            logger.info("Property {} posted successfully for owner {}", propertyDTO.getPropertyID(), ownerId);
//
//            // Return a PropertyDTO with updated information
//            return new PropertyDTO(property);
//        }

    }
}*/
