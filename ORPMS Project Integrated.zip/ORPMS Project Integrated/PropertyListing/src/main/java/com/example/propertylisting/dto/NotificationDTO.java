package com.example.propertylisting.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationDTO implements Serializable {

    private static final long serialVersionUID = 1L; // To support versioning of serialized objects

    @NotBlank(message = "Notification ID cannot be blank")
    private UUID notificationID;

    @NotBlank(message = "Tenant ID cannot be blank")
    private UUID tenantID;

    @NotBlank(message = "Owner ID cannot be blank")
    private UUID ownerID;

    @NotBlank(message = "Message cannot be blank")
    @Size(max = 500, message = "Message must not exceed 500 characters")
    private String message;

    @NotNull(message = "Generated date cannot be null")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime generatedDate;
}
