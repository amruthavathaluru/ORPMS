package com.example.propertylisting.dto;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LeaseDTO {
    @NotBlank(message = "Lease ID cannot be blank")
    private UUID leaseID;

    @NotBlank(message = "Property ID cannot be blank")
    private UUID propertyID;

    @NotBlank(message = "Owner ID cannot be blank") // Owner ID should not be empty
    private UUID ownerID;

    @NotBlank(message = "Tenant ID cannot be blank")
    private UUID tenantID;

    @NotNull(message = "Start date cannot be null")
    @FutureOrPresent(message = "Start date must be in the present or future")
    private LocalDate startDate;

    @NotNull(message = "End date cannot be null")
    @Future(message = "End date must be in the future")
    private LocalDate endDate;

    @NotNull(message = "Rent amount cannot be null")
    @DecimalMin(value = "0.0", inclusive = false, message = "Rent amount must be greater than 0")
    private Double rentAmount;

    @NotBlank(message = "Agreement status cannot be blank")
    @Pattern(regexp = "^(Active|Pending|Expired|Terminated)$", message = "Agreement status must be one of: Active, Pending, Expired, Terminated")
    private String agreementStatus;

    public LeaseDTO(String leaseID, String propertyID, String tenantID, LocalDate startDate, LocalDate endDate, double rentAmount) {
        this.leaseID = UUID.fromString(leaseID);
        this.propertyID = UUID.fromString(propertyID);
        this.tenantID = UUID.fromString(tenantID);
        this.startDate = startDate;
        this.endDate = endDate;
        this.rentAmount = rentAmount;
    }
}
