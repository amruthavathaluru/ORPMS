package com.example.propertylisting.controller;

import com.example.propertylisting.dto.NotificationDTO;
import com.example.propertylisting.dto.OwnerDTO;
import com.example.propertylisting.dto.RentPaymentDTO;
import com.example.propertylisting.Service.OwnerService;
import com.example.propertylisting.exception.DuplicateResourceException;
import com.example.propertylisting.exception.OwnerNotFound;
import com.example.propertylisting.utils.ResultResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import jakarta.validation.Valid;

@Slf4j
@RestController
@RequestMapping("/owners")
public class OwnerController {

    @Autowired
    private OwnerService ownerService;

    @PostMapping("/create")
    public ResponseEntity<ResultResponse<OwnerDTO>> createOwner(@Valid @RequestBody OwnerDTO ownerDTO) {
        log.info("Creating owner: {}", ownerDTO);
        try {
            OwnerDTO createdOwner = ownerService.createOwner(ownerDTO);
            return ResponseEntity.ok(ResultResponse.<OwnerDTO>builder()
                    .success(true)
                    .data(createdOwner)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (DuplicateResourceException e) {
            log.error("Duplicate owner: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<OwnerDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error creating owner: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<OwnerDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @GetMapping("/{ownerId}")
    public ResponseEntity<ResultResponse<OwnerDTO>> getOwnerById(@PathVariable String ownerId) {
        log.info("Fetching owner with ID: {}", ownerId);
        try {
            OwnerDTO owner = ownerService.getOwnerById(ownerId);
            return ResponseEntity.ok(ResultResponse.<OwnerDTO>builder()
                    .success(true)
                    .data(owner)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (OwnerNotFound e) {
            log.error("Owner not found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<OwnerDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error fetching owner by ID: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<OwnerDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @GetMapping("/all")
    public ResponseEntity<ResultResponse<List<OwnerDTO>>> getAllOwners() {
        log.info("Fetching all owners");
        try {
            List<OwnerDTO> owners = ownerService.getAllOwners();
            return ResponseEntity.ok(ResultResponse.<List<OwnerDTO>>builder()
                    .success(true)
                    .data(owners)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error fetching all owners: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<OwnerDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @PutMapping("/update/{ownerId}")
    public ResponseEntity<ResultResponse<OwnerDTO>> updateOwner(@PathVariable String ownerId, @Valid @RequestBody OwnerDTO ownerDTO) {
        log.info("Updating owner with ID: {}", ownerId);
        try {
            OwnerDTO updatedOwner = ownerService.updateOwner(ownerId, ownerDTO);
            return ResponseEntity.ok(ResultResponse.<OwnerDTO>builder()
                    .success(true)
                    .data(updatedOwner)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (OwnerNotFound e) {
            log.error("Owner not found for update: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<OwnerDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error updating owner: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<OwnerDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @DeleteMapping("/delete/{ownerId}")
    public ResponseEntity<ResultResponse<String>> deleteOwner(@PathVariable String ownerId) {
        log.info("Deleting owner with ID: {}", ownerId);
        try {
            ownerService.deleteOwner(ownerId);
            return ResponseEntity.ok(ResultResponse.<String>builder()
                    .success(true)
                    .data("Owner deleted successfully")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (OwnerNotFound e) {
            log.error("Owner not found for deletion: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<String>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error deleting owner: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<String>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @GetMapping("/{ownerId}/notifications")
    public ResponseEntity<ResultResponse<List<NotificationDTO>>> getNotificationsForOwner(@PathVariable String ownerId) {
        log.info("Fetching notifications for owner with ID: {}", ownerId);
        try {
            List<NotificationDTO> notifications = ownerService.getNotificationsForOwner(ownerId);
            return ResponseEntity.ok(ResultResponse.<List<NotificationDTO>>builder()
                    .success(true)
                    .data(notifications)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error fetching notifications for owner ID {}: {}", ownerId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<NotificationDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    @GetMapping("/{ownerId}/rent-payments")
    public ResponseEntity<ResultResponse<List<RentPaymentDTO>>> getRentPaymentsForOwner(@PathVariable String ownerId) {
        log.info("Fetching rent payments for owner with ID: {}", ownerId);
        try {
            List<RentPaymentDTO> rentPayments = ownerService.getRentPaymentsForOwner(ownerId);
            return ResponseEntity.ok(ResultResponse.<List<RentPaymentDTO>>builder()
                    .success(true)
                    .data(rentPayments)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error fetching rent payments for owner ID {}: {}", ownerId, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<RentPaymentDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
}