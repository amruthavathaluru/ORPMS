package com.example.propertylisting;

import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import org.springframework.boot.autoconfigure.SpringBootApplication;


@EnableFeignClients
@SpringBootApplication
@EnableDiscoveryClient
public class PropertylistingApplication {

	public static void main(String[] args) {
		SpringApplication.run(PropertylistingApplication.class, args);
	}

}
