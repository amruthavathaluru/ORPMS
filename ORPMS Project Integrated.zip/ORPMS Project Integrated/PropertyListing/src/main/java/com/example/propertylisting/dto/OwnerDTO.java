package com.example.propertylisting.dto;

import java.util.List;
import java.util.UUID;

import com.example.propertylisting.entity.Owner;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OwnerDTO {

    @NotNull
    private UUID ownerID;

    @NotBlank(message = "Name cannot be blank")
    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
    private String name;

    @NotBlank(message = "Gender cannot be blank")
    @Pattern(regexp = "^(Male|Female|Other)$", message = "Gender must be 'Male', 'Female', or 'Other'")
    private String gender;

    @NotBlank(message = "Contact number cannot be blank")
    @Pattern(regexp = "^[0-9]{10,12}$", message = "Contact number must be between 10 and 12 digits")
    private String contactNo;

    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Email must be a valid email address")
    private String email;

    private List<PropertyDTO> properties;

    public OwnerDTO(String ownerID, String name, String gender, String contactNo, String email) {
        this.ownerID = UUID.fromString(ownerID);
        this.name = name;
        this.gender = gender;
        this.contactNo = contactNo;
        this.email = email;
    }

    public OwnerDTO(Owner owner) {
        this.ownerID = UUID.fromString(owner.getOwnerID());
        this.name = owner.getName();
        this.gender = owner.getGender();
        this.contactNo = owner.getContactNo();
        this.email = owner.getEmail();
        // You would need to convert property entities to property DTOs here.
    }

    public void setProperties(List<PropertyDTO> propertyDTOs) {
        this.properties = propertyDTOs;
    }
}