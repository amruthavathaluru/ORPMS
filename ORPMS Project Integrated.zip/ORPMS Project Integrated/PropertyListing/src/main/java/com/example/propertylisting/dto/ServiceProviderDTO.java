package com.example.propertylisting.dto;

import java.util.UUID;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ServiceProviderDTO {

    @NotBlank(message = "Provider ID cannot be blank")
    private UUID providerID; // Added Service Provider ID

    @NotBlank(message = "Name cannot be blank")
    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
    private String name;

    @NotBlank(message = "Service type cannot be blank")
    @Pattern(regexp = "^(Plumbing|Electrical|Cleaning|Other)$", message = "Service type must be 'Plumbing', 'Electrical', 'Cleaning', or 'Other'")
    private String serviceType; // e.g., Plumbing, Electrical, Cleaning

    @NotBlank(message = "Contact number cannot be blank")
    @Pattern(regexp = "^[0-9]{10,12}$", message = "Contact number must be between 10 and 12 digits")
    private String contactNo;
}
