package com.example.propertylisting.client;

import com.example.propertylisting.dto.NotificationDTO;
import com.example.propertylisting.dto.RentPaymentDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;

@FeignClient(name = "rentpayment")
public interface RentPaymentClient {

    @GetMapping("/rentpayments/owner/{ownerId}")
    List<RentPaymentDTO> getRentPaymentsByOwnerId(@PathVariable("ownerId") String ownerId);
    
    @GetMapping("/notifications/owner/{ownerId}")
    List<NotificationDTO> getNotificationsByOwnerId(@PathVariable("ownerId") String ownerId);

}
