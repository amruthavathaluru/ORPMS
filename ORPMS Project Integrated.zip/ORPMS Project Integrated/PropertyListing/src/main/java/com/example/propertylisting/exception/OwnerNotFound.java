package com.example.propertylisting.exception;

public class OwnerNotFound extends RuntimeException{
	public OwnerNotFound(String message) {
		super(message);
	}

}
