package com.example.propertylisting.dto;
 
import com.example.propertylisting.entity.Owner;
import com.example.propertylisting.entity.Property;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
 
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PropertyDTO {
 
	@Null(message = "Property ID should not be provided; it will be generated automatically")
	private UUID propertyID;
 
 
    @NotNull
    private UUID ownerID;

    private UUID tenantID;

    //private Owner owner;
 
    @NotBlank(message = "Property name cannot be blank")
    @Size(min = 3, max = 50, message = "Property name must be between 3 and 50 characters")
    private String propertyName;
 
    @NotBlank(message = "Address cannot be blank")
    @Size(min = 10, max = 100, message = "Address must be between 10 and 100 characters")
    private String address;
 
    @NotBlank(message = "Type cannot be blank")
    @Pattern(regexp = "^(Residential|Commercial|Industrial)$", message = "Type must be 'Residential', 'Commercial', or 'Industrial'")
    private String type;
 
    @NotNull(message = "Price cannot be null")
    @DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0")
    private Double price;
 
    @NotBlank(message = "Rental terms cannot be blank")
    @Size(max = 200, message = "Rental terms must not exceed 200 characters")
    private String rentalTerms;
 
    @NotNull(message = "Image URLs cannot be null")
    @Size(min = 1, message = "At least one image URL is required")
    private List<@NotBlank(message = "Image URL cannot be blank") String> imageUrls;
 
    @NotBlank(message = "Availability status cannot be blank")
    @Pattern(regexp = "^(available|rented)$", message = "Availability status must be 'available','rented'")
    private String availabilityStatus;
 
    private List<LeaseDTO> leases; // Validation is assumed to be handled in LeaseDTO
 
    public PropertyDTO(Property property) {
    	 this.propertyID = UUID.fromString(property.getPropertyID());
    	    // Get the ownerID through the owner relationship
    	    this.ownerID = property.getOwner() != null ? UUID.fromString(property.getOwner().getOwnerID()) : null;
    	    this.propertyName = property.getPropertyName();
    	    this.address = property.getAddress();
    	    this.type = property.getType();
    	    this.price = property.getPrice();
    	    this.rentalTerms = property.getRentalTerms();
    	    this.imageUrls = property.getImageUrls();
    	    this.availabilityStatus = property.getAvailabilityStatus().name();
 
////        // Map leases from Property to LeaseDTO
////        if (property.getLeases() != null) {
////            this.leases = property.getLeases().stream()
////                .map(lease -> new LeaseDTO(
////                    lease.getLeaseID(),
////                    lease.getProperty().getPropertyID(),
////                    lease.getTenant().getTenantID(),
////                    lease.getStartDate(),
////                    lease.getEndDate(),
////                    lease.getRentAmount()
////                ))
//                .collect(Collectors.toList());
//        }
    }
}