package com.example.propertylisting.exception;

public class PropertyNotFound extends RuntimeException {
	public PropertyNotFound(String message) {
		super(message);
	}

}
