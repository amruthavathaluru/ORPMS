package com.leasemanagement.lease.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class TenantProfileDTO {

    @NotBlank(message = "Tenant ID cannot be blank")
    private String tenantID;

    @NotBlank(message = "Tenant Name cannot be blank")
    @Size(max = 100, message = "Tenant Name cannot exceed 100 characters")
    private String tenantName;

    @NotBlank(message = "Tenant Email cannot be blank")
    @Email(message = "Invalid email format")
    private String tenantEmail;
}
