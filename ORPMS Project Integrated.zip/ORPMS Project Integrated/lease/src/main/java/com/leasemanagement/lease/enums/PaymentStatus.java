package com.leasemanagement.lease.enums;

public enum PaymentStatus {
	payment_initiated,
	amount_received,
	payment_done;

}