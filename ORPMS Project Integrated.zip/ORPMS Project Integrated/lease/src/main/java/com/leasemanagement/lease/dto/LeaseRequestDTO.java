package com.leasemanagement.lease.dto;

import lombok.Data;

import java.util.UUID;

import jakarta.validation.constraints.NotBlank;

@Data
public class LeaseRequestDTO {

    @NotBlank(message = "Property ID cannot be blank")
    private UUID propertyID;

    @NotBlank(message = "Tenant ID cannot be blank")
    private UUID tenantID;

    @NotBlank(message = "Owner ID cannot be blank")
    private UUID ownerID;
    
    
}
