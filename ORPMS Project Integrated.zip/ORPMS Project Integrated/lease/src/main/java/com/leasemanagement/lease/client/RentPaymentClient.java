package com.leasemanagement.lease.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.leasemanagement.lease.dto.RentPaymentDTO;


@FeignClient(name="rentpaymentmodule")
public interface RentPaymentClient {
	
	@GetMapping("rentpayment/{paymentID}")
    ResponseEntity<RentPaymentDTO> getPaymentById(@PathVariable("paymentID") String propertyId);
	//update with true values
	
	
}
