package com.leasemanagement.lease.enums;

public enum LeaseStatus {
	agreement_initiated,
	agreement_accepted,
	lease_due,
	lease_terminated;
}
