package com.leasemanagement.lease.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.leasemanagement.lease.model.Lease;

@Repository
public interface LeaseRepository extends JpaRepository<Lease ,String> {

	Lease findByTenantID(String tenantID);

}
