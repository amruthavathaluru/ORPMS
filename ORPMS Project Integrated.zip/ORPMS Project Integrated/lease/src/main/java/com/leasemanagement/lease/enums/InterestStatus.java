package com.leasemanagement.lease.enums;



public enum InterestStatus {
	submitted,
	accepted,
	rejected;
}