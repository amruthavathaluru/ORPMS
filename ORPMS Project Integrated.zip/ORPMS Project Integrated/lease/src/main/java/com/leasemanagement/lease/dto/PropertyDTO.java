package com.leasemanagement.lease.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class PropertyDTO {

    @NotBlank(message = "Property ID cannot be blank")
    private String propertyID;
    
    @NotBlank(message = "Owner ID cannot be blank")
    private String ownerID;

    @NotBlank(message = "Property Address cannot be blank")
    private String propertyAddress;
    
    

    @DecimalMin(value = "0.0", inclusive = false, message = "Property Price must be greater than 0")
    private double propertyPrice;
    
    
}
