package com.leasemanagement.lease.service;

import com.leasemanagement.lease.client.InterestClient;
import com.leasemanagement.lease.client.PropertyClient;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.leasemanagement.lease.dto.InterestDTO;
import com.leasemanagement.lease.dto.LeaseResponseDTO;
import com.leasemanagement.lease.dto.OwnerDTO;
import com.leasemanagement.lease.dto.RentPaymentDTO;
import com.leasemanagement.lease.dto.PropertyDTO;
import com.leasemanagement.lease.dto.TenantProfileDTO;
import com.leasemanagement.lease.enums.LeaseStatus;
import com.leasemanagement.lease.enums.PaymentStatus;
import com.leasemanagement.lease.model.Lease;
import com.leasemanagement.lease.repository.LeaseRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LeaseService {

	
		@Autowired
		private PropertyClient propertyClient;
		
		@Autowired
		private InterestClient interestClient;
		
		
		@Autowired
		private LeaseRepository leaseRepo;

		public LeaseResponseDTO showLease(InterestDTO interestDTO) {
			
			 
			 
		 TenantProfileDTO tenantDTO = interestClient.getTenantProfile(interestDTO.getTenantID().toString()).getBody().getData();
	//	ResultResponse<TenantProfileDTO> ten = tenantResponse.getBody();
					 
		PropertyDTO propertyDTO =  propertyClient.getPropertyById(interestDTO.getPropertyID().toString()).getBody(); 
//		PropertyDTO prop = propertyDTO.getBody();
		
		OwnerDTO ownerDTO = propertyClient.getOwnerById(propertyDTO.getOwnerID().toString()).getBody().getData();
		
		
		     
		// ResponseEntity<ResultResponse<OwnerDTO>>	     
		//ResponseEntity<ResultResponse<TenantProfileDTO>>
		     
		     
		     
		     
		     //Fetching data from other modules and adding it to Response DTO
		     
		     LeaseResponseDTO leaseDto = new LeaseResponseDTO();
		     
		     leaseDto.setTenantName(tenantDTO.getTenantName());
		     leaseDto.setTenantEmail(tenantDTO.getTenantEmail());
		     leaseDto.setOwnerName(ownerDTO.getName());
		     leaseDto.setOwnerEmail(ownerDTO.getEmail());
		     leaseDto.setPropertyAddress(propertyDTO.getPropertyAddress());
		     leaseDto.setPropertyPrice(propertyDTO.getPropertyPrice());
		     leaseDto.setStartDate(LocalDate.now());
		     leaseDto.setEndDate(LocalDate.now().plusMonths(11));
		     leaseDto.setLeaseStatus(LeaseStatus.agreement_initiated);
		     
		     //Saving to the Database
		     
		     Lease lease = new Lease();
		     
		     lease.setTenantName(leaseDto.getTenantName());
		     lease.setTenantEmail(leaseDto.getTenantEmail());
		     lease.setOwnerName(leaseDto.getOwnerName());
		     lease.setOwnerEmail(leaseDto.getOwnerEmail());
		     lease.setPropertyAddress(leaseDto.getPropertyAddress());
		     lease.setPropertyPrice(leaseDto.getPropertyPrice());
		     lease.setStartDate(leaseDto.getStartDate());
		     lease.setEndDate(leaseDto.getEndDate());
		     lease.setLeaseStatus(LeaseStatus.agreement_initiated);
		     lease.setOwnerID(ownerDTO.getOwnerID());
		     lease.setPropertyID(propertyDTO.getPropertyID().toString());
		     lease.setTenantID(tenantDTO.getTenantID().toString());
		     
		     leaseRepo.save(lease);  
		   
		     return leaseDto;
		     
		}
		
//		public PaymentDto initiatePayment(String leaseId) {
//		        // Send lease ID to payment module
//		        return paymentService.processPayment(leaseId);
//		    }
		  

		public String paymentStatusUpdate(RentPaymentDTO rentPaymentDTO) {
			
			 if (rentPaymentDTO.getLeaseID() == null) {
			        throw new IllegalArgumentException("Lease ID must not be null");
			    }
			 
			 
			 Lease lease = leaseRepo.findById(rentPaymentDTO.getLeaseID().toString())
					 .orElseThrow(() -> new RuntimeException("Lease Id not found"));
			 
			 
			 
			 
			 if(rentPaymentDTO.getPaymentStatus().equals(PaymentStatus.payment_done))
			 {
			 lease.setLeaseStatus(LeaseStatus.agreement_accepted);
			 }
			 
			 leaseRepo.save(lease);
			
			return "Payment Done and Lease Genrated";
		}
		

		public LeaseResponseDTO getLeaseByTenantID(String tenantID) {
			// TODO Auto-generated method stub
			
			Lease lease = leaseRepo.findByTenantID(tenantID);
			
			LeaseResponseDTO leaseResponseDTO = new LeaseResponseDTO();
			
			//Storing values from lease to leaseResponse
			
			leaseResponseDTO.setTenantName(lease.getTenantName());
			leaseResponseDTO.setTenantEmail(lease.getTenantEmail());
			leaseResponseDTO.setOwnerName(lease.getOwnerName());
			leaseResponseDTO.setOwnerEmail(lease.getOwnerEmail());
			leaseResponseDTO.setPropertyAddress(lease.getPropertyAddress());
			leaseResponseDTO.setPropertyPrice(lease.getPropertyPrice());
			leaseResponseDTO.setStartDate(lease.getStartDate());
			leaseResponseDTO.setEndDate(lease.getEndDate());
			
			
			return leaseResponseDTO;
		}

		public LeaseResponseDTO renewLease(String leaseId) {
			// TODO Auto-generated method stub
			
			Lease lease = leaseRepo.findById(leaseId)
					.orElseThrow(() ->  new RuntimeException("Lease not found"));
			
			 LocalDate updatedDate = fetchRenewalDate(lease.getEndDate());
			
			
			lease.setStartDate(updatedDate);
	        lease.setEndDate(updatedDate.plusMonths(11));
	        
	        LeaseResponseDTO leaseResponseDTO = new LeaseResponseDTO();
	        
	        leaseResponseDTO.setTenantName(lease.getTenantName());
			leaseResponseDTO.setTenantEmail(lease.getTenantEmail());
			leaseResponseDTO.setOwnerName(lease.getOwnerName());
			leaseResponseDTO.setOwnerEmail(lease.getOwnerEmail());
			leaseResponseDTO.setPropertyAddress(lease.getPropertyAddress());
			leaseResponseDTO.setPropertyPrice(lease.getPropertyPrice());
			leaseResponseDTO.setStartDate(lease.getStartDate());
			leaseResponseDTO.setEndDate(lease.getEndDate());
	        
	        return leaseResponseDTO;
		}
		
		
		 public static LocalDate fetchRenewalDate(LocalDate endDate)
		    {
		    	 LocalDate updatedDate = endDate.plusDays(1);
		    	
		    	return updatedDate;
		    }
		
		
		
		
		
}
