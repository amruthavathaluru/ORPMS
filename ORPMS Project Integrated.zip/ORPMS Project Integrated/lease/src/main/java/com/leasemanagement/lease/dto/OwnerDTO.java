package com.leasemanagement.lease.dto;


 

 

 
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.*; // Import validation annotations
 
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class OwnerDTO {
 
	@Null(message = "Owner ID should not be provided; it will be generated automatically")
	private String ownerID;
 
 
    @NotBlank(message = "Name cannot be blank")
    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
    private String name;
    
    
//    @NotBlank(message = "Gender cannot be blank")
//    @Pattern(regexp = "^(Male|Female|Other)$", message = "Gender must be 'Male', 'Female', or 'Other'")
//    private String gender;
 
//    @NotBlank(message = "Contact number cannot be blank")
//    @Pattern(regexp = "^[0-9]{10,12}$", message = "Contact number must be between 10 and 12 digits")
//    private String contactNo;
 
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Email must be a valid email address")
    private String email;
// 
//    @NotBlank(message = "Password cannot be blank")
//    @Size(min = 8, message = "Password must be at least 8 characters")
//    private String passwordHash;
 
//    public OwnerDTO(Owner owner) {
//        this.ownerID = owner.getOwnerID();
//        this.name = owner.getName();
//        this.gender = owner.getGender();
//        this.contactNo = owner.getContactNo();
//        this.email = owner.getEmail();
//        this.passwordHash = owner.getPasswordHash();
//    }
 
//    public void setProperties(List<PropertyDTO> propertyDTOs) {
//        // TODO Auto-generated method stub
//    }
}