package com.leasemanagement.lease.response;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ResultResponse<T> {
	 	private boolean success;
	    private T data;
	    private String message;
	    private LocalDateTime timestamp;
}
