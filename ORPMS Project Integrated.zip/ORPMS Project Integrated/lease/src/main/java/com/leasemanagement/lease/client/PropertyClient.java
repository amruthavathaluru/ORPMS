package com.leasemanagement.lease.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.leasemanagement.lease.dto.OwnerDTO;
import com.leasemanagement.lease.dto.PropertyDTO;
import com.leasemanagement.lease.response.ResultResponse;

@FeignClient(name="propertylisting")
public interface PropertyClient {

	
	@GetMapping("properties/{propertyId}")
    ResponseEntity<PropertyDTO> getPropertyById(@PathVariable("propertyId") String propertyId);
	
	@GetMapping("owners/{ownerId}")
    ResponseEntity<ResultResponse<OwnerDTO>> getOwnerById(@PathVariable("ownerId") String ownerId);
	//ownerid from ownerdto or propertdto
}
