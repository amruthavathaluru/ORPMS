package com.leasemanagement.lease.controller;

import java.time.LocalDateTime;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.leasemanagement.lease.dto.InterestDTO;
import com.leasemanagement.lease.dto.LeaseRequestDTO;
import com.leasemanagement.lease.dto.LeaseResponseDTO;
import com.leasemanagement.lease.dto.RentPaymentDTO;
import com.leasemanagement.lease.response.ResultResponse;
import com.leasemanagement.lease.service.LeaseService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("lease")
@Slf4j
public class LeaseController {

	@Autowired
	private LeaseService leaseService;
	
	@PostMapping("/display")
	public ResponseEntity<ResultResponse<LeaseResponseDTO>> showLease(@Valid @RequestBody InterestDTO interestDTO)
	{
		log.info("Displaying Lease Details ");
		
		try {
			log.info("Inside try block");
			LeaseResponseDTO leaseResponseDTO = leaseService.showLease(interestDTO);
			log.info("exiting try block");
			return ResponseEntity.ok(ResultResponse.<LeaseResponseDTO>builder()
					.success(true)
					.data(leaseResponseDTO)
					.timestamp(LocalDateTime.now())
					.build());
		}catch (Exception e) {
            log.error("Error getting lease details: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<LeaseResponseDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
		
		
	}
	
	
	
//	 @PostMapping("/initiatePayment")
//	    public ResponseEntity<ResultResponse<PaymentDto>> initiatePayment(@RequestBody String leaseId) {
//	        log.info("Initiating payment for lease ID: {}", leaseId);
//
//	        try {
//	            log.info("Inside try block");
//	            PaymentDto paymentDto = leaseService.initiatePayment(leaseId);
//	            log.info("Exiting try block");
//	            return ResponseEntity.ok(ResultResponse.<PaymentDto>builder()
//	                    .success(true)
//	                    .data(paymentDto)
//	                    .timestamp(LocalDateTime.now())
//	                    .build());
//	        } catch (Exception e) {
//	            log.error("Error initiating payment: {}", e.getMessage(), e);
//	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PaymentDto>builder()
//	                    .success(false)
//	                    .message("Internal server error")
//	                    .timestamp(LocalDateTime.now())
//	                    .build());
//	        }
//	    }
//

	
	@PutMapping("update/paid")
	public ResponseEntity<ResultResponse<String>> paymentStatusUpdate(@Valid @RequestBody RentPaymentDTO rentPaymentDTO)
	{
		log.info("Updating  payment status in lease table");
		
		try {
			log.info("Inside try block");
			String updateStatus = leaseService.paymentStatusUpdate(rentPaymentDTO);
			log.info("Exiting try block");
			return ResponseEntity.ok(ResultResponse.<String>builder()
					.success(true)
					.data(updateStatus)
					.timestamp(LocalDateTime.now())
					.build());
		}catch(Exception e) {
			  log.error("Error getting lease details: {}", e.getMessage(), e);
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<String>builder()
	                    .success(false)
	                    .message("Internal server error")
	                    .timestamp(LocalDateTime.now())
	                    .build());
		}
			
	}
	
	@GetMapping("tenant/{tenantID}")
	public ResponseEntity<ResultResponse<LeaseResponseDTO>> getLeaseByTenantID(@Valid @PathVariable String tenantID)
	{
		log.info("Getting lease by tenant Id");
		try {
			log.info("Inisde try block");
			LeaseResponseDTO leaseResponseDTO = leaseService.getLeaseByTenantID(tenantID);
			log.info("Exiting try block");
			return ResponseEntity.ok(ResultResponse.<LeaseResponseDTO>builder()
					.success(true)
					.data(leaseResponseDTO)
					.timestamp(LocalDateTime.now())
					.build());
		}catch(Exception e) {
			log.error("Error getting Lease Details: {}",e.getMessage(),e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<LeaseResponseDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
		}
	}
	
	@PutMapping("renewal/{leaseId}")
	public ResponseEntity<ResultResponse<LeaseResponseDTO>> renewLease(@Valid @PathVariable String leaseId)
	{
		log.info("Displaying Lease Details ");
		
		try {
			log.info("Inside try block");
			LeaseResponseDTO leaseResponseDTO = leaseService.renewLease(leaseId);
			log.info("exiting try block");
			return ResponseEntity.ok(ResultResponse.<LeaseResponseDTO>builder()
					.success(true)
					.data(leaseResponseDTO)
					.timestamp(LocalDateTime.now())
					.build());
		}catch (Exception e) {
            log.error("Error getting lease details: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<LeaseResponseDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
		
		
	}
	
	
}

   
	

