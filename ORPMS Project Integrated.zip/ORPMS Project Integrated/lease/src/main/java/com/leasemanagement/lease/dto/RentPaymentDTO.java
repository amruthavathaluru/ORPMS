package com.leasemanagement.lease.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.leasemanagement.lease.enums.PaymentStatus;

import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Data
@JsonIgnoreProperties(ignoreUnknown=true)
public class RentPaymentDTO {

    @NotBlank(message = "Lease ID cannot be blank")
    private String leaseID;

    @NotNull(message = "Payment status cannot be null")
    private PaymentStatus paymentStatus;
}
