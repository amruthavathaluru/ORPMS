//package com.example.rentpayment.service;
//
//import com.example.rentpayment.client.LeaseClient;
//import com.example.rentpayment.dto.LeaseDTO;
//import com.example.rentpayment.dto.RentPaymentsDTO;
//import com.example.rentpayment.entity.RentPayments;
//import com.example.rentpayment.enums.NotificationType;
//import com.example.rentpayment.enums.PaymentStatus;
//import com.example.rentpayment.exception.LeaseNotFoundException;
//import com.example.rentpayment.exception.ResourceNotFoundException;
//import com.example.rentpayment.repository.RentPaymentRepository;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.util.List;
//import java.util.stream.Collectors;
//
///**
// * Service class for managing rent payments using DTOs.
// * Includes operations such as saving, updating, and retrieving rent payment details.
// * This service also triggers notifications for various rent payment events.
// */
//@Service
//@Slf4j
//public class RentPaymentService {
//
//    @Autowired
//    private RentPaymentRepository rentPaymentRepository;
//
//    @Autowired
//    private NotificationService notificationService;
//
//    @Autowired
//    private LeaseClient leaseClient;
//
//    /**
//     * Fetches all rent payments due within the next 3 days using DTOs.
//     * Used by scheduled tasks to send reminders.
//     *
//     * @return A list of rent payment DTOs that are due soon.
//     */
//    public List<RentPaymentsDTO> getDuePayments() {
//        log.info("Fetching rent payments due within the next 3 days.");
//        List<RentPayments> rentPayments = rentPaymentRepository.findPaymentsDueSoon(LocalDate.now().plusDays(3));
//        return rentPayments.stream().map(RentPaymentsDTO::fromEntity).collect(Collectors.toList());
//    }
//
//    /**
//     * Fetches all rent payments that are overdue as of today using DTOs.
//     * Used by scheduled tasks to send overdue alerts.
//     *
//     * @return A list of overdue rent payment DTOs.
//     */
//    public List<RentPaymentsDTO> getOverduePayments() {
//        log.info("Fetching rent payments that are overdue.");
//        List<RentPayments> rentPayments = rentPaymentRepository.findOverduePayments(LocalDate.now());
//        return rentPayments.stream().map(RentPaymentsDTO::fromEntity).collect(Collectors.toList());
//    }
//
//    /**
//     * Fetches all rent payments using DTOs.
//     *
//     * @return A list of all rent payment DTOs.
//     */
//    public List<RentPaymentsDTO> getAllRentPayments() {
//        log.info("Fetching all rent payments from the database.");
//        List<RentPayments> rentPayments = rentPaymentRepository.findAll();
//        return rentPayments.stream().map(RentPaymentsDTO::fromEntity).collect(Collectors.toList());
//    }
//
//    /**
//     * Fetches a specific rent payment by its ID using a DTO.
//     *
//     * @param paymentID The ID of the rent payment to fetch.
//     * @return The rent payment DTO.
//     * @throws ResourceNotFoundException if the rent payment is not found.
//     */
//    public RentPaymentsDTO getRentPaymentById(String paymentID) {
//        log.info("Fetching rent payment with ID: {}", paymentID);
//        RentPayments rentPayment = rentPaymentRepository.findById(paymentID)
//                .orElseThrow(() -> new ResourceNotFoundException("Rent payment not found with ID: " + paymentID));
//        return RentPaymentsDTO.fromEntity(rentPayment);
//    }
//
//    /**
//     * Saves a new rent payment and triggers a payment success notification using DTOs.
//     *
//     * @param rentPaymentsDTO The rent payment DTO to save.
//     * @return The saved rent payment DTO.
//     * @throws LeaseNotFoundException if lease details cannot be fetched from the lease service.
//     */
//    public RentPaymentsDTO saveRentPayment(RentPaymentsDTO rentPaymentsDTO) {
//        log.info("Attempting to save rent payment: {}", rentPaymentsDTO);
//
//        // Fetch tenant details from Lease service via Feign client
//        LeaseDTO lease;
//        try {
//            lease = leaseClient.getLeaseById(rentPaymentsDTO.getLeaseId());
//            log.info("Fetched lease details successfully for Lease ID: {}", rentPaymentsDTO.getLeaseId());
//        } catch (Exception e) {
//            log.error("Failed to fetch lease details for Lease ID: {}", rentPaymentsDTO.getLeaseId(), e);
//            throw new LeaseNotFoundException("Lease not found with ID: " + rentPaymentsDTO.getLeaseId());
//        }
//
//        // Save the rent payment to the repository
//        RentPayments savedPayment = rentPaymentRepository.save(rentPaymentsDTO.toEntity(rentPaymentsDTO.getLeaseId()));
//        log.info("Rent payment saved successfully: {}", savedPayment);
//
//        // Trigger notification for payment success
//        String message = "Your rent payment of ₹" + savedPayment.getAmount() + " was successful.";
//        notificationService.createNotification(
//                lease.getTenantId(),
//                message,
//                NotificationType.PAYMENT_SUCCESS
//        );
//        log.info("Payment success notification triggered for Tenant ID: {}", lease.getTenantId());
//
//        return RentPaymentsDTO.fromEntity(savedPayment);
//    }
//
//    /**
//     * Deletes a rent payment by its ID.
//     *
//     * @param paymentID The ID of the rent payment to delete.
//     * @throws ResourceNotFoundException if the rent payment is not found.
//     */
//    public void deleteRentPayment(String paymentID) {
//        log.info("Attempting to delete rent payment with ID: {}", paymentID);
//
//        // Check if the rent payment exists
//        if (!rentPaymentRepository.existsById(paymentID)) {
//            log.error("Rent payment not found with ID: {}", paymentID);
//            throw new ResourceNotFoundException("Rent payment not found with ID: " + paymentID);
//        }
//
//        // Delete the rent payment
//        rentPaymentRepository.deleteById(paymentID);
//        log.info("Rent payment with ID: {} deleted successfully.", paymentID);
//    }
//
//    /**
//     * Fetches rent payments associated with a specific lease ID using DTOs.
//     *
//     * @param leaseId The ID of the lease.
//     * @return A list of rent payment DTOs for the specified lease ID.
//     * @throws LeaseNotFoundException if the lease is not found.
//     */
//    public List<RentPaymentsDTO> getRentPaymentsByLeaseId(String leaseId) {
//        log.info("Fetching rent payments for Lease ID: {}", leaseId);
//
//        // Validate lease ID via Feign client
//        LeaseDTO lease;
//        try {
//            lease = leaseClient.getLeaseById(leaseId);
//            log.info("Lease details validated for Lease ID: {}", leaseId);
//        } catch (Exception e) {
//            log.error("Failed to validate lease for Lease ID: {}", leaseId, e);
//            throw new LeaseNotFoundException("Lease not found with ID: " + leaseId);
//        }
//
//        // Fetch rent payments for the lease ID
//        List<RentPayments> rentPayments = rentPaymentRepository.findAllByLeaseId(leaseId);
//        return rentPayments.stream().map(RentPaymentsDTO::fromEntity).collect(Collectors.toList());
//    }
//
//    /**
//     * Updates the payment status of a rent payment by its ID and triggers a status update notification using DTOs.
//     *
//     * @param paymentID The ID of the rent payment to update.
//     * @param status    The new payment status.
//     * @return The updated rent payment DTO.
//     * @throws ResourceNotFoundException if the rent payment is not found.
//     */
//    public RentPaymentsDTO updatePaymentStatus(String paymentID, PaymentStatus status) {
//        log.info("Updating payment status for Rent Payment ID: {}", paymentID);
//
//        // Fetch rent payment
//        RentPayments rentPayment = rentPaymentRepository.findById(paymentID)
//                .orElseThrow(() -> {
//                    log.error("Rent payment not found with ID: {}", paymentID);
//                    return new ResourceNotFoundException("Rent payment not found with ID: " + paymentID);
//                });
//
//        // Fetch lease details for the rent payment
//        LeaseDTO lease = leaseClient.getLeaseById(rentPayment.getLeaseId());
//
//        // Update payment status
//        rentPayment.setStatus(status);
//        rentPayment.setUpdatedAt(LocalDateTime.now());
//        RentPayments updatedPayment = rentPaymentRepository.save(rentPayment);
//        log.info("Payment status updated successfully for Rent Payment ID: {}", paymentID);
//
//        // Trigger notification for status update
//        String message = "Your rent payment status has been updated to " + status + ".";
//        createNotification(
//                lease.getTenantId(),
//                message,
//                NotificationType.REMINDER // Adjust notification type as necessary
//        );
//        log.info("Payment status update notification triggered for Tenant ID: {}", lease.getTenantId());
//
//        return RentPaymentsDTO.fromEntity(updatedPayment);
//    }
//}

package com.example.rentpayment.service;

import com.example.rentpayment.client.LeaseClient;
import com.example.rentpayment.dto.LeaseDTO;
import com.example.rentpayment.dto.RentPaymentsDTO;
import com.example.rentpayment.entity.RentPayments;
import com.example.rentpayment.enums.NotificationType;
import com.example.rentpayment.enums.PaymentStatus;
import com.example.rentpayment.exception.LeaseNotFoundException;
import com.example.rentpayment.exception.ResourceNotFoundException;
import com.example.rentpayment.repository.RentPaymentRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service class for managing rent payments using DTOs.
 * Includes operations such as saving, updating, and retrieving rent payment details.
 * This service also triggers notifications for various rent payment events.
 */
@Service
@Slf4j
public class RentPaymentService {

    @Autowired
    private RentPaymentRepository rentPaymentRepository;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private LeaseClient leaseClient;

    /**
     * Fetches all rent payments due within the next 3 days using DTOs.
     * Used by scheduled tasks to send reminders.
     *
     * @return A list of rent payment DTOs that are due soon.
     */
    public List<RentPaymentsDTO> getDuePayments() {
        log.info("Fetching rent payments due within the next 3 days.");
        return rentPaymentRepository.findPaymentsDueSoon(LocalDate.now().plusDays(3)).stream()
                .map(RentPaymentsDTO::fromEntity)
                .collect(Collectors.toList());
    }

    /**
     * Fetches all rent payments that are overdue as of today using DTOs.
     * Used by scheduled tasks to send overdue alerts.
     *
     * @return A list of overdue rent payment DTOs.
     */
    public List<RentPaymentsDTO> getOverduePayments() {
        log.info("Fetching rent payments that are overdue.");
        return rentPaymentRepository.findOverduePayments(LocalDate.now()).stream()
                .map(RentPaymentsDTO::fromEntity)
                .collect(Collectors.toList());
    }

    /**
     * Fetches all rent payments using DTOs.
     *
     * @return A list of all rent payment DTOs.
     */
    public List<RentPaymentsDTO> getAllRentPayments() {
        log.info("Fetching all rent payments from the database.");
        return rentPaymentRepository.findAll().stream()
                .map(RentPaymentsDTO::fromEntity)
                .collect(Collectors.toList());
    }

    /**
     * Fetches a specific rent payment by its ID using DTO.
     *
     * @param paymentID The ID of the rent payment to fetch.
     * @return The rent payment DTO.
     * @throws ResourceNotFoundException if the rent payment is not found.
     */
    public RentPaymentsDTO getRentPaymentById(String paymentID) {
        log.info("Fetching rent payment with ID: {}", paymentID);
        return rentPaymentRepository.findById(paymentID)
                .map(RentPaymentsDTO::fromEntity)
                .orElseThrow(() -> new ResourceNotFoundException("Rent payment not found with ID: " + paymentID));
    }

    /**
     * Saves a new rent payment and triggers a payment success notification using DTO.
     *
     * @param rentPaymentDTO The rent payment DTO to save.
     * @return The saved rent payment DTO.
     * @throws LeaseNotFoundException if lease details cannot be fetched from the lease service.
     */
    public RentPaymentsDTO saveRentPayment(RentPaymentsDTO rentPaymentDTO) {
        log.info("Attempting to save rent payment: {}", rentPaymentDTO);

        // Fetch tenant details from Lease service via Feign client
        LeaseDTO lease;
        try {
            lease = leaseClient.getLeaseById(rentPaymentDTO.getLeaseId());
            log.info("Fetched lease details successfully for Lease ID: {}", rentPaymentDTO.getLeaseId());
        } catch (Exception e) {
            log.error("Failed to fetch lease details for Lease ID: {}", rentPaymentDTO.getLeaseId(), e);
            throw new LeaseNotFoundException("Lease not found with ID: " + rentPaymentDTO.getLeaseId());
        }

        // Save the rent payment to the repository
        RentPayments rentPayment = rentPaymentDTO.toEntity(rentPaymentDTO.getLeaseId());
        RentPayments savedPayment = rentPaymentRepository.save(rentPayment);
        log.info("Rent payment saved successfully: {}", savedPayment);

        // Trigger notification for payment success
        String message = "Your rent payment of ₹" + savedPayment.getAmount() + " was successful.";
        notificationService.createNotification(
                lease.getTenantId(),
                message,
                NotificationType.PAYMENT_SUCCESS
        );
        log.info("Payment success notification triggered for Tenant ID: {}", lease.getTenantId());

        return RentPaymentsDTO.fromEntity(savedPayment);
    }

    /**
     * Deletes a rent payment by its ID.
     *
     * @param paymentID The ID of the rent payment to delete.
     * @throws ResourceNotFoundException if the rent payment is not found.
     */
    public void deleteRentPayment(String paymentID) {
        log.info("Attempting to delete rent payment with ID: {}", paymentID);

        // Check if the rent payment exists
        if (!rentPaymentRepository.existsById(paymentID)) {
            log.error("Rent payment not found with ID: {}", paymentID);
            throw new ResourceNotFoundException("Rent payment not found with ID: " + paymentID);
        }

        // Delete the rent payment
        rentPaymentRepository.deleteById(paymentID);
        log.info("Rent payment with ID: {} deleted successfully.", paymentID);
    }

    /**
     * Fetches rent payments associated with a specific lease ID using DTOs.
     *
     * @param leaseId The ID of the lease.
     * @return A list of rent payment DTOs for the specified lease ID.
     * @throws LeaseNotFoundException if the lease is not found.
     */
    public List<RentPaymentsDTO> getRentPaymentsByLeaseId(String leaseId) {
        log.info("Fetching rent payments for Lease ID: {}", leaseId);

        // Validate lease ID via Feign client
        LeaseDTO lease;
        try {
            lease = leaseClient.getLeaseById(leaseId);
            log.info("Lease details validated for Lease ID: {}", leaseId);
        } catch (Exception e) {
            log.error("Failed to validate lease for Lease ID: {}", leaseId, e);
            throw new LeaseNotFoundException("Lease not found with ID: " + leaseId);
        }

        // Fetch rent payments for the lease ID
        return rentPaymentRepository.findAllByLeaseId(leaseId).stream()
                .map(RentPaymentsDTO::fromEntity)
                .collect(Collectors.toList());
    }

    /**
     * Updates the payment status of a rent payment by its ID and triggers a status update notification using DTOs.
     *
     * @param paymentID The ID of the rent payment to update.
     * @param status    The new payment status.
     * @return The updated rent payment DTO.
     * @throws ResourceNotFoundException if the rent payment is not found.
     */
    public RentPaymentsDTO updatePaymentStatus(String paymentID, PaymentStatus status) {
        log.info("Updating payment status for Rent Payment ID: {}", paymentID);

        // Fetch rent payment
        RentPayments rentPayment = rentPaymentRepository.findById(paymentID)
                .orElseThrow(() -> {
                    log.error("Rent payment not found with ID: {}", paymentID);
                    return new ResourceNotFoundException("Rent payment not found with ID: " + paymentID);
                });

        // Fetch lease details for the rent payment
        LeaseDTO lease = leaseClient.getLeaseById(rentPayment.getLeaseId());

        // Update payment status
        rentPayment.setStatus(status);
        rentPayment.setUpdatedAt(LocalDateTime.now());
        RentPayments updatedPayment = rentPaymentRepository.save(rentPayment);
        log.info("Payment status updated successfully for Rent Payment ID: {}", paymentID);

        // Trigger notification for status update
        String message = "Your rent payment status has been updated to " + status + ".";
        notificationService.createNotification(
                lease.getTenantId(),
                message,
                NotificationType.REMINDER // Adjust notification type as necessary
                );
                log.info("Payment status update notification triggered for Tenant ID: {}", lease.getTenantId());

                return RentPaymentsDTO.fromEntity(updatedPayment);
            }
        }











































//package com.example.rentpayment.service;
//
//import com.example.rentpayment.client.LeaseClient;
//import com.example.rentpayment.dto.LeaseDTO;
//import com.example.rentpayment.entity.RentPayments;
//import com.example.rentpayment.enums.NotificationType;
//import com.example.rentpayment.enums.PaymentStatus;
//import com.example.rentpayment.exception.LeaseNotFoundException;
//import com.example.rentpayment.exception.ResourceNotFoundException;
//import com.example.rentpayment.repository.RentPaymentRepository;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.util.List;
//
///**
// * Service class for managing rent payments.
// * Includes operations such as saving, updating, and retrieving rent payment details.
// * This service also triggers notifications for various rent payment events.
// */
//@Service
//@Slf4j
//public class RentPaymentService {
//
//    @Autowired
//    private RentPaymentRepository rentPaymentRepository;
//
//    @Autowired
//    private NotificationService notificationService;
//
//    @Autowired
//    private LeaseClient leaseClient;
//
//    /**
//     * Fetches all rent payments due within the next 3 days.
//     * Used by scheduled tasks to send reminders.
//     *
//     * @return A list of rent payments that are due soon.
//     */
//    public List<RentPayments> getDuePayments() {
//        log.info("Fetching rent payments due within the next 3 days.");
//        return rentPaymentRepository.findPaymentsDueSoon(LocalDate.now().plusDays(3));
//    }
//
//    /**
//     * Fetches all rent payments that are overdue as of today.
//     * Used by scheduled tasks to send overdue alerts.
//     *
//     * @return A list of overdue rent payments.
//     */
//    public List<RentPayments> getOverduePayments() {
//        log.info("Fetching rent payments that are overdue.");
//        return rentPaymentRepository.findOverduePayments(LocalDate.now());
//    }
//
//    /**
//     * Fetches all rent payments.
//     *
//     * @return A list of all rent payments.
//     */
//    public List<RentPayments> getAllRentPayments() {
//        log.info("Fetching all rent payments from the database.");
//        return rentPaymentRepository.findAll();
//    }
//
//    /**
//     * Fetches a specific rent payment by its ID.
//     *
//     * @param paymentID The ID of the rent payment to fetch.
//     * @return The rent payment entity.
//     * @throws ResourceNotFoundException if the rent payment is not found.
//     */
//    public RentPayments getRentPaymentById(String paymentID) {
//        log.info("Fetching rent payment with ID: {}", paymentID);
//        return rentPaymentRepository.findById(paymentID)
//                .orElseThrow(() -> new ResourceNotFoundException("Rent payment not found with ID: " + paymentID));
//    }
//
//    /**
//     * Saves a new rent payment and triggers a payment success notification.
//     *
//     * @param rentPayment The rent payment entity to save.
//     * @return The saved rent payment entity.
//     * @throws LeaseNotFoundException if lease details cannot be fetched from the lease service.
//     */
//    public RentPayments saveRentPayment(RentPayments rentPayment) {
//        log.info("Attempting to save rent payment: {}", rentPayment);
//
//        // Fetch tenant details from Lease service via Feign client
//        LeaseDTO lease;
//        try {
//            lease = leaseClient.getLeaseById(rentPayment.getLeaseId());
//            log.info("Fetched lease details successfully for Lease ID: {}", rentPayment.getLeaseId());
//        } catch (Exception e) {
//            log.error("Failed to fetch lease details for Lease ID: {}", rentPayment.getLeaseId(), e);
//            throw new LeaseNotFoundException("Lease not found with ID: " + rentPayment.getLeaseId());
//        }
//
//        // Save the rent payment to the repository
//        RentPayments savedPayment = rentPaymentRepository.save(rentPayment);
//        log.info("Rent payment saved successfully: {}", savedPayment);
//
//        // Trigger notification for payment success
//        String message = "Your rent payment of ₹" + savedPayment.getAmount() + " was successful.";
//        notificationService.createNotification(
//                lease.getTenantId(),
//                message,
//                NotificationType.PAYMENT_SUCCESS
//        );
//        log.info("Payment success notification triggered for Tenant ID: {}", lease.getTenantId());
//
//        return savedPayment;
//    }
//
//    /**
//     * Deletes a rent payment by its ID.
//     *
//     * @param paymentID The ID of the rent payment to delete.
//     * @throws ResourceNotFoundException if the rent payment is not found.
//     */
//    public void deleteRentPayment(String paymentID) {
//        log.info("Attempting to delete rent payment with ID: {}", paymentID);
//
//        // Check if the rent payment exists
//        if (!rentPaymentRepository.existsById(paymentID)) {
//            log.error("Rent payment not found with ID: {}", paymentID);
//            throw new ResourceNotFoundException("Rent payment not found with ID: " + paymentID);
//        }
//
//        // Delete the rent payment
//        rentPaymentRepository.deleteById(paymentID);
//        log.info("Rent payment with ID: {} deleted successfully.", paymentID);
//    }
//
//    /**
//     * Fetches rent payments associated with a specific lease ID.
//     *
//     * @param leaseId The ID of the lease.
//     * @return A list of rent payments for the specified lease ID.
//     * @throws LeaseNotFoundException if the lease is not found.
//     */
//    public List<RentPayments> getRentPaymentsByLeaseId(String leaseId) {
//        log.info("Fetching rent payments for Lease ID: {}", leaseId);
//
//        // Validate lease ID via Feign client
//        LeaseDTO lease;
//        try {
//            lease = leaseClient.getLeaseById(leaseId);
//            log.info("Lease details validated for Lease ID: {}", leaseId);
//        } catch (Exception e) {
//            log.error("Failed to validate lease for Lease ID: {}", leaseId, e);
//            throw new LeaseNotFoundException("Lease not found with ID: " + leaseId);
//        }
//
//        // Fetch rent payments for the lease ID
//        return rentPaymentRepository.findAllByLeaseId(leaseId);
//    }
//
//    /**
//     * Updates the payment status of a rent payment by its ID and triggers a status update notification.
//     *
//     * @param paymentID The ID of the rent payment to update.
//     * @param status    The new payment status.
//     * @return The updated rent payment entity.
//     * @throws ResourceNotFoundException if the rent payment is not found.
//     */
//    public RentPayments updatePaymentStatus(String paymentID, PaymentStatus status) {
//        log.info("Updating payment status for Rent Payment ID: {}", paymentID);
//
//        // Fetch rent payment
//        RentPayments rentPayment = rentPaymentRepository.findById(paymentID)
//                .orElseThrow(() -> {
//                    log.error("Rent payment not found with ID: {}", paymentID);
//                    return new ResourceNotFoundException("Rent payment not found with ID: " + paymentID);
//                });
//
//        // Fetch lease details for the rent payment
//        LeaseDTO lease = leaseClient.getLeaseById(rentPayment.getLeaseId());
//
//        // Update payment status
//        rentPayment.setStatus(status);
//        rentPayment.setUpdatedAt(LocalDateTime.now());
//        RentPayments updatedPayment = rentPaymentRepository.save(rentPayment);
//        log.info("Payment status updated successfully for Rent Payment ID: {}", paymentID);
//
//        // Trigger notification for status update
//        String message = "Your rent payment status has been updated to " + status + ".";
//        notificationService.createNotification(
//                lease.getTenantId(),
//                message,
//                NotificationType.REMINDER // Adjust notification type as necessary
//        );
//        log.info("Payment status update notification triggered for Tenant ID: {}", lease.getTenantId());
//
//        return updatedPayment;
//    }
//}




































