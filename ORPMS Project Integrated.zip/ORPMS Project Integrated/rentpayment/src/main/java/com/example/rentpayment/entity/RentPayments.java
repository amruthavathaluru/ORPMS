package com.example.rentpayment.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
//import jakarta.persistence.FetchType;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import lombok.Data;

//import java.math.BigDecimal;
//import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import com.example.rentpayment.enums.PaymentStatus;
import com.example.rentpayment.enums.PaymentType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Data
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class RentPayments {
	
    @Id
    private String paymentID;
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;

  
    private String leaseId;

    private LocalDateTime paymentDate;

    @Column(name = "amount", nullable = false)
    private double amount;

    @Enumerated(EnumType.STRING)
    private PaymentType method = PaymentType.cash;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status = PaymentStatus.payment_initiated;
    

    @PrePersist
    public void generateuuid() {
        this.paymentID = UUID.randomUUID().toString();
        this.createdAt = LocalDateTime.now();
    }

    @PreUpdate
    public void updateAtMethod() {
        this.updatedAt = LocalDateTime.now();
    }
}



