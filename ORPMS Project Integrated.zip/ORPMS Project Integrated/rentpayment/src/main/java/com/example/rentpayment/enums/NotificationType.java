package com.example.rentpayment.enums;

public enum NotificationType {
	REMINDER,
    PAYMENT_SUCCESS,
    PAYMENT_OVERDUE
}
