package com.example.rentpayment.repository;

import com.example.rentpayment.entity.RentPayments;
//import com.example.rentpayment.enums.PaymentStatus;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
@Repository
public interface RentPaymentRepository extends JpaRepository<RentPayments, String> {

//    @Query("SELECT rp FROM RentPayments rp WHERE rp.lease.leaseID = ?1")
    List<RentPayments> findAllByLeaseId(String leaseId);
    
    
    @Query("SELECT p FROM RentPayments p WHERE p.paymentDate BETWEEN :now AND :dueDate AND p.status = 'payment_initiated'")
    List<RentPayments> findPaymentsDueSoon(@Param("dueDate") LocalDate dueDate);

    @Query("SELECT p FROM RentPayments p WHERE p.paymentDate < :now AND p.status = 'payment_initiated'")
    List<RentPayments> findOverduePayments(@Param("now") LocalDate now);
    
}
