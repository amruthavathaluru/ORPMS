package com.example.rentpayment.controller;

import com.example.rentpayment.entity.Notification;
import com.example.rentpayment.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller to handle notification-related API requests.
 */
@RestController
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    /**
     * Fetches unread notifications for a tenant.
     *
     * @param tenantId The ID of the tenant.
     * @return A list of unread notifications.
     */
    @GetMapping("/tenant/{tenantId}")
    public ResponseEntity<List<Notification>> getNotificationsByTenantId(@PathVariable String tenantId) {
        List<Notification> notifications = notificationService.getNotificationsByTenantId(tenantId);
        return ResponseEntity.ok(notifications);
    }

    /**
     * Fetches unread notifications for an owner.
     *
     * @param ownerId The ID of the owner.
     * @return A list of unread notifications.
     */
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<Notification>> getNotificationsByOwnerId(@PathVariable String ownerId) {
        List<Notification> notifications = notificationService.getNotificationsByOwnerId(ownerId);
        return ResponseEntity.ok(notifications);
    }
    
    
    //post
}
