package com.example.rentpayment.dto;

//import com.example.rentpayment.entity.Lease;
import com.example.rentpayment.entity.RentPayments;
import com.example.rentpayment.enums.PaymentStatus;
import com.example.rentpayment.enums.PaymentType;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.time.LocalDate;

/**
 * Data Transfer Object (DTO) for RentPayments.
 */

@Data
public class RentPaymentsDTO {

	 private String paymentID;

	    @NotNull(message = "Payment date cannot be null")
	    private LocalDate paymentDate;

	    @Positive(message = "Amount must be positive")
	    private double amount;

	    @NotNull(message = "Payment method cannot be null")
	    private PaymentType method;

	    @NotNull(message = "Payment status cannot be null")
	    private PaymentStatus status;

	    @NotNull(message = "Lease ID cannot be null")
	    private String leaseId; // Add this field

	    /**
	     * Converts an entity to a DTO.
	     * @param rentPayment The rent payment entity to convert.
	     * @return The rent payment DTO.
	     */

    public static RentPaymentsDTO fromEntity(RentPayments rentPayment) {
        RentPaymentsDTO dto = new RentPaymentsDTO();
        dto.setPaymentID(rentPayment.getPaymentID());
//        dto.setPaymentDate(rentPayment.getPaymentDate());
        dto.setAmount(rentPayment.getAmount());
        dto.setMethod(rentPayment.getMethod());
        dto.setStatus(rentPayment.getStatus());
        dto.setLeaseId(rentPayment.getLeaseId()); // Set leaseId
        return dto;
    }

    /**
     * Converts a DTO to an entity.
     * @param lease The lease entity to associate with the rent payment.
     * @return The rent payment entity.
     */
    public RentPayments toEntity(String leaseID) {
        RentPayments entity = new RentPayments();
        entity.setPaymentID(this.paymentID);
//        entity.setPaymentDate(this.paymentDate);
        entity.setAmount(this.amount);
        entity.setMethod(this.method);
        entity.setStatus(this.status);
        entity.setLeaseId(leaseID);
        return entity;
    }

	
}