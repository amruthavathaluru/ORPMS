package com.example.rentpayment.client;

import com.example.rentpayment.dto.LeaseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client to communicate with the lease service.
 * Provides methods to fetch lease details by lease ID.
 */
@FeignClient(name = "lease") // Replace "lease-service" with the actual service name registered in Eureka/Discovery Server
public interface LeaseClient {

    /**
     * Fetches lease details by lease ID.
     *
     * @param leaseId The ID of the lease.
     * @return LeaseDTO containing lease details.
     */
    @GetMapping("/leases/{leaseId}")
    LeaseDTO getLeaseById(@PathVariable("leaseId") String leaseId);
}
