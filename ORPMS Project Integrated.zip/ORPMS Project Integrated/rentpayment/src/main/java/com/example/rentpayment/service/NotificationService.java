package com.example.rentpayment.service;

import com.example.rentpayment.client.LeaseClient;
import com.example.rentpayment.dto.LeaseDTO;
import com.example.rentpayment.entity.Notification;
import com.example.rentpayment.enums.NotificationType;
import com.example.rentpayment.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service to handle notification logic, including sending reminders and fetching unread notifications.
 */
@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private LeaseClient leaseClient;

    /**
     * Creates a new notification.
     *
     * @param recipientId The ID of the notification recipient.
     * @param message The message of the notification.
     * @param type The type of notification.
     * @return The created Notification object.
     */
    public Notification createNotification(String recipientId, String message, NotificationType type) {
        Notification notification = new Notification();
        notification.setRecipientId(recipientId);
        notification.setMessage(message);
        notification.setType(type);
        notification.setCreatedAt(LocalDateTime.now());
        return notificationRepository.save(notification);
    }

    /**
     * Sends a rent payment reminder notification to a tenant based on lease ID.
     *
     * @param leaseId The ID of the lease.
     */
    public void sendReminderNotification(String leaseId) {
        LeaseDTO lease = leaseClient.getLeaseById(leaseId); // Fetch lease details using Feign client
        String message = "Reminder: Your rent payment is due soon.";
        createNotification(lease.getTenantId(), message, NotificationType.REMINDER);
    }

    /**
     * Fetches all unread notifications for a specific tenant.
     *
     * @param tenantId The ID of the tenant.
     * @return A list of unread notifications.
     */
    public List<Notification> getNotificationsByTenantId(String tenantId) {
        return notificationRepository.findByRecipientIdAndIsRead(tenantId, false);
    }

    /**
     * Fetches all unread notifications for a specific owner.
     *
     * @param ownerId The ID of the owner.
     * @return A list of unread notifications.
     */
    public List<Notification> getNotificationsByOwnerId(String ownerId) {
        return notificationRepository.findByRecipientIdAndIsRead(ownerId, false);
    }
}
