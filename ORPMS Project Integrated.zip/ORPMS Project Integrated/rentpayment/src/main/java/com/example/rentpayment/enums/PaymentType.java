package com.example.rentpayment.enums;

public enum PaymentType {
	debit,
	upi,
	credit,
	cash;
}
