package com.example.rentpayment.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * LeaseDTO represents the data structure for lease details.
 * This DTO is used for communication with the lease service via Feign Client.
 */
@Data
public class LeaseDTO {

    @NotBlank(message = "Lease ID cannot be blank")
    private String leaseId;

    @NotBlank(message = "Tenant ID cannot be blank")
    private String tenantId;

    @NotBlank(message = "Owner ID cannot be blank")
    private String ownerId;

    @NotBlank(message = "Property ID cannot be blank")
    private String propertyId;

    @NotNull(message = "Lease status cannot be null")
    private String leaseStatus;

    @NotBlank(message = "Start date cannot be blank")
    @Pattern(regexp = "\\d{4}-\\d{2}-\\d{2}", message = "Start date must be in the format YYYY-MM-DD")
    private String startDate;

    @NotBlank(message = "End date cannot be blank")
    @Pattern(regexp = "\\d{4}-\\d{2}-\\d{2}", message = "End date must be in the format YYYY-MM-DD")
    private String endDate;
}
