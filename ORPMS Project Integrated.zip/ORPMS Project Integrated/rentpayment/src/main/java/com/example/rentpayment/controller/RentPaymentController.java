
//package com.example.rentpayment.controller;
//
//import com.example.rentpayment.dto.RentPaymentsDTO;
//import com.example.rentpayment.dto.UpdatePaymentStatusRequest;
//import com.example.rentpayment.entity.Lease;
//import com.example.rentpayment.entity.RentPayments;
//import com.example.rentpayment.service.LeaseService;
//import com.example.rentpayment.service.RentPaymentService;
//
//import jakarta.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import lombok.extern.slf4j.Slf4j;
//
//import java.util.List;
//import java.util.stream.Collectors;
//@RestController
//@RequestMapping("/api/rentpayments")
//@Slf4j
//public class RentPaymentController {
//
//    @Autowired
//    private RentPaymentService rentPaymentService;
//    @Autowired
//    private LeaseService leaseService;
//
//    /**
//     * Fetches all rent payments.
//     * @return ResponseEntity containing a list of rent payment DTOs.
//     */
//    @GetMapping("/all")
//    public ResponseEntity<List<RentPaymentsDTO>> getAllRentPayments() {
//        log.info("Log.enter: Entering getAllRentPayments");
//        List<RentPaymentsDTO> rentPayments = rentPaymentService.getAllRentPayments().stream()
//                .map(RentPaymentsDTO::fromEntity)
//                .collect(Collectors.toList());
//        log.info("Log.exit: Exiting getAllRentPayments");
//        return ResponseEntity.ok(rentPayments);
//    }
//
//    /**
//     * Fetches a rent payment by its ID.
//     * @param id The ID of the rent payment to fetch.
//     * @return ResponseEntity containing the rent payment DTO.
//     */
//    @GetMapping("/{id}")
//    public ResponseEntity<RentPaymentsDTO> getRentPaymentById(@PathVariable String id) {
//        log.info("Log.enter: Fetching rent payment with ID: {}", id);
//        RentPayments rentPayment = rentPaymentService.getRentPaymentById(id);
//        log.info("Log.exit: Rent payment fetched with ID: {}", id);
//        return ResponseEntity.ok(RentPaymentsDTO.fromEntity(rentPayment));
//    }
//
//    /**
//     * Creates a new rent payment.
//     * @param rentPaymentDTO The rent payment DTO to create.
//     * @return ResponseEntity containing the created rent payment DTO.
//     */
//    @PostMapping("/create")
//    public ResponseEntity<RentPaymentsDTO> createRentPayment(@RequestBody @Valid RentPaymentsDTO rentPaymentDTO) {
//        log.info("Log.enter: Creating a new rent payment");
//        Lease lease = leaseService.getLeaseById(rentPaymentDTO.getLeaseId()); // Fetch the lease entity
//        RentPayments createdRentPayment = rentPaymentService.saveRentPayment(rentPaymentDTO.toEntity(lease));
//        log.info("Log.exit: Rent payment created");
//        return ResponseEntity.status(HttpStatus.CREATED).body(RentPaymentsDTO.fromEntity(createdRentPayment));
//    }
//
//    /**
//     * Deletes a rent payment by its ID.
//     * @param id The ID of the rent payment to delete.
//     * @return ResponseEntity with no content.
//     */
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteRentPayment(@PathVariable String id) {
//        log.info("Log.enter: Deleting rent payment with ID: {}", id);
//        rentPaymentService.deleteRentPayment(id);
//        log.info("Log.exit: Rent payment deleted with ID: {}", id);
//        return ResponseEntity.noContent().build();
//    }
//
//    /**
//     * Updates the payment status of a rent payment by its ID.
//     * @param id The ID of the rent payment to update.
//     * @param request The request containing the new payment status.
//     * @return ResponseEntity containing the updated rent payment DTO.
//     */
//    @PutMapping("/{id}/status")
//    public ResponseEntity<RentPaymentsDTO> updatePaymentStatus(@PathVariable String id, @RequestBody @Valid UpdatePaymentStatusRequest request) {
//        log.info("Log.enter: Updating payment status for ID: {}", id);
//        RentPayments updatedRentPayment = rentPaymentService.updatePaymentStatus(id, request.getStatus());
//        log.info("Log.exit: Payment status updated for ID: {}", id);
//        return ResponseEntity.ok(RentPaymentsDTO.fromEntity(updatedRentPayment));
//    }
//
//    /**
//     * Fetches rent payments by lease ID.
//     * @param leaseId The ID of the lease.
//     * @return ResponseEntity containing a list of rent payment DTOs.
//     */
//    @GetMapping("/lease/{leaseId}")
//    public ResponseEntity<List<RentPaymentsDTO>> getRentPaymentsByLeaseId(@PathVariable String leaseId) {
//        log.info("Log.enter: Fetching rent payments for lease ID: {}", leaseId);
//        List<RentPayments> rentPayments = rentPaymentService.getRentPaymentsByLeaseId(leaseId);
//        List<RentPaymentsDTO> rentPaymentsDTOs = rentPayments.stream()
//                .map(RentPaymentsDTO::fromEntity)
//                .collect(Collectors.toList());
//        log.info("Log.exit: Rent payments fetched for lease ID: {}", leaseId);
//        return ResponseEntity.ok(rentPaymentsDTOs);
//    }
//}

package com.example.rentpayment.controller;

import com.example.rentpayment.dto.RentPaymentsDTO;
import com.example.rentpayment.dto.UpdatePaymentStatusRequest;
import com.example.rentpayment.service.RentPaymentService;
import com.example.rentpayment.exception.ResourceNotFoundException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.validation.Valid;

@Slf4j
@RestController
@RequestMapping("/api/rentpayments")
public class RentPaymentController {

    @Autowired
    private RentPaymentService rentPaymentService;

    /**
     * Fetches all rent payments.
     *
     * @return ResponseEntity containing a list of rent payment DTOs.
     */
    @GetMapping("/all")
    public ResponseEntity<ResultResponse<List<RentPaymentsDTO>>> getAllRentPayments() {
        log.info("Fetching all rent payments");
        try {
            List<RentPaymentsDTO> rentPayments = rentPaymentService.getAllRentPayments();
            return ResponseEntity.ok(ResultResponse.<List<RentPaymentsDTO>>builder()
                    .success(true)
                    .message("All rent payments fetched successfully")
                    .data(rentPayments)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error fetching all rent payments: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<RentPaymentsDTO>>builder()
                    .success(false)
                    .message("Internal server error while fetching all rent payments")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Fetches a rent payment by its ID.
     *
     * @param id The ID of the rent payment to fetch.
     * @return ResponseEntity containing the rent payment DTO.
     */
    @GetMapping("/{id}")
    public ResponseEntity<ResultResponse<RentPaymentsDTO>> getRentPaymentById(@PathVariable String id) {
        log.info("Fetching rent payment with ID: {}", id);
        try {
            RentPaymentsDTO rentPayment = rentPaymentService.getRentPaymentById(id);
            return ResponseEntity.ok(ResultResponse.<RentPaymentsDTO>builder()
                    .success(true)
                    .message("Rent payment fetched successfully")
                    .data(rentPayment)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (ResourceNotFoundException e) {
            log.error("Rent payment not found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<RentPaymentsDTO>builder()
                    .success(false)
                    .message("Rent payment not found with ID: " + id)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error fetching rent payment: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<RentPaymentsDTO>builder()
                    .success(false)
                    .message("Internal server error while fetching rent payment")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Creates a new rent payment.
     *
     * @param rentPaymentDTO The rent payment DTO to create.
     * @return ResponseEntity containing the created rent payment DTO.
     */
    @PostMapping("/create")
    public ResponseEntity<ResultResponse<RentPaymentsDTO>> createRentPayment(@RequestBody @Valid RentPaymentsDTO rentPaymentDTO) {
        log.info("Creating a new rent payment");
        try {
            RentPaymentsDTO createdRentPayment = rentPaymentService.saveRentPayment(rentPaymentDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(ResultResponse.<RentPaymentsDTO>builder()
                    .success(true)
                    .message("Rent payment created successfully")
                    .data(createdRentPayment)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (ResourceNotFoundException e) {
            log.error("Lease not found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<RentPaymentsDTO>builder()
                    .success(false)
                    .message("Lease not found with ID: " + rentPaymentDTO.getLeaseId())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error creating rent payment: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<RentPaymentsDTO>builder()
                    .success(false)
                    .message("Internal server error while creating rent payment")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Updates the payment status of a rent payment by its ID.
     *
     * @param id The ID of the rent payment to update.
     * @param request The request containing the new payment status.
     * @return ResponseEntity containing the updated rent payment DTO.
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<ResultResponse<RentPaymentsDTO>> updatePaymentStatus(@PathVariable String id, @RequestBody @Valid UpdatePaymentStatusRequest request) {
        log.info("Updating payment status for ID: {}", id);
        try {
            RentPaymentsDTO updatedRentPayment = rentPaymentService.updatePaymentStatus(id, request.getStatus());
            return ResponseEntity.ok(ResultResponse.<RentPaymentsDTO>builder()
                    .success(true)
                    .message("Payment status updated successfully")
                    .data(updatedRentPayment)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (ResourceNotFoundException e) {
            log.error("Rent payment not found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<RentPaymentsDTO>builder()
                    .success(false)
                    .message("Rent payment not found with ID: " + id)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error updating payment status: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<RentPaymentsDTO>builder()
                    .success(false)
                    .message("Internal server error while updating payment status")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Deletes a rent payment by its ID.
     *
     * @param id The ID of the rent payment to delete.
     * @return ResponseEntity indicating success or failure.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ResultResponse<Void>> deleteRentPayment(@PathVariable String id) {
        log.info("Deleting rent payment with ID: {}", id);
        try {
            rentPaymentService.deleteRentPayment(id);
            return ResponseEntity.ok(ResultResponse.<Void>builder()
                    .success(true)
                    .message("Rent payment deleted successfully")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (ResourceNotFoundException e) {
            log.error("Rent payment not found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
                    .success(false)
                    .message("Rent payment not found with ID: " + id)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error deleting rent payment: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<Void>builder()
                    .success(false)
                    .message("Internal server error while deleting rent payment")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Fetches rent payments by lease ID.
     *
     * @param leaseId The ID of the lease.
     * @return ResponseEntity containing a list of rent payment DTOs.
     */
    @GetMapping("/lease/{leaseId}")
    public ResponseEntity<ResultResponse<List<RentPaymentsDTO>>> getRentPaymentsByLeaseId(@PathVariable String leaseId) {
        log.info("Fetching rent payments for lease ID: {}", leaseId);
        try {
            List<RentPaymentsDTO> rentPaymentsDTOs = rentPaymentService.getRentPaymentsByLeaseId(leaseId);
            return ResponseEntity.ok(ResultResponse.<List<RentPaymentsDTO>>builder()
                    .success(true)
                    .message("Rent payments fetched")
                    		.data(rentPaymentsDTOs)
                            .timestamp(LocalDateTime.now())
                            .build());
                } catch (Exception e) {
                    log.error("Error fetching rent payments: {}", e.getMessage(), e);
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<RentPaymentsDTO>>builder()
                            .success(false)
                            .message("Internal server error while fetching rent payments")
                            .timestamp(LocalDateTime.now())
                            .build());
                }
            }
        }		
















































