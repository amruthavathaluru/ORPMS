package com.example.rentpayment.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

import com.example.rentpayment.enums.NotificationType;

@Entity
@Data
public class Notification {

    @Id
    @GeneratedValue
    private UUID notificationId;

    @Column(nullable = false)
    private String recipientId;

    @Column(nullable = false, length = 500)
    private String message;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private Boolean isRead = false;

    @Enumerated(EnumType.STRING)
    private NotificationType type; 
}