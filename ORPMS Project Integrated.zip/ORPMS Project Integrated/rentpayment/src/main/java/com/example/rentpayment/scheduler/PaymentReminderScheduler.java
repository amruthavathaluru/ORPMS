package com.example.rentpayment.scheduler;

import com.example.rentpayment.client.LeaseClient;
import com.example.rentpayment.dto.LeaseDTO;
import com.example.rentpayment.dto.RentPaymentsDTO;
import com.example.rentpayment.enums.NotificationType;
import com.example.rentpayment.service.NotificationService;
import com.example.rentpayment.service.RentPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Scheduler to handle periodic notifications for rent payments.
 * Sends reminders for due payments and overdue alerts.
 */
@Component
public class PaymentReminderScheduler {

    @Autowired
    private RentPaymentService rentPaymentService;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private LeaseClient leaseClient;

    /**
     * Sends reminders for rent payments due soon.
     * Scheduled to run every day at 8 AM.
     */
    @Scheduled(cron = "0 0 8 * * ?") // Adjust cron as needed
    public void sendPaymentReminders() {
        List<RentPaymentsDTO> duePayments = rentPaymentService.getDuePayments();

        for (RentPaymentsDTO payment : duePayments) {
            LeaseDTO lease = leaseClient.getLeaseById(payment.getLeaseId()); // Fetch lease details
            if(lease != null) {
                String message = "Reminder: Your rent payment of ₹" + payment.getAmount() + " is due on " + payment.getPaymentDate() + ".";
                notificationService.createNotification(lease.getTenantId(), message, NotificationType.REMINDER);
            } else {
                // handle lease not found. Log an error, or take other appropriate action.
                System.err.println("Lease not found for rent payment ID: " + payment.getPaymentDate());
            }
        }
    }

    /**
     * Sends alerts for overdue payments.
     * Scheduled to run every day at 9 AM.
     */
    @Scheduled(cron = "0 0 9 * * ?")
    public void sendOverduePaymentAlerts() {
        List<RentPaymentsDTO> overduePayments = rentPaymentService.getOverduePayments();

        for (RentPaymentsDTO payment : overduePayments) {
            LeaseDTO lease = leaseClient.getLeaseById(payment.getLeaseId()); // Fetch lease details
            if(lease != null) {
                String message = "Alert: Your rent payment of ₹" + payment.getAmount() + " was overdue since " + payment.getPaymentDate() + ". Please pay immediately.";
                notificationService.createNotification(lease.getTenantId(), message, NotificationType.PAYMENT_OVERDUE);
            } else {
                // handle lease not found. Log an error, or take other appropriate action.
                System.err.println("Lease not found for rent payment ID: " + payment.getPaymentDate());
            }
        }
    }
}