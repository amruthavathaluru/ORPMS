package com.example.rentpayment.controller;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Data;

/**
 * A generic class to standardize API responses across the application.
 * Provides a consistent structure for response objects, including metadata
 * like success status, error or success messages, and timestamps.
 * 
 * @param <T> The type of data returned in the API response (e.g., entity, DTO, or list).
 */
@Data
@Builder
public class ResultResponse<T> {

    /**
     * Indicates whether the operation was successful or not.
     * True for success, false for failure.
     */
    private boolean success;

    /**
     * A message describing the outcome of the operation.
     * Can provide details about success or failure.
     */
    private String message;

    /**
     * The actual data returned by the operation.
     * This can be any type, such as an object, DTO, or a list.
     */
    private T data;

    /**
     * The timestamp when the response was generated.
     * Useful for tracking and debugging API responses.
     */
    private LocalDateTime timestamp;

    /**
     * Static method to create a new builder instance for constructing 
     * ResultResponse objects in a fluent manner.
     *
     * @param <T> The type of the data returned in the response.
     * @return A new ResultResponseBuilder instance.
     */
    public static <T> ResultResponseBuilder<T> builder() {
        return new ResultResponseBuilder<>();
    }

    /**
     * Inner static class to provide a fluent API for constructing ResultResponse objects.
     * Uses the Builder design pattern to simplify the creation of response objects.
     * 
     * @param <T> The type of the data returned in the response.
     */
    public static class ResultResponseBuilder<T> {
        // Indicates the success status of the operation.
        private boolean success;
        
        // Message describing the outcome of the operation.
        private String message;
        
        // The actual data returned in the response.
        private T data;
        
        // The timestamp for the response generation.
        private LocalDateTime timestamp;

        /**
         * Default constructor for the ResultResponseBuilder class.
         */
        ResultResponseBuilder() {
        }

        /**
         * Sets the success status of the response.
         * 
         * @param success True if the operation was successful, false otherwise.
         * @return The current instance of ResultResponseBuilder for method chaining.
         */
        public ResultResponseBuilder<T> success(boolean success) {
            this.success = success;
            return this;
        }

        /**
         * Sets the message for the response.
         * 
         * @param message The descriptive message about the operation outcome.
         * @return The current instance of ResultResponseBuilder for method chaining.
         */
        public ResultResponseBuilder<T> message(String message) {
            this.message = message;
            return this;
        }

        /**
         * Sets the data to be included in the response.
         * 
         * @param data The actual data returned by the operation.
         * @return The current instance of ResultResponseBuilder for method chaining.
         */
        public ResultResponseBuilder<T> data(T data) {
            this.data = data;
            return this;
        }

        /**
         * Sets the timestamp for the response.
         * 
         * @param timestamp The timestamp indicating when the response was generated.
         * @return The current instance of ResultResponseBuilder for method chaining.
         */
        public ResultResponseBuilder<T> timestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        /**
         * Builds the ResultResponse object using the provided values.
         *
         * @return A new ResultResponse instance with the configured properties.
         */
        public ResultResponse<T> build() {
            return new ResultResponse<>(success, message, data, timestamp);
        }

        /**
         * Provides a string representation of the ResultResponseBuilder instance.
         * Useful for debugging purposes.
         *
         * @return A string representation of the ResultResponseBuilder object.
         */
        public String toString() {
            return "ResultResponse.ResultResponseBuilder(success=" + this.success + 
                   ", message=" + this.message + 
                   ", data=" + this.data + 
                   ", timestamp=" + this.timestamp + ")";
        }
    }
}
