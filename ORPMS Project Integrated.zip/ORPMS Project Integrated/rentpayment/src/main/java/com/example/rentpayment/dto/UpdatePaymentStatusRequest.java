//package com.example.rentpayment.dto;
//
//import com.example.rentpayment.enums.PaymentStatus;
//
//import lombok.Data;
//
//@Data
//	public class UpdatePaymentStatusRequest {
//	    private PaymentStatus status;
//	}

package com.example.rentpayment.dto;

import com.example.rentpayment.enums.PaymentStatus;
import lombok.Data;

@Data
public class UpdatePaymentStatusRequest {
    private PaymentStatus status;
}
