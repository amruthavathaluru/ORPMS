package com.example.rentpayment.enums;

public enum PaymentStatus {
	payment_initiated,
	amount_received,
	payment_done,
//	SUCCESS,
//	FAILED;
}
