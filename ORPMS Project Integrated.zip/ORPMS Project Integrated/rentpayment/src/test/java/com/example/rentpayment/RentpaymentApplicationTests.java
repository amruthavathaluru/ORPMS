package com.example.rentpayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentpaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
