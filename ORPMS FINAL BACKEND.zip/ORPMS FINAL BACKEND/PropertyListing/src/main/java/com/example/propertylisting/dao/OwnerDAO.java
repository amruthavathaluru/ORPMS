package com.example.propertylisting.dao;

import com.example.propertylisting.entity.Owner;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OwnerDAO extends JpaRepository<Owner, String> {
	 Optional<Owner> findById(String ownerID);
}



















//package com.example.propertylisting.dao;
//
//import com.example.propertylisting.entity.Owner;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//import org.springframework.stereotype.Repository;
//import java.util.List;
////import java.util.UUID;
//
//@Repository
//public interface OwnerDAO extends JpaRepository<Owner, String> {
//
//    //  Find an owner by name (case-insensitive)
//    @Query("SELECT o FROM Owner o WHERE LOWER(o.name) LIKE LOWER(CONCAT('%', :name, '%'))")
//    List<Owner> findByName(@Param("name") String name);
//
//    //  Find an owner by gender
//    @Query("SELECT o FROM Owner o WHERE LOWER(o.gender) = LOWER(:gender)")
//    List<Owner> findByGender(@Param("gender") String gender);
//
//    //  Find an owner by contact number
//    @Query("SELECT o FROM Owner o WHERE o.contactNo = :contactNo")
//    Owner findByContactNo(@Param("contactNo") String contactNo);
//
//    //  Find an owner by email
//    @Query("SELECT o FROM Owner o WHERE LOWER(o.email) = LOWER(:email)")
//    Owner findByEmail(@Param("email") String email);
//}
