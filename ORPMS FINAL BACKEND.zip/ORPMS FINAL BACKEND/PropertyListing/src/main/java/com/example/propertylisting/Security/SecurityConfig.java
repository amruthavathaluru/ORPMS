package com.example.propertylisting.Security;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
 
import jakarta.ws.rs.HttpMethod;
 
@Configuration
@EnableWebSecurity
public class SecurityConfig {
 
    @Autowired
    private JwtFilter jwtFilter;
 
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
 
        return http.csrf(customizer -> customizer.disable())
                .authorizeHttpRequests(request -> request
                		
                		  // **ADD THIS RULE TO ALLOW LEASE SERVICE TO MARK PROPERTY AS RENTED**
                        .requestMatchers(HttpMethod.PUT, "/properties/*/rented/*").permitAll()
                        // OwnerController Endpoints
                        .requestMatchers("/owners/create").permitAll() // Publicly accessible (e.g., new owner registration)
                       // .requestMatchers("/owners/{ownerId}").hasAuthority("OWNER") // View owner details
                        .requestMatchers("/owners/{ownerId}").permitAll()
                        .requestMatchers("/owners/all").permitAll() // Fetch all owners (admin-only access)
                        .requestMatchers("/owners/update/{ownerId}").hasAuthority("OWNER") // Update owner (owner-only access)
                        .requestMatchers("/owners/delete/{ownerId}").hasAuthority("OWNER")// Delete owner (admin-only access)
                        .requestMatchers("/owners/{ownerId}/notifications").hasAuthority("OWNER") // View owner notifications
                        .requestMatchers("/owners/{ownerId}/rent-payments").hasAuthority("OWNER") // View owner rent payments
 
                        // PropertyController Endpoints
                        //.requestMatchers("/properties/owner/{ownerId}").hasAuthority("OWNER")
                        .requestMatchers(HttpMethod.OPTIONS, "/properties/owner/**").permitAll()// Add property
                        .requestMatchers("/properties/{propertyId}").permitAll() // Public access to view property details
                        .requestMatchers("properties/tenant/{tenantId}").permitAll()
                        .requestMatchers("/properties").permitAll() // Public access to list all properties
                        .requestMatchers("/properties/owner/{ownerId}/{propertyId}").hasAuthority("OWNER") // Update/delete property
                        .requestMatchers("/properties/search").permitAll() // Public access to search properties
                        .requestMatchers("/properties/owner/{ownerId}").hasAuthority("OWNER") // Owner's properties
                   

 
                        // Any other request
                        .anyRequest().authenticated())
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }
    
 
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins("http://localhost:3000")
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                        .allowedHeaders("*")
                        .allowCredentials(true);
            }
        };
    }
}
 
 
 