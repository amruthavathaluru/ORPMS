package com.example.propertylisting.Service;
 
import com.example.propertylisting.dto.OwnerDTO;
import com.example.propertylisting.dto.PropertyDTO;
import com.example.propertylisting.entity.Owner;
import com.example.propertylisting.entity.Property;
import com.example.propertylisting.entity.PropertyAvailabilityStatus;
import com.example.propertylisting.exception.PropertyNotFound;
import com.example.propertylisting.exception.ResourceNotFoundException;
import com.example.propertylisting.dao.OwnerDAO;
import com.example.propertylisting.dao.PropertyDAO;
import com.example.propertylisting.utils.ResultResponse; // Assuming you have ResultResponse
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
 
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
 
@Service
public class PropertyServiceImpl implements PropertyService {
 
    private static final Logger logger = LoggerFactory.getLogger(PropertyServiceImpl.class);
 
    @Autowired
    private PropertyDAO propertyDAO;
 
    @Autowired
    private OwnerDAO ownerDAO;
 
    @Override
    public ResponseEntity<ResultResponse<PropertyDTO>> addProperty(PropertyDTO propertyDTO, String ownerId) {
        logger.info("Attempting to add property for ownerId: {}", ownerId);

        try {
            Owner owner = ownerDAO.findById(ownerId)
                    .orElseThrow(() -> new PropertyNotFound("Owner with ID " + ownerId + " not found."));

            Property property = new Property();
            property.setPropertyName(propertyDTO.getPropertyName());
            property.setAddress(propertyDTO.getAddress());
            property.setType(propertyDTO.getType());
            property.setPrice(propertyDTO.getPrice());
            property.setRentalTerms(propertyDTO.getRentalTerms());
            property.setImageUrls(propertyDTO.getImageUrls());
            property.setAvailabilityStatus(PropertyAvailabilityStatus.valueOf(propertyDTO.getAvailabilityStatus()));
            property.setOwner(owner);

            property = propertyDAO.save(property);
            logger.info("Property added successfully for ownerId: {}", ownerId);

            PropertyDTO result = new PropertyDTO(property);
            result.setOwnerID(UUID.fromString(owner.getOwnerID()));
            return ResponseEntity.ok(ResultResponse.<PropertyDTO>builder()
                    .success(true)
                    .data(result)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (PropertyNotFound e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @Override
    public ResponseEntity<ResultResponse<PropertyDTO>> updateProperty(String propertyId, PropertyDTO propertyDTO, String ownerId) {
        logger.info("Attempting to update property with ID: {} for ownerId: {}", propertyId, ownerId);
 
        try {
            Property property = propertyDAO.findById(propertyId)
                    .orElseThrow(() -> new PropertyNotFound("Property with ID " + propertyId + " not found."));
 
            if (!property.getOwner().getOwnerID().equals(ownerId)) {
                throw new PropertyNotFound("Owner with ID " + ownerId + " does not own the property with ID " + propertyId + ".");
            }
 
            property.setPropertyName(propertyDTO.getPropertyName());
            property.setAddress(propertyDTO.getAddress());
            property.setType(propertyDTO.getType());
            property.setPrice(propertyDTO.getPrice());
            property.setRentalTerms(propertyDTO.getRentalTerms());
            property.setImageUrls(propertyDTO.getImageUrls());
            property.setAvailabilityStatus(PropertyAvailabilityStatus.valueOf(propertyDTO.getAvailabilityStatus()));
 
            property = propertyDAO.save(property);
            logger.info("Property updated successfully for propertyId: {}", propertyId);
 
            PropertyDTO result = new PropertyDTO(property);
 
            return ResponseEntity.ok(ResultResponse.<PropertyDTO>builder()
                    .success(true)
                    .data(result)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (PropertyNotFound e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @Override
    public ResponseEntity<ResultResponse<Void>> deleteProperty(String propertyId, String ownerId) {
        logger.info("Attempting to delete property with ID: {} for ownerId: {}", propertyId, ownerId);
        try {
            Property property = propertyDAO.findById(propertyId)
                    .orElseThrow(() -> new PropertyNotFound("Property with ID " + propertyId + " not found."));
 
            if (!property.getOwner().getOwnerID().equals(ownerId)) {
                throw new PropertyNotFound("Owner with ID " + ownerId + " does not own the property with ID " + propertyId + ".");
            }
 
            propertyDAO.delete(property);
            logger.info("Property deleted successfully for propertyId: {}", propertyId);
 
            return ResponseEntity.ok(ResultResponse.<Void>builder()
                    .success(true)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (PropertyNotFound e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Void>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<Void>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @Override
    public ResponseEntity<ResultResponse<PropertyDTO>> getPropertyById(String propertyId) {
        logger.info("Fetching property with ID: {}", propertyId);
 
        try {
            Property property = propertyDAO.findById(propertyId)
                    .orElseThrow(() -> new PropertyNotFound("Property with ID " + propertyId + " not found."));
 
            logger.info("Property fetched successfully with ID: {}", propertyId);
            return ResponseEntity.ok(ResultResponse.<PropertyDTO>builder()
                    .success(true)
                    .data(new PropertyDTO(property))
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (PropertyNotFound e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @Override
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> getAllProperties() {
        logger.info("Fetching all properties");
        try {
            List<Property> properties = propertyDAO.findAll();
            logger.info("Fetched {} properties", properties.size());
            List<PropertyDTO> propertyDTOs = properties.stream().map(PropertyDTO::new).collect(Collectors.toList());
            return ResponseEntity.ok(ResultResponse.<List<PropertyDTO>>builder()
                    .success(true)
                    .data(propertyDTOs)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<PropertyDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @Override
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> getPropertiesByOwner(String ownerId) {
        logger.info("Fetching properties for ownerId: {}", ownerId);
 
        try {
            List<Property> properties = propertyDAO.findByOwnerId(ownerId);
 
            if (properties.isEmpty()) {
                logger.warn("No properties found for ownerId: {}", ownerId);
            } else {
                logger.info("Fetched {} properties for ownerId: {}", properties.size(), ownerId);
            }
 
            List<PropertyDTO> propertyDTOs = properties.stream().map(PropertyDTO::new).collect(Collectors.toList());
            return ResponseEntity.ok(ResultResponse.<List<PropertyDTO>>builder()
                    .success(true)
                    .data(propertyDTOs)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<PropertyDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @Override
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> searchProperties(String location, String type, Double minPrice, Double maxPrice) {
        logger.info("Searching properties with filters - location: {}, type: {}, minPrice: {}, maxPrice: {}", location, type, minPrice, maxPrice);
 
        try {
            List<Property> properties = propertyDAO.searchProperties(location, type, minPrice, maxPrice);
 
            logger.info("Fetched {} properties matching filters", properties.size());
            List<PropertyDTO> propertyDTOs = properties.stream().map(PropertyDTO::new).collect(Collectors.toList());
 
            return ResponseEntity.ok(ResultResponse.<List<PropertyDTO>>builder()
                    .success(true)
                    .data(propertyDTOs)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<PropertyDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
 
    @Transactional
    @Override
    public ResponseEntity<ResultResponse<PropertyDTO>> updatePropertyAfterLease(String propertyId, String tenantId) {
    	
    	logger.info("HIIIII");
        logger.info("Updating property with ID: {} after lease generation for tenant ID: {}", propertyId, tenantId);
        try {
            Property property = propertyDAO.findById(propertyId)
                    .orElseThrow(() -> new PropertyNotFound("Property with ID " + propertyId + " not found."));
 
            property.setTenantID(tenantId);
            property.setAvailabilityStatus(PropertyAvailabilityStatus.rented);
            Property updatedProperty = propertyDAO.save(property);
 
            //logger.info("IDS {}  , prop {}",tenantId,propertyId);
            //logger.info("HII : {}",updatedProperty.toString());
          
            PropertyDTO result = new PropertyDTO(updatedProperty);
            return ResponseEntity.ok(ResultResponse.<PropertyDTO>builder()
                    .success(true)
                    .data(result)
                    .timestamp(LocalDateTime.now())
                    .message("Property updated successfully after lease.")
                    .build());
 
        } catch (PropertyNotFound e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            logger.error("Error updating property after lease:", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<PropertyDTO>builder()
                    .success(false)
                    .message("Internal server error while updating property after lease.")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
    
    @Override
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> getPropertiesByTenantId(String tenantId) {
        logger.info("Fetching properties for tenant ID: {}", tenantId);
        try {
            List<Property> properties = propertyDAO.findByTenantID(tenantId);
            logger.info("Fetched {} properties for tenant ID: {}", properties.size(), tenantId);
            List<PropertyDTO> propertyDTOs = properties.stream().map(PropertyDTO::new).collect(Collectors.toList());
            return ResponseEntity.ok(ResultResponse.<List<PropertyDTO>>builder()
                    .success(true)
                    .data(propertyDTOs)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            logger.error("Error fetching properties by tenant ID: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<PropertyDTO>>builder()
                    .success(false)
                    .message("Internal server error while fetching properties by tenant ID")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
}