package com.example.propertylisting.controller;
 
import com.example.propertylisting.dto.PropertyDTO;
import com.example.propertylisting.Service.PropertyService;
import com.example.propertylisting.utils.ResultResponse;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
 
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
 
import jakarta.validation.Valid;
 
import java.util.List;
 
@RestController
@RequestMapping("/properties")
@CrossOrigin(origins = "http://localhost:3000")
public class PropertyController {
 
    private static final Logger logger = LoggerFactory.getLogger(PropertyController.class);
 
    @Autowired
    private PropertyService propertyService;
 
    @PostMapping("/owner/{ownerId}")
    public ResponseEntity<ResultResponse<PropertyDTO>> addProperty(@PathVariable String ownerId, @Valid @RequestBody PropertyDTO propertyDTO) {
        logger.info("Adding property for ownerId: {}", ownerId);
        return propertyService.addProperty(propertyDTO, ownerId);
    }
 
    @GetMapping("/{propertyId}")
    public ResponseEntity<ResultResponse<PropertyDTO>> getPropertyById(@PathVariable String propertyId) {
        logger.info("Fetching property with ID: {}", propertyId);
        return propertyService.getPropertyById(propertyId);
    }
 
    @GetMapping
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> getAllProperties() {
        logger.info("Fetching all properties");
        return propertyService.getAllProperties();
    }
 
    @PutMapping("/owner/{ownerId}/{propertyId}")
    public ResponseEntity<ResultResponse<PropertyDTO>> updateProperty(@PathVariable String ownerId, @PathVariable String propertyId, @Valid @RequestBody PropertyDTO propertyDTO) {
        logger.info("Updating property with ID: {} for ownerId: {}", propertyId, ownerId);
        return propertyService.updateProperty(propertyId, propertyDTO, ownerId);
    }
 
    @DeleteMapping("/owner/{ownerId}/{propertyId}")
    public ResponseEntity<ResultResponse<Void>> deleteProperty(@PathVariable String ownerId, @PathVariable String propertyId) {
        logger.info("Deleting property with ID: {} for ownerId: {}", propertyId, ownerId);
        return propertyService.deleteProperty(propertyId, ownerId);
    }
 
    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> getPropertiesByOwner(@PathVariable String ownerId) {
        logger.info("Fetching properties for ownerId: {}", ownerId);
        return propertyService.getPropertiesByOwner(ownerId);
    }
 
    @GetMapping("/search")
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> searchProperties(
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice) {
        logger.info("Received request to search properties with filters: location={}, type={}, minPrice={}, maxPrice={}", location, type, minPrice, maxPrice);
        return propertyService.searchProperties(location, type, minPrice, maxPrice);
    }
    @PutMapping("/{propertyId}/rented/{tenantId}")
    public ResponseEntity<ResultResponse<PropertyDTO>> markPropertyAsRented(
            @PathVariable String propertyId,
            @PathVariable String tenantId) {
        logger.info("Marking property with ID: {} as rented by tenant ID: {}", propertyId, tenantId);
        return propertyService.updatePropertyAfterLease(propertyId, tenantId);
    }
    @GetMapping("/tenant/{tenantId}")
    public ResponseEntity<ResultResponse<List<PropertyDTO>>> getPropertiesByTenantId(@PathVariable String tenantId) {
        logger.info("Fetching properties for tenant ID: {}", tenantId);
        return propertyService.getPropertiesByTenantId(tenantId);
    }
}