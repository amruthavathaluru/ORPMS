//package com.example.propertylisting.dao;
//
//import com.example.propertylisting.entity.Property;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import java.util.List;
//
//public interface PropertyDAO extends JpaRepository<Property, String> {
//    List<Property> findByOwnerId(String ownerId);
//}





















//
package com.example.propertylisting.dao;

import com.example.propertylisting.entity.Property;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
//import java.util.UUID;

@Repository
public interface PropertyDAO extends JpaRepository<Property, String> {

	@Query("SELECT p FROM Property p WHERE p.owner.ownerID = :ownerId")
	List<Property> findByOwnerId(@Param("ownerId") String ownerId);


    //  Find available properties
    @Query("SELECT p FROM Property p WHERE p.availabilityStatus = :status")
    List<Property> findByAvailabilityStatus(@Param("status") String status);

    //  Filter properties by location (case-insensitive search)
    @Query("SELECT p FROM Property p WHERE LOWER(p.address) LIKE LOWER(CONCAT('%', :location, '%'))")
    List<Property> findByLocation(@Param("location") String location);

    //  Filter properties by type (e.g., Apartment, Villa, Studio)
    @Query("SELECT p FROM Property p WHERE LOWER(p.type) = LOWER(:type)")
    List<Property> findByType(@Param("type") String type);

    //  Filter properties by price range
    @Query("SELECT p FROM Property p WHERE p.price BETWEEN :minPrice AND :maxPrice")
    List<Property> findByPriceRange(@Param("minPrice") Double minPrice, @Param("maxPrice") Double maxPrice);
    //Filter properties by search 
    @Query("SELECT p FROM Property p WHERE " +
    	       "(:location IS NULL OR LOWER(p.address) LIKE LOWER(CONCAT('%', :location, '%'))) AND " +
    	       "(:type IS NULL OR LOWER(p.type) = LOWER(:type)) AND " +
    	       "(:minPrice IS NULL OR p.price >= :minPrice) AND " +
    	       "(:maxPrice IS NULL OR p.price <= :maxPrice)")
    	List<Property> searchProperties(
    	    @Param("location") String location,
    	    @Param("type") String type,
    	    @Param("minPrice") Double minPrice,
    	    @Param("maxPrice") Double maxPrice
    	);
    @Query("SELECT p FROM Property p WHERE p.tenantID = :tenantId")
    List<Property> findByTenantID(@Param("tenantId") String tenantId);
}