package com.example.propertylisting.Service;
 
import com.example.propertylisting.dto.PropertyDTO;

import com.example.propertylisting.utils.ResultResponse; // Assuming you have ResultResponse

import org.springframework.http.ResponseEntity;

import org.springframework.web.multipart.MultipartFile;
 
import java.util.List;
 
public interface PropertyService {

	ResponseEntity<ResultResponse<PropertyDTO>> addProperty(PropertyDTO propertyDTO, String ownerId);

    ResponseEntity<ResultResponse<PropertyDTO>> updateProperty(String propertyId, PropertyDTO propertyDTO, String ownerId);

    ResponseEntity<ResultResponse<Void>> deleteProperty(String propertyId, String ownerId);

    ResponseEntity<ResultResponse<PropertyDTO>> getPropertyById(String propertyId);

    ResponseEntity<ResultResponse<List<PropertyDTO>>> getAllProperties();

    ResponseEntity<ResultResponse<List<PropertyDTO>>> getPropertiesByOwner(String ownerId);

    ResponseEntity<ResultResponse<List<PropertyDTO>>> searchProperties(String location, String type, Double minPrice, Double maxPrice);

    ResponseEntity<ResultResponse<PropertyDTO>> updatePropertyAfterLease(String propertyId, String tenantId);
    
    ResponseEntity<ResultResponse<List<PropertyDTO>>> getPropertiesByTenantId(String tenantId);

}
 