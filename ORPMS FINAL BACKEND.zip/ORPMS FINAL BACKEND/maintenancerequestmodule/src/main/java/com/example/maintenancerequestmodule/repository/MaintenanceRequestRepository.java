package com.example.maintenancerequestmodule.repository;

import com.example.maintenancerequestmodule.entity.MaintenanceRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface MaintenanceRequestRepository extends JpaRepository<MaintenanceRequest, String> {

    List<MaintenanceRequest> findByTenantID(String tenantID);

    List<MaintenanceRequest> findByPropertyID(String propertyID);
}