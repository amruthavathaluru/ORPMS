package com.example.maintenancerequestmodule.dto;

import java.time.LocalDateTime;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Null;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class MaintenanceRequestDTO {

    @Null(message = "Request ID should not be provided; it will be generated automatically")
    private UUID requestID;

    @NotNull(message = "Tenant ID cannot be null")
    private UUID tenantID;

    @NotNull(message = "Property ID cannot be null")
    private UUID propertyID;

    @NotBlank(message = "Issue description cannot be null")
    @Size(min = 10, max = 200, message = "Issue description must be between 10 and 200 characters")
    private String issueDescription;

    @NotBlank(message = "Status cannot be null")
    private String status;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    // Constructor to create DTO from Entity (if needed for internal use)
    public MaintenanceRequestDTO(com.example.maintenancerequestmodule.entity.MaintenanceRequest request) {
        this.requestID = UUID.fromString(request.getRequestID());
        this.tenantID = UUID.fromString(request.getTenantID());
        this.propertyID = UUID.fromString(request.getPropertyID());
        this.issueDescription = request.getIssueDescription();
        this.status = request.getStatus().name(); // Assuming Status is an Enum
        this.createdAt = request.getCreatedAt();
        this.updatedAt = request.getUpdatedAt();
    }
}




//package com.example.maintenancerequest.dto;
//
//public class MaintenanceRequestDTO {
//    private String requestID;
//    private String tenantID;
//    private String propertyID;
//    private String issueDescription;
//    private String status;
//
//    // Getters and Setters
//    public String getRequestID() { return requestID; }
//    public void setRequestID(String requestID) { this.requestID = requestID; }
//
//    public String getTenantID() { return tenantID; }
//    public void setTenantID(String tenantID) { this.tenantID = tenantID; }
//
//    public String getPropertyID() { return propertyID; }
//    public void setPropertyID(String propertyID) { this.propertyID = propertyID; }
//
//    public String getIssueDescription() { return issueDescription; }
//    public void setIssueDescription(String issueDescription) { this.issueDescription = issueDescription; }
//
//    public String getStatus() { return status; }
//    public void setStatus(String status) { this.status = status; }
//}
