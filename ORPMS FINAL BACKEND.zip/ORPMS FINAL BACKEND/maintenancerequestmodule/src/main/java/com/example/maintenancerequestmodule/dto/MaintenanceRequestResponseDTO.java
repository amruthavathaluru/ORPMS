package com.example.maintenancerequestmodule.dto;

import java.time.LocalDateTime;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class MaintenanceRequestResponseDTO {

    private UUID requestID;
    private UUID tenantID;
    private UUID propertyID;
    private String issueDescription;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Constructor to create DTO from Entity
    public MaintenanceRequestResponseDTO(com.example.maintenancerequestmodule.entity.MaintenanceRequest request) {
        this.requestID = UUID.fromString(request.getRequestID());
        this.tenantID = UUID.fromString(request.getTenantID());
        this.propertyID = UUID.fromString(request.getPropertyID());
        this.issueDescription = request.getIssueDescription();
        this.status = request.getStatus().name(); // Assuming Status is an Enum
        this.createdAt = request.getCreatedAt();
        this.updatedAt = request.getUpdatedAt();
    }
}