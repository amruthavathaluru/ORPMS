package com.example.maintenancerequestmodule.enums;

public enum MaintenanceRequestStatus {
    request_submitted,
    request_received,
    assigned_to_service_provider,
    request_closed;
}