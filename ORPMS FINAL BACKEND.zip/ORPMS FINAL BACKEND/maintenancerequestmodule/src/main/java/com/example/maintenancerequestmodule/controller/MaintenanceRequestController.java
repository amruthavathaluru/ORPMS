package com.example.maintenancerequestmodule.controller;

import com.example.maintenancerequestmodule.dto.MaintenanceRequestDTO;
import com.example.maintenancerequestmodule.dto.MaintenanceRequestResponseDTO;
import com.example.maintenancerequestmodule.service.MaintenanceRequestService;
import com.example.maintenancerequestmodule.utils.ResultResponse;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/maintenance-requests")
public class MaintenanceRequestController {

    private static final Logger logger = LoggerFactory.getLogger(MaintenanceRequestController.class);

    @Autowired
    private MaintenanceRequestService maintenanceRequestService;

    // Create a new maintenance request
    @PostMapping("/create")
    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> createRequest(@RequestBody @Valid MaintenanceRequestDTO dto) {
        logger.info("Received request to create a new maintenance request: {}", dto);

        // Log before calling the service layer
        logger.info("Calling MaintenanceRequestService to create request.");
        MaintenanceRequestResponseDTO response = maintenanceRequestService.createRequest(dto);
        // Log after the service call
        logger.info("Maintenance request creation successful. Response: {}", response);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResultResponse.<MaintenanceRequestResponseDTO>builder()
                        .success(true)
                        .data(response)
                        .timestamp(LocalDateTime.now())
                        .build());
    }

    // Retrieve all maintenance requests
    @GetMapping("/all")
    public ResponseEntity<ResultResponse<List<MaintenanceRequestResponseDTO>>> getAllRequests() {
        logger.info("Received request to fetch all maintenance requests.");

        // Log before calling the service layer
        logger.info("Calling MaintenanceRequestService to get all requests.");
        List<MaintenanceRequestResponseDTO> responses = maintenanceRequestService.getAllRequests();
        // Log after the service call
        logger.info("Retrieved {} maintenance requests.", responses.size());
        logger.debug("All maintenance requests: {}", responses);

        return ResponseEntity.ok(ResultResponse.<List<MaintenanceRequestResponseDTO>>builder()
                .success(true)
                .data(responses)
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Retrieve a specific maintenance request by ID
    @GetMapping("/{id}")
    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> getRequestById(@PathVariable UUID id) {
        logger.info("Received request to fetch maintenance request with ID: {}", id);

        // Log before calling the service layer
        logger.info("Calling MaintenanceRequestService to get request by ID: {}", id);
        MaintenanceRequestResponseDTO response = maintenanceRequestService.getRequestById(id);
        // Log after the service call
        if (response != null) {
            logger.info("Successfully retrieved maintenance request with ID: {}", response.getRequestID());
            logger.debug("Retrieved request: {}", response);
        } else {
            logger.warn("Maintenance request with ID: {} not found (handled by exception in service).", id);
        }

        return ResponseEntity.ok(ResultResponse.<MaintenanceRequestResponseDTO>builder()
                .success(true)
                .data(response)
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Retrieve maintenance requests by tenant ID
    @GetMapping("/tenant/{tenantId}")
    public ResponseEntity<ResultResponse<List<MaintenanceRequestResponseDTO>>> getRequestsByTenantId(@PathVariable UUID tenantId) {
        logger.info("Received request to fetch maintenance requests for tenant ID: {}", tenantId);

        // Log before calling the service layer
        logger.info("Calling MaintenanceRequestService to get requests by tenant ID: {}", tenantId);
        List<MaintenanceRequestResponseDTO> responses = maintenanceRequestService.getRequestsByTenantId(tenantId);
        // Log after the service call
        logger.info("Retrieved {} maintenance requests for tenant ID: {}", responses.size(), tenantId);
        logger.debug("Requests for tenant ID {}: {}", tenantId, responses);

        return ResponseEntity.ok(ResultResponse.<List<MaintenanceRequestResponseDTO>>builder()
                .success(true)
                .data(responses)
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Retrieve maintenance requests by property ID
    @GetMapping("/property/{propertyId}")
    public ResponseEntity<ResultResponse<List<MaintenanceRequestResponseDTO>>> getRequestsByPropertyId(@PathVariable UUID propertyId) {
        logger.info("Received request to fetch maintenance requests for property ID: {}", propertyId);

        // Log before calling the service layer
        logger.info("Calling MaintenanceRequestService to get requests by property ID: {}", propertyId);
        List<MaintenanceRequestResponseDTO> responses = maintenanceRequestService.getRequestsByPropertyId(propertyId);
        // Log after the service call
        logger.info("Retrieved {} maintenance requests for property ID: {}", responses.size(), propertyId);
        logger.debug("Requests for property ID {}: {}", propertyId, responses);

        return ResponseEntity.ok(ResultResponse.<List<MaintenanceRequestResponseDTO>>builder()
                .success(true)
                .data(responses)
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Update an existing maintenance request
    @PutMapping("/update/{id}")
    public ResponseEntity<ResultResponse<MaintenanceRequestResponseDTO>> updateRequest(
            @PathVariable UUID id, @RequestBody @Valid MaintenanceRequestDTO dto) {
        logger.info("Received request to update maintenance request with ID: {}. Request body: {}", id, dto);

        // Log before calling the service layer
        logger.info("Calling MaintenanceRequestService to update request with ID: {}", id);
        MaintenanceRequestResponseDTO updatedResponse = maintenanceRequestService.updateRequest(id, dto);
        // Log after the service call
        logger.info("Maintenance request with ID: {} updated successfully. Response: {}", id, updatedResponse);
        logger.debug("Updated request: {}", updatedResponse);

        return ResponseEntity.ok(ResultResponse.<MaintenanceRequestResponseDTO>builder()
                .success(true)
                .data(updatedResponse)
                .timestamp(LocalDateTime.now())
                .build());
    }

    // Delete a specific maintenance request by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<ResultResponse<Void>> deleteRequest(@PathVariable UUID id) {
        logger.info("Received request to delete maintenance request with ID: {}", id);

        // Log before calling the service layer
        logger.info("Calling MaintenanceRequestService to delete request with ID: {}", id);
        maintenanceRequestService.deleteRequest(id);
        // Log after the service call
        logger.info("Maintenance request with ID: {} deleted successfully.", id);

        return ResponseEntity.ok(ResultResponse.<Void>builder()
                .success(true)
                .timestamp(LocalDateTime.now())
                .build());
    }
}