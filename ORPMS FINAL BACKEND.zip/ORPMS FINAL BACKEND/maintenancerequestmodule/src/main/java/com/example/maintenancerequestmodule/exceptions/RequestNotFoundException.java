package com.example.maintenancerequestmodule.exceptions;


public class RequestNotFoundException  extends RuntimeException{
	public RequestNotFoundException(String message) {
        super(message);
    }
}