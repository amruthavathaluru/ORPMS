package com.example.maintenancerequestmodule.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private JwtFilter jwtFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        return http.csrf(customizer -> customizer.disable())
                .authorizeHttpRequests(request -> request
                        .requestMatchers(HttpMethod.OPTIONS, "/api/maintenance-requests/**").permitAll() // Allow OPTIONS for all maintenance request endpoints

                        // Publicly accessible endpoints
                        .requestMatchers(HttpMethod.GET, "/api/maintenance-requests/all").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/maintenance-requests/{id}").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/maintenance-requests/tenant/{tenantId}").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/maintenance-requests/property/{propertyId}").permitAll()

                        // Tenant accessible endpoints
                        .requestMatchers(HttpMethod.POST, "/api/maintenance-requests/create").hasAuthority("TENANT")

                        // Owner or Admin accessible endpoints
                        .requestMatchers(HttpMethod.PUT, "/api/maintenance-requests/update/{id}").hasAnyAuthority("OWNER")
                        .requestMatchers(HttpMethod.DELETE, "/api/maintenance-requests/delete/{id}").hasAnyAuthority("TENANT")

                        .anyRequest().authenticated())
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/maintenance-requests/**")
                        .allowedOrigins("http://localhost:3000") // Adjust as needed
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                        .allowedHeaders("*")
                        .allowCredentials(true);
            }
        };
    }
}