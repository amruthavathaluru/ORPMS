package com.example.maintenancerequestmodule.client;

import java.util.UUID;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.maintenancerequestmodule.dto.TenantDTO;
import com.example.maintenancerequestmodule.utils.ResultResponse;

@FeignClient(name = "tenantmanagementmodule")
public interface TenantClient {

    @GetMapping("tenant/{tenantId}")
    ResponseEntity<ResultResponse<TenantDTO>> getTenantById(@PathVariable("tenantId") UUID tenantID);
}
