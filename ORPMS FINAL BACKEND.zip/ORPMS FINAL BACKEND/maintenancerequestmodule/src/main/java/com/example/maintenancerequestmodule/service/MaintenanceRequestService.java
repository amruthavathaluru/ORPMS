package com.example.maintenancerequestmodule.service;

import com.example.maintenancerequestmodule.dto.MaintenanceRequestDTO;
import com.example.maintenancerequestmodule.dto.MaintenanceRequestResponseDTO;
import com.example.maintenancerequestmodule.entity.MaintenanceRequest;
import com.example.maintenancerequestmodule.enums.MaintenanceRequestStatus;
import com.example.maintenancerequestmodule.exceptions.RequestNotFoundException;
import com.example.maintenancerequestmodule.repository.MaintenanceRequestRepository;

import jakarta.validation.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class MaintenanceRequestService {

    private static final Logger logger = LoggerFactory.getLogger(MaintenanceRequestService.class);

    @Autowired
    private MaintenanceRequestRepository maintenanceRequestRepository;

    // Helper method to map DTO to Entity
    private MaintenanceRequest mapToEntity(MaintenanceRequestDTO dto) {
        logger.info("Mapping MaintenanceRequestDTO to Entity for tenantId: {}, propertyId: {}", dto.getTenantID(), dto.getPropertyID());
        MaintenanceRequest request = new MaintenanceRequest();
        request.setTenantID(dto.getTenantID().toString());
        request.setPropertyID(dto.getPropertyID().toString());
        request.setIssueDescription(dto.getIssueDescription());

        if (dto.getStatus() != null) {
            try {
                MaintenanceRequestStatus status = MaintenanceRequestStatus.valueOf(dto.getStatus().toLowerCase());
                request.setStatus(status);
                logger.debug("Mapped status: {} for request", status);
            } catch (IllegalArgumentException e) {
                logger.warn("Invalid status provided: {}", dto.getStatus(), e);
                throw new ValidationException("Invalid status: " + dto.getStatus());
            }
        } else {
            request.setStatus(MaintenanceRequestStatus.request_received);
            logger.debug("No status provided, set default status: {}", MaintenanceRequestStatus.request_received);
        }
        logger.debug("Mapped entity: {}", request);
        return request;
    }

    // Helper method to map Entity to Response DTO
    private MaintenanceRequestResponseDTO mapToResponseDTO(MaintenanceRequest request) {
        logger.info("Mapping MaintenanceRequest Entity to Response DTO for request ID: {}", request.getRequestID());
        MaintenanceRequestResponseDTO responseDTO = new MaintenanceRequestResponseDTO(
                UUID.fromString(request.getRequestID()),
                UUID.fromString(request.getTenantID()),
                UUID.fromString(request.getPropertyID()),
                request.getIssueDescription(),
                request.getStatus().name().toLowerCase(), // Convert to lowercase for response
                request.getCreatedAt(),
                request.getUpdatedAt()
        );
        logger.debug("Mapped response DTO: {}", responseDTO);
        return responseDTO;
    }

    // Create a maintenance request
    public MaintenanceRequestResponseDTO createRequest(MaintenanceRequestDTO dto) {
        logger.info("Creating a new maintenance request for tenantId: {}, propertyId: {}", dto.getTenantID(), dto.getPropertyID());
        MaintenanceRequest request = mapToEntity(dto);
        MaintenanceRequest savedRequest = maintenanceRequestRepository.save(request);
        MaintenanceRequestResponseDTO response = mapToResponseDTO(savedRequest);
        logger.info("Maintenance request created successfully with ID: {}", response.getRequestID());
        return response;
    }

    // Retrieve all maintenance requests
    public List<MaintenanceRequestResponseDTO> getAllRequests() {
        logger.info("Retrieving all maintenance requests");
        List<MaintenanceRequest> requests = maintenanceRequestRepository.findAll();
        List<MaintenanceRequestResponseDTO> responseList = requests.stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
        logger.info("Retrieved {} maintenance requests", responseList.size());
        logger.debug("Retrieved requests: {}", responseList);
        return responseList;
    }

    // Retrieve a maintenance request by ID
    public MaintenanceRequestResponseDTO getRequestById(UUID requestID) {
        logger.info("Retrieving maintenance request by ID: {}", requestID);
        MaintenanceRequest request = maintenanceRequestRepository.findById(requestID.toString())
                .orElseThrow(() -> {
                    logger.warn("Maintenance request not found with ID: {}", requestID);
                    return new RequestNotFoundException("Request not found with ID: " + requestID);
                });
        MaintenanceRequestResponseDTO response = mapToResponseDTO(request);
        logger.info("Retrieved maintenance request with ID: {}", response.getRequestID());
        logger.debug("Retrieved request: {}", response);
        return response;
    }

    // Retrieve maintenance requests by tenant ID
    public List<MaintenanceRequestResponseDTO> getRequestsByTenantId(UUID tenantId) {
        logger.info("Retrieving maintenance requests by tenant ID: {}", tenantId);
        // Log before potential Feign call (if you were to fetch tenant details)
        logger.info("Before potential Feign call to fetch tenant details for ID: {}", tenantId);
        List<MaintenanceRequest> requests = maintenanceRequestRepository.findByTenantID(tenantId.toString());
        // Log after potential Feign call
        logger.info("After potential Feign call (if any) for tenant ID: {}", tenantId);
        List<MaintenanceRequestResponseDTO> responseList = requests.stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
        logger.info("Retrieved {} maintenance requests for tenant ID: {}", responseList.size(), tenantId);
        logger.debug("Retrieved requests: {}", responseList);
        return responseList;
    }

    // Retrieve maintenance requests by property ID
    public List<MaintenanceRequestResponseDTO> getRequestsByPropertyId(UUID propertyId) {
        logger.info("Retrieving maintenance requests by property ID: {}", propertyId);
        // Log before potential Feign call (if you were to fetch property details)
        logger.info("Before potential Feign call to fetch property details for ID: {}", propertyId);
        List<MaintenanceRequest> requests = maintenanceRequestRepository.findByPropertyID(propertyId.toString());
        // Log after potential Feign call
        logger.info("After potential Feign call (if any) for property ID: {}", propertyId);
        List<MaintenanceRequestResponseDTO> responseList = requests.stream()
                .map(this::mapToResponseDTO)
                .collect(Collectors.toList());
        logger.info("Retrieved {} maintenance requests for property ID: {}", responseList.size(), propertyId);
        logger.debug("Retrieved requests: {}", responseList);
        return responseList;
    }

    // Update a maintenance request
    public MaintenanceRequestResponseDTO updateRequest(UUID requestID, MaintenanceRequestDTO dto) {
        logger.info("Updating maintenance request with ID: {}", requestID);
        MaintenanceRequest existingRequest = maintenanceRequestRepository.findById(requestID.toString())
                .orElseThrow(() -> {
                    logger.warn("Maintenance request not found with ID: {}", requestID);
                    return new RequestNotFoundException("Request not found with ID: " + requestID);
                });

        // Update fields if provided in the DTO
        if (dto.getTenantID() != null) {
            logger.debug("Updating tenant ID to: {}", dto.getTenantID());
            existingRequest.setTenantID(dto.getTenantID().toString());
        }
        if (dto.getPropertyID() != null) {
            logger.debug("Updating property ID to: {}", dto.getPropertyID());
            existingRequest.setPropertyID(dto.getPropertyID().toString());
        }
        if (dto.getIssueDescription() != null) {
            logger.debug("Updating issue description to: {}", dto.getIssueDescription());
            existingRequest.setIssueDescription(dto.getIssueDescription());
        }
        if (dto.getStatus() != null) {
            logger.debug("Updating status to: {}", dto.getStatus());
            try {
                existingRequest.setStatus(MaintenanceRequestStatus.valueOf(dto.getStatus().toLowerCase()));
            } catch (IllegalArgumentException e) {
                logger.warn("Invalid status provided: {}", dto.getStatus(), e);
                throw new ValidationException("Invalid status: " + dto.getStatus());
            }
        }

        MaintenanceRequest updatedRequest = maintenanceRequestRepository.save(existingRequest);
        MaintenanceRequestResponseDTO response = mapToResponseDTO(updatedRequest);
        logger.info("Maintenance request with ID: {} updated successfully", response.getRequestID());
        logger.debug("Updated request: {}", response);
        return response;
    }

    // Delete a maintenance request
    public boolean deleteRequest(UUID requestID) {
        logger.info("Deleting maintenance request with ID: {}", requestID);
        if (!maintenanceRequestRepository.existsById(requestID.toString())) {
            logger.warn("Maintenance request not found with ID: {}", requestID);
            throw new RequestNotFoundException("Request not found with ID: " + requestID);
        }
        maintenanceRequestRepository.deleteById(requestID.toString());
        logger.info("Maintenance request with ID: {} deleted successfully", requestID);
        return true;
    }
}