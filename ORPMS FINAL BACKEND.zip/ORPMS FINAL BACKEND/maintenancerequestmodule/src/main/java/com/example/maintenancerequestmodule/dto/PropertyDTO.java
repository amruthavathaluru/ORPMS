package com.example.maintenancerequestmodule.dto;

import java.util.UUID;

public class PropertyDTO {
    private UUID propertyID;
    private String propertyName;
    private String address;

    // Getters and Setters
    public UUID getPropertyID() {
        return propertyID;
    }

    public void setPropertyID(UUID propertyID) {
        this.propertyID = propertyID;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
