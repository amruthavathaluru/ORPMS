package com.example.maintenancerequestmodule.client;

import java.util.UUID;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.maintenancerequestmodule.dto.PropertyDTO;
import com.example.maintenancerequestmodule.utils.ResultResponse;


@FeignClient(name = "propertylisting")
public interface PropertyClient {
    @GetMapping("/properties/{propertyId}")
    ResponseEntity<ResultResponse<PropertyDTO>> getPropertyById(@PathVariable("propertyId") UUID propertyID);
}
