package com.example.maintenancerequestmodule.dto;

import java.util.UUID;

public class TenantDTO {
    private UUID tenantID;
    private String name;
    private String contactNumber;

    // Getters and Setters
    public UUID getTenantID() {
        return tenantID;
    }

    public void setTenantID(UUID tenantID) {
        this.tenantID = tenantID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }
}
