package com.example.loginmodule.dto;

import lombok.Data;

/**
 * AuthenticationResponse represents the response containing the authentication token and user ID.
 * It is used to return the JWT token and user ID after successful user login.
 */
@Data
public class AuthenticationResponse {

    /**
     * The JWT authentication token.
     */
    private String token;

    /**
     * The unique identifier of the logged-in user.
     */
    private String userId;
}