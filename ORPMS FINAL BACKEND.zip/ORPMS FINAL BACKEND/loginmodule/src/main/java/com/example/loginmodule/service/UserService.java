package com.example.loginmodule.service;

import com.example.loginmodule.client.OwnerClient;
import com.example.loginmodule.client.TenantClient;
import com.example.loginmodule.dto.OwnerDTO;
import com.example.loginmodule.dto.TenantDTO;
import com.example.loginmodule.entity.User;
import com.example.loginmodule.entity.UserPrincipal;
import com.example.loginmodule.enums.UserType;
import com.example.loginmodule.dao.UserRepository;
import com.example.loginmodule.exception.InvalidCredentialsException;
import com.example.loginmodule.exception.UserAlreadyExistsException;
import com.example.loginmodule.exception.UserNotFoundException;
import com.fasterxml.jackson.databind.ObjectMapper;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Lazy
    @Autowired
    private AuthenticationManager authManager;

    @Autowired
    private TenantClient tenantClient;

    @Autowired
    private OwnerClient ownerClient;

    @Transactional
    public User registerUser(String email, String password, UserType userType, Object details) {
        log.info("Registering user with email: {}", email);
        log.debug("Register details - Email: {}, UserType: {}, Details: {}", email, userType, details);

        if (userRepository.findByEmail(email).isPresent()) {
            log.warn("User with email {} already exists", email);
            throw new UserAlreadyExistsException("User with this email already exists!");
        }

        User user = User.builder()
                .email(email)
                .password(passwordEncoder.encode(password))
                .userType(userType)
                .build();

        log.debug("Saving user to repository: {}", user);
        User savedUser = userRepository.save(user);
        log.debug("User saved successfully with ID: {}", savedUser.getUserId());

        try {
            ObjectMapper objectMapper = new ObjectMapper();

            if (userType == UserType.TENANT) {
                TenantDTO tenantDetailsDTO = objectMapper.convertValue(details, TenantDTO.class);
                tenantDetailsDTO.setTenantID(savedUser.getUserId());
                log.debug("Sending tenant registration request: {}", tenantDetailsDTO);
                ResponseEntity<?> response = tenantClient.registerTenant(tenantDetailsDTO);
                log.debug("Tenant registration response: {}", response);

                if (response.getStatusCode() != HttpStatus.OK) {
                    log.error("Failed to register tenant with ID: {}. Response: {}", savedUser.getUserId(), response);
                    String errorMessage = "Failed to register tenant";
                    if (response.getBody() != null) {
                        errorMessage = response.getBody().toString(); // Try to get the error message from the body
                    }
                    throw new RuntimeException("Tenant registration failed: " + errorMessage);
                }
                log.info("Tenant registered successfully with ID: {}", savedUser.getUserId());
            } else if (userType == UserType.OWNER) {
                OwnerDTO ownerDetailsDTO = objectMapper.convertValue(details, OwnerDTO.class);
                ownerDetailsDTO.setOwnerID(savedUser.getUserId());
                log.debug("Sending owner creation request: {}", ownerDetailsDTO);
                ResponseEntity<?> response = ownerClient.createOwner(ownerDetailsDTO);
                log.debug("Owner creation response: {}", response);

                if (response.getStatusCode() != HttpStatus.OK) {
                    log.error("Failed to create owner with ID: {}. Response: {}", savedUser.getUserId(), response);
                    throw new RuntimeException("Failed to create owner");
                }
                log.info("Owner created successfully with ID: {}", savedUser.getUserId());
            }
        }
        catch (FeignException e) {
            log.error("Feign client exception during registration: {}", e.getMessage());
            String errorMessage = "Registration failed";
            if (e.responseBody().isPresent()) {
                try {
                    byte[] bodyBytes = e.responseBody().get().array();
                    errorMessage = new String(bodyBytes, StandardCharsets.UTF_8);
                    log.error("Error response from target service: {}", errorMessage);
                } catch (Exception ex) {
                    log.error("Error reading Feign response body: {}", ex.getMessage());
                }
            }
            throw new RuntimeException("Microservice call failed: " + errorMessage);
        } catch (Exception e) {
            log.error("Error during microservice call: {}", e.getMessage());
            throw new RuntimeException("Microservice call failed: " + e.getMessage());
        }
        return savedUser;
    }

    public Map<String, String> loginUser(String email, String password, UserType role) {
        log.info("Logging in user with email: {}", email);
        log.debug("Attempting authentication for email: {}", email);
        log.debug("Password submitted: {}", password);
        log.debug("Expected role from request: {}", role);

        Authentication authentication = null;
        try {
            authentication = authManager
                    .authenticate(new UsernamePasswordAuthenticationToken(email, password));

            if (!authentication.isAuthenticated()) {
                log.warn("Invalid login credentials for email: {}", email);
                throw new UserNotFoundException("Invalid Login Credentials!");
            }
        } catch (BadCredentialsException e) {
            log.warn("Invalid credentials for email: {}", email);
            throw new InvalidCredentialsException("Invalid credentials");
        }

        // Get the UserPrincipal and perform role verification **before** token generation
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        User loggedInUser = userPrincipal.getUser();
        UserType actualUserType = loggedInUser.getUserType();
        log.debug("Actual user type from database: {}", actualUserType);

        // **Role Verification Step**
        if (actualUserType != role) {
            log.warn("Attempted login with incorrect role. Expected: {}, Actual: {}", role, actualUserType);
            throw new InvalidCredentialsException("Invalid role for this user.");
        }

        String userId = userPrincipal.getUserId();
        String username = userPrincipal.getUsername(); // This will be the email
        String userRole = actualUserType.toString(); // Use the actual user type

        log.debug("Authenticated user ID: {}", userId);
        log.debug("Authenticated username: {}", username);
        log.debug("Authenticated role: {}", userRole);

        String token = jwtService.generateToken(username, userRole, userId);
        log.debug("Generated JWT token for email: {} and role: {}, with userId: {}", username, userRole, userId);

        Map<String, String> loginResponse = new HashMap<>();
        loginResponse.put("token", token);
        loginResponse.put("userId", userId);

        return loginResponse;
    }

    public User updatePassword(String userId, String newPassword) {
        log.info("Updating password for user ID: {}", userId);
        log.debug("Attempting to update password for user ID: {}", userId);

        User user = userRepository.findById(userId).orElseThrow(() -> {
            log.warn("User not found with ID: {}", userId);
            return new UserNotFoundException("User not found");
        });

        user.setPassword(passwordEncoder.encode(newPassword));
        log.debug("Password encoded and set for user ID: {}", userId);

        User updatedUser = userRepository.save(user);
        log.debug("Password updated successfully for user ID: {}", userId);
        return updatedUser;
    }
}