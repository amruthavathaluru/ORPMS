package com.example.loginmodule.controller;

import com.example.loginmodule.dto.*;
import com.example.loginmodule.entity.User;
import com.example.loginmodule.exception.InvalidCredentialsException;
import com.example.loginmodule.exception.UserAlreadyExistsException;
import com.example.loginmodule.exception.UserNotFoundException;
import com.example.loginmodule.service.UserService;
import com.example.loginmodule.utils.ResultResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * UserController handles API endpoints for user registration, login, and password updates.
 */
@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    /**
     * Registers a new user.
     *
     * @param requestDTO The registration request DTO.
     * @return ResponseEntity containing the result of the registration.
     */
    @PostMapping("/register")
    public ResponseEntity<ResultResponse<UserDTO>> registerUser(@RequestBody RegisterRequestFullDTO requestDTO) {
        log.info("Registering user with email: {}", requestDTO.getEmail());
        log.debug("Register request details: {}", requestDTO);

        try {
            User registeredUser = userService.registerUser(requestDTO.getEmail(), requestDTO.getPassword(), requestDTO.getUserType(), requestDTO.getDetails());
            log.debug("UserService registerUser returned: {}", registeredUser);

            UserDTO userDTO = new UserDTO();
            userDTO.setUserId(registeredUser.getUserId());
            userDTO.setEmail(registeredUser.getEmail());
            userDTO.setUserType(registeredUser.getUserType());

            log.info("User registered successfully: {}", userDTO);
            return ResponseEntity.ok(ResultResponse.<UserDTO>builder()
                    .success(true)
                    .data(userDTO)
                    .message("User registered successfully")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (UserAlreadyExistsException e) {
            log.warn("User registration failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<UserDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (RuntimeException e) {
            log.error("Microservice call failed during user registration: {}", e.getMessage());
            String errorMessage = "Microservice call failed";
            if (e.getMessage().contains("Tenant with this contact number already exists")) {
                errorMessage = "User with this contact number already exists.";
            }
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(ResultResponse.<UserDTO>builder()
                    .success(false)
                    .message(errorMessage)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Internal server error during user registration", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<UserDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Logs in a user.
     *
     * @param loginRequestDTO The login request DTO.
     * @return ResponseEntity containing the authentication response.
     */
    @PostMapping("/login")
    public ResponseEntity<ResultResponse<AuthenticationResponse>> loginUser(@RequestBody LoginRequestDTO loginRequestDTO) {
        log.info("Logging in user with email: {}", loginRequestDTO.getEmail());
        log.debug("Login request details: {}", loginRequestDTO);

        try {
            Map<String, String> loginData = userService.loginUser(
                    loginRequestDTO.getEmail(),
                    loginRequestDTO.getPassword(),
                    loginRequestDTO.getUserType()
            );
            String token = loginData.get("token");
            String userId = loginData.get("userId");
            log.debug("UserService loginUser returned token: {} and userId: {}", token, userId);

            AuthenticationResponse response = new AuthenticationResponse();
            response.setToken(token);
            response.setUserId(userId); // Set the userId in the response

            log.info("User logged in successfully");
            return ResponseEntity.ok(ResultResponse.<AuthenticationResponse>builder()
                    .success(true)
                    .data(response)
                    .message("Login successful")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (UserNotFoundException e) {
            log.warn("Login failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ResultResponse.<AuthenticationResponse>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (InvalidCredentialsException e) {
            log.warn("Invalid password: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ResultResponse.<AuthenticationResponse>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Internal server error during login", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<AuthenticationResponse>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Updates a user's password.
     *
     * @param userId      The ID of the user to update.
     * @param requestDTO The update password request DTO.
     * @return ResponseEntity containing the updated user details.
     */
    @PutMapping("/update-password/{userId}")
    public ResponseEntity<ResultResponse<UserDTO>> updatePassword(
            @PathVariable String userId,
            @RequestBody UpdatePasswordRequestDTO requestDTO) {
        log.info("Updating password for user ID: {}", userId);
        log.debug("Update password request details: {}", requestDTO);

        try {
            User updatedUser = userService.updatePassword(userId, requestDTO.getNewPassword());
            log.debug("UserService updatePassword returned: {}", updatedUser);

            UserDTO userDTO = new UserDTO();
            userDTO.setUserId(updatedUser.getUserId());
            userDTO.setEmail(updatedUser.getEmail());
            userDTO.setUserType(updatedUser.getUserType());

            log.info("Password updated successfully for user ID: {}", userId);
            return ResponseEntity.ok(ResultResponse.<UserDTO>builder()
                    .success(true)
                    .data(userDTO)
                    .message("Password updated successfully")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (UserNotFoundException e) {
            log.warn("Password update failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<UserDTO>builder()
                    .success(false)
                    .message(e.getMessage())
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Internal server error during password update", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<UserDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
}