package com.example.loginmodule.dto;

import com.example.loginmodule.enums.UserType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * Data Transfer Object (DTO) for user registration requests.
 * This DTO encapsulates the necessary information for a user registration process,
 * including email, password, user type, and user-specific details.
 *
 * <p>It uses Jakarta Bean Validation annotations to enforce data integrity and ensure that
 * the provided information meets the required constraints.</p>
 *
 * <p>The 'details' field is a generic Object, which allows for flexibility in capturing
 * user-specific information. However, it is recommended to use specific DTOs for
 * different UserTypes for better type safety and maintainability.</p>
 */
@Data
public class RegisterRequestFullDTO {

    /**
     * The email address of the user.
     * Must not be blank and must be a valid email format.
     */
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Email should be valid")
    private String email;

    /**
     * The password of the user.
     * Must not be blank and must be at least 8 characters long.
     */
    @NotBlank(message = "Password cannot be blank")
    @Size(min = 8, message = "Password must be at least 8 characters long")
    private String password;

    /**
     * The type of the user (e.g., OWNER, TENANT).
     * Must not be null.
     */
    @NotNull(message = "User type cannot be null")
    @Pattern(regexp = "^(TENANT|OWNER)$", message = "Type must be 'OWNER' or 'TENANT'")
    private UserType userType;

    /**
     * User-specific details. The type of this object depends on the userType.
     */
    private Object details;
}