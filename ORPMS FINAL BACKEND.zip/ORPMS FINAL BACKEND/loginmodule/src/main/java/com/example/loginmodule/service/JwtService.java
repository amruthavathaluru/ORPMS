package com.example.loginmodule.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * JwtService provides functionalities for generating, extracting, and validating JWT tokens.
 * It is used for authentication and authorization purposes.
 */
@Service
@Slf4j
public class JwtService {

    /**
     * Expiration time for JWT tokens in milliseconds (1 hour).
     */
    private static final long EXPIRATION_MS = 3600000; // 1 hour

    /**
     * Secret key for signing and verifying JWT tokens.
     */
    private static final String secretKey = "12345678900987654321asdfghjkllkjhgfdsaqwertyuioppoiuytrewq";

    private Key getKey() {
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * Generates a JWT token for the given userId, email, and role.
     *
     * @param email  The email for which the token is generated.
     * @param role   The role of the user.
     * @return The generated JWT token.
     */
    public String generateToken(String email, String role, String userId) {
        log.info("Generating token for email: {}, and role: {}", email, role);
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + EXPIRATION_MS);

        Map<String, Object> claims = new HashMap<>();
        //claims.put("userId", userId); // Add userId to claims
        claims.put("role", role);
        claims.put("email", email);
        claims.put("userId", userId);// Add role to claims
        
        String token = Jwts.builder()
                .setClaims(claims) // Add claims
                .setSubject(email)
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(getKey())
                .compact();

        log.info("Token generated successfully for email: {}, and role: {}", email, role);
        return token;
    }

    /**
     * Extracts the username (email) from the given JWT token.
     *
     * @param token The JWT token from which to extract the username.
     * @return The extracted username (email).
     */
    public String extractUserName(String token) {
        log.info("Extracting username from token");
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(getKey())
                .build()
                .parseClaimsJws(token)
                .getBody();

        String username = claims.getSubject();
        log.info("Username extracted: {}", username);
        return username;
    }

    /**
     * Validates the given JWT token against the user details.
     *
     * @param token       The JWT token to validate.
     * @param userDetails The user details to validate against.
     * @return True if the token is valid, false otherwise.
     */
    public boolean validateToken(String token, UserDetails userDetails) {
        log.info("Validating token for user: {}", userDetails.getUsername());
        final String email = extractUserName(token);
        boolean isValid = (email.equals(userDetails.getUsername()) && !isTokenExpired(token));
        log.info("Token validation result: {}", isValid);
        return isValid;
    }

    /**
     * Extracts all claims from the given JWT token.
     *
     * @param token The JWT token from which to extract claims.
     * @return The extracted claims.
     */
    private Claims extractAllClaims(String token) {
        log.info("Extracting all claims from token");
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(getKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
        log.info("All claims extracted");
        return claims;
    }

    /**
     * Extracts the expiration date from the given JWT token.
     *
     * @param token The JWT token from which to extract the expiration date.
     * @return The extracted expiration date.
     */
    private Date extractExpiration(String token) {
        log.info("Extracting token expiration");
        Claims claims = extractAllClaims(token);
        Date expiration = claims.getExpiration();
        log.info("Token expiration extracted: {}", expiration);
        return expiration;
    }

    /**
     * Checks if the given JWT token is expired.
     *
     * @param token The JWT token to check.
     * @return True if the token is expired, false otherwise.
     */
    public boolean isTokenExpired(String token) {
        log.info("Checking if token is expired");
        boolean isExpired = extractExpiration(token).before(new Date());
        log.info("Token is expired: {}", isExpired);
        return isExpired;
    }

    /**
     * Extracts the userId from the given JWT token.
     *
     * @param token The JWT token from which to extract the user ID.
     * @return The extracted user ID.
     */
    public String extractUserId(String token) {
        log.info("Extracting userId from token");
        Claims claims = extractAllClaims(token);
        String userId = claims.get("userId", String.class);
        log.info("userId extracted: {}", userId);
        return userId;
    }

    /**
     * Extracts the role from the given JWT token.
     *
     * @param token The JWT token from which to extract the role.
     * @return The extracted role.
     */
    public String extractRole(String token) {
        log.info("Extracting role from token");
        Claims claims = extractAllClaims(token);
        String role = claims.get("role", String.class);
        log.info("role extracted: {}", role);
        return role;
    }
}