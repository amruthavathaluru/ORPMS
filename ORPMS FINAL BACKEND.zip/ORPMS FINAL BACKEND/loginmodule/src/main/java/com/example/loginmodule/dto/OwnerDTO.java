package com.example.loginmodule.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

/**
 * Data Transfer Object (DTO) representing an Owner user for registration and information exchange.
 * This DTO includes validation constraints to ensure data integrity.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class OwnerDTO {

    /**
     * The unique identifier for the owner user.
     */
    private String ownerID;

    /**
     * The name of the owner user.
     * Must not be blank and must be between 2 and 50 characters.
     */
    @NotBlank(message = "Name cannot be blank")
    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
    private String name;

    /**
     * The gender of the owner user.
     * Must not be blank and must be one of "Male", "Female", or "Other".
     */
    @NotBlank(message = "Gender cannot be blank")
    @Pattern(regexp = "(?i)^(Male|Female|Other)$", message = "Gender must be 'Male', 'Female', or 'Other'")
    private String gender;

    /**
     * The contact number of the owner user.
     * Must not be blank and must be between 10 and 12 digits.
     */
    @NotBlank(message = "Contact number cannot be blank")
    @Pattern(regexp = "^[1-9][0-9]{9}$", message = "Contact number must be between 10 digits")
    private String contactNo;

    /**
     * The email address of the owner user.
     * Must not be blank and must be a valid email format.
     */
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Email must be a valid email address")
    private String email;
}