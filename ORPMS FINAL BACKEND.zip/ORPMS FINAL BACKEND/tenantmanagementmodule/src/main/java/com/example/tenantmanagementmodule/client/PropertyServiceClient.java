package com.example.tenantmanagementmodule.client;

import java.util.UUID;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.tenantmanagementmodule.dto.PropertyDTO;
import com.example.tenantmanagementmodule.utils.ResultResponse;

/**
 * Feign client interface for interacting with the property listing service.
 * This interface defines methods to retrieve property information.
 */
@FeignClient(name = "propertylisting")
public interface PropertyServiceClient {

    /**
     * Retrieves a PropertyDTO by its property ID.
     *
     * @param propertyId The UUID of the property to retrieve.
     * @return A ResponseEntity containing a ResultResponse with the PropertyDTO, or an error response.
     */
    @GetMapping("/properties/{propertyId}")
    ResponseEntity<ResultResponse<PropertyDTO>> getPropertyById(@PathVariable("propertyId") UUID propertyID);
}