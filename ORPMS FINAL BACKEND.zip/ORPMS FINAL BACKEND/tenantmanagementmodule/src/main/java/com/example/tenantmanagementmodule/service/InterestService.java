package com.example.tenantmanagementmodule.service;

import com.example.tenantmanagementmodule.client.PropertyServiceClient;
import com.example.tenantmanagementmodule.dao.InterestRepository;
import com.example.tenantmanagementmodule.dao.TenantRepository;
import com.example.tenantmanagementmodule.dto.InterestDTO;
import com.example.tenantmanagementmodule.dto.InterestUpdateDTO;
import com.example.tenantmanagementmodule.dto.PropertyDTO;
import com.example.tenantmanagementmodule.entity.Interest;
import com.example.tenantmanagementmodule.entity.Tenant;
import com.example.tenantmanagementmodule.exceptions.DuplicateInterestException;
import com.example.tenantmanagementmodule.exceptions.InterestNotFoundException;
import com.example.tenantmanagementmodule.exceptions.PropertyNotFoundException;
import com.example.tenantmanagementmodule.exceptions.TenantNotFoundException;
import com.example.tenantmanagementmodule.exceptions.UnauthorizedAccessException;
import com.example.tenantmanagementmodule.utils.ResultResponse;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Service class for managing tenant interest-related operations.
 * This class provides methods for recording, updating, and retrieving tenant interests in properties.
 * It also handles authorization checks for owners updating interest statuses.
 */
@Slf4j
@Service
public class InterestService {

    @Autowired
    private InterestRepository interestRepository;

    @Autowired
    private TenantRepository tenantRepository;

    @Autowired
    private PropertyServiceClient propertyServiceClient;

    /**
     * Records a new interest.
     *
     * @param interestDTO The InterestDTO containing interest details.
     * @return The saved InterestDTO.
     * @throws TenantNotFoundException    If the tenant is not found.
     * @throws PropertyNotFoundException  If the property is not found.
     * @throws DuplicateInterestException If a duplicate interest is found.
     */
    public InterestDTO recordInterest(InterestDTO interestDTO) {
        log.info("Recording interest: {}", interestDTO);

        Tenant tenant = tenantRepository.findById(interestDTO.getTenantID().toString())
                .orElseThrow(() -> {
                    log.error("Tenant not found with ID: {}", interestDTO.getTenantID());
                    return new TenantNotFoundException("Tenant not found with ID: " + interestDTO.getTenantID());
                });

        UUID propertyId = interestDTO.getPropertyID();

        ResponseEntity<ResultResponse<PropertyDTO>> response = propertyServiceClient.getPropertyById(propertyId);

        if (response == null || response.getStatusCode() == HttpStatus.NOT_FOUND) {
            log.error("Property not found with ID: {}, Response: {}", propertyId, response);
            throw new PropertyNotFoundException("Property not found with ID: " + propertyId);
        }

        if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null || !response.getBody().isSuccess() || response.getBody().getData() == null) {
            log.error("Service error with ID: {}, Response: {}", propertyId, response);
            throw new RuntimeException("Property service error");
        }

        PropertyDTO propertyDTO = response.getBody().getData();

        Optional<Interest> existingInterest = interestRepository.findByTenant_TenantIDAndPropertyID(
                tenant.getTenantID().toString(), propertyId.toString());

        if (existingInterest.isPresent()) {
            log.error("Duplicate interest found for Tenant ID: {} and Property ID: {}",
                    interestDTO.getTenantID(), interestDTO.getPropertyID());
            throw new DuplicateInterestException("Tenant has already expressed interest in this property");
        }

        Interest interest = new Interest();
        interest.setTenant(tenant);
        interest.setPropertyID(propertyId.toString());
        interest.setStatus(interestDTO.getStatus());

        Interest savedInterest = interestRepository.save(interest);
        log.info("Interest recorded successfully: {}", savedInterest.getInterestID());
        return convertToDTO(savedInterest);
    }

    /**
     * Updates the status of an interest.
     *
     * @param updateDTO The InterestUpdateDTO containing updated status details.
     * @param ownerId   The ID of the owner making the update.
     * @return The updated InterestDTO.
     * @throws InterestNotFoundException    If the interest is not found.
     * @throws UnauthorizedAccessException If the owner is not authorized to update the interest.
     */
    public InterestDTO updateInterestStatus(InterestUpdateDTO updateDTO, UUID ownerId) {
        log.info("Updating interest status: {}", updateDTO);

        Interest interest = interestRepository.findById(updateDTO.getInterestID().toString())
                .orElseThrow(() -> {
                    log.error("Interest not found with ID: {}", updateDTO.getInterestID());
                    return new InterestNotFoundException("Interest not found with ID: " + updateDTO.getInterestID());
                });

        if (!isOwnerAuthorized(interest, ownerId)) {
            log.error("Owner with ID: {} is not authorized to update interest with ID: {}", ownerId, updateDTO.getInterestID());
            throw new UnauthorizedAccessException("Owner not authorized to update this interest.");
        }

        interest.setStatus(updateDTO.getStatus());
        Interest updatedInterest = interestRepository.save(interest);
        log.info("Interest status updated successfully: {}", updatedInterest.getInterestID());
        return convertToDTO(updatedInterest);
    }

    /**
     * Retrieves an interest by its ID.
     *
     * @param interestID The ID of the interest to retrieve.
     * @return The InterestDTO object with the specified ID.
     * @throws InterestNotFoundException If the interest is not found.
     */
    public InterestDTO getInterestById(String interestID) {
        log.info("Retrieving interest by id: {}", interestID);
        Interest interest = interestRepository.findById(interestID).orElseThrow(() -> {
            log.error("Interest not found with ID: {}", interestID);
            return new InterestNotFoundException("Interest not found with ID: " + interestID);
        });
        return convertToDTO(interest);
    }

    /**
     * Checks if the owner is authorized to update the interest.
     *
     * @param interest The interest to check authorization for.
     * @param ownerId  The ID of the owner.
     * @return true if the owner is authorized, false otherwise.
     */
    private boolean isOwnerAuthorized(Interest interest, UUID ownerId) {
        log.info("Checking owner authorization for interest ID: {}", interest.getInterestID());
        ResponseEntity<ResultResponse<PropertyDTO>> response = propertyServiceClient.getPropertyById(UUID.fromString(interest.getPropertyID()));

        if (response == null || response.getStatusCode() == HttpStatus.NOT_FOUND) {
            log.error("Property not found during authorization check. Property ID: {}, Response: {}", interest.getPropertyID(), response);
            throw new PropertyNotFoundException("Property not found with given ID");
        }

        if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null || !response.getBody().isSuccess() || response.getBody().getData() == null) {
            log.error("Service error during authorization check. Property ID: {}, Response: {}", interest.getPropertyID(), response);
            return false;
        }
        PropertyDTO propertyDTO = response.getBody().getData();

        // Add logging to check the propertyDTO
        log.info("PropertyDTO received for authorization check: {}", propertyDTO);

        // Add logging to check the ownerID
        log.info("OwnerID from PropertyDTO for authorization check: {}", propertyDTO.getOwnerID());
        log.info("OwnerID from request for authorization check: {}", ownerId);

        if (propertyDTO.getOwnerID() == null) {
            log.error("OwnerID is null for Property ID: {} during authorization check.", interest.getPropertyID());
            return false;
        }

        boolean isAuthorized = propertyDTO.getOwnerID().equals(ownerId);
        log.info("Authorization check result: {}", isAuthorized);

        return isAuthorized;
    }

    /**
     * Retrieves interests by tenant ID, including the interest date.
     * Property name will be fetched on the frontend.
     *
     * @param tenantId The ID of the tenant.
     * @return A list of InterestDTOs with interest date.
     */
    public List<InterestDTO> getInterestsByTenantId(String tenantId) {
        log.info("Retrieving interests for tenant ID: {}", tenantId);
        List<Interest> interests = interestRepository.findByTenant_TenantID(tenantId);
        return interests.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Retrieves interests by property ID.
     *
     * @param propertyId The ID of the property.
     * @return A list of InterestDTOs.
     */
    public List<InterestDTO> getInterestsByPropertyId(String propertyId) {
        log.info("Retrieving interests for property ID: {}", propertyId);
        List<Interest> interests = interestRepository.findByPropertyID(propertyId);
        return interests.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    /**
     * Deletes an interest by its ID, verifying the tenant ID.
     *
     * @param interestId The ID of the interest to delete.
     * @param tenantId The ID of the tenant making the request.
     * @return true if the interest is deleted, false otherwise.
     * @throws InterestNotFoundException If the interest is not found.
     * @throws UnauthorizedAccessException If the tenant is not authorized.
     */
    public boolean deleteInterestByTenant(String interestId, String tenantId) {
        log.info("Deleting interest ID: {} for tenant ID: {}", interestId, tenantId);

        Interest interest = interestRepository.findById(interestId)
                .orElseThrow(() -> new InterestNotFoundException("Interest not found with ID: " + interestId));

        if (!interest.getTenant().getTenantID().equals(tenantId)) {
            log.error("Tenant ID: {} is not authorized to delete interest ID: {}", tenantId, interestId);
            throw new UnauthorizedAccessException("Tenant not authorized to delete this interest.");
        }

        interestRepository.deleteById(interestId);
        log.info("Interest ID: {} deleted successfully.", interestId);
        return true;
    }

    /**
     * Converts an Interest entity to an InterestDTO.
     *
     * @param interest The Interest entity to convert.
     * @return The converted InterestDTO.
     */
    private InterestDTO convertToDTO(Interest interest) {
        return new InterestDTO(interest);
    }
}