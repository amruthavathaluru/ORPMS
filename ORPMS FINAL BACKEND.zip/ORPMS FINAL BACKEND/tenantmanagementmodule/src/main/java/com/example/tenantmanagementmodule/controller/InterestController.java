package com.example.tenantmanagementmodule.controller;

import com.example.tenantmanagementmodule.dto.InterestDTO;
import com.example.tenantmanagementmodule.dto.InterestUpdateDTO;
import com.example.tenantmanagementmodule.exceptions.DuplicateInterestException;
import com.example.tenantmanagementmodule.exceptions.InterestNotFoundException;
import com.example.tenantmanagementmodule.exceptions.PropertyNotFoundException;
import com.example.tenantmanagementmodule.exceptions.TenantNotFoundException;
import com.example.tenantmanagementmodule.exceptions.UnauthorizedAccessException;
import com.example.tenantmanagementmodule.service.InterestService;
import com.example.tenantmanagementmodule.utils.ResultResponse;

import feign.FeignException;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * REST controller for managing tenant interests.
 */
@Slf4j
@RestController
@RequestMapping("/interest")
public class InterestController {

    @Autowired
    private InterestService interestService;

    /**
     * Records a new interest.
     *
     * @param interestDTO The InterestDTO containing the details of the interest.
     * @return ResponseEntity containing the recorded InterestDTO or an error response.
     */
    @PostMapping("/post")
    public ResponseEntity<ResultResponse<InterestDTO>> recordInterest(@Valid @RequestBody InterestDTO interestDTO) {
        log.info("Received request to record interest: {}", interestDTO);
        try {
            InterestDTO recordedInterest = interestService.recordInterest(interestDTO);
            log.info("Interest recorded successfully: {}", recordedInterest);
            return ResponseEntity.ok(ResultResponse.<InterestDTO>builder()
                    .success(true)
                    .data(recordedInterest)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (TenantNotFoundException e) {
            log.error("Error recording interest: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Tenant not found.") // Change the message here
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (PropertyNotFoundException e) {
            log.error("Error recording interest: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Property not found.") // Add message for property not found.
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (DuplicateInterestException e) {
            log.error("Duplicate interest error: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Interest already exists.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (FeignException.NotFound e) {
            log.error("Property not found (Feign 404): {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Property not found.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error recording interest: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Updates the status of an existing interest.
     *
     * @param updateDTO The InterestUpdateDTO containing the updated status.
     * @param ownerId   The ID of the owner making the update.
     * @return ResponseEntity containing the updated InterestDTO or an error response.
     */
    @PutMapping("/update")
    public ResponseEntity<ResultResponse<InterestDTO>> updateInterestStatus(
            @Valid @RequestBody InterestUpdateDTO updateDTO,
            @RequestParam("ownerId") UUID ownerID) {
        log.info("Received request to update interest status: {}", updateDTO);

        // Validation for UUIDs will be handled by GlobalExceptionHandler

        try {
            InterestDTO updatedInterest = interestService.updateInterestStatus(updateDTO, ownerID);
            log.info("Interest status updated successfully: {}", updatedInterest);
            return ResponseEntity.ok(ResultResponse.<InterestDTO>builder()
                    .success(true)
                    .data(updatedInterest)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (InterestNotFoundException e) {
            log.error("Error updating interest status: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Interest not found.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (UnauthorizedAccessException e) {
            log.error("Unauthorized access to update interest status: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Unauthorized access.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error updating interest status: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

    /**
     * Retrieves an interest by its ID.
     *
     * @param interestID The ID of the interest to retrieve.
     * @return ResponseEntity containing the retrieved InterestDTO or an error response.
     */
    @GetMapping("/{interestID}")
    public ResponseEntity<ResultResponse<InterestDTO>> getInterestById(@Valid @PathVariable String interestID) {
        log.info("Received request to get interest by ID: {}", interestID);

        // Validation for UUIDs will be handled by GlobalExceptionHandler

        try {
            InterestDTO interestDTO = interestService.getInterestById(interestID);
            log.info("Interest found: {}", interestDTO);
            return ResponseEntity.ok(ResultResponse.<InterestDTO>builder()
                    .success(true)
                    .data(interestDTO)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (InterestNotFoundException e) {
            log.error("Error getting interest by ID: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Interest not found.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting interest by ID: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<InterestDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
    
    /**
     * Retrieves interests by tenant ID.
     *
     * @param tenantId The ID of the tenant.
     * @return ResponseEntity containing the list of InterestDTOs or an error response.
     */
    @GetMapping("/tenant/{tenantId}")
    public ResponseEntity<ResultResponse<List<InterestDTO>>> getInterestsByTenantId(
            @PathVariable("tenantId") String tenantID) {
        log.info("Received request to get interests by tenant ID: {}", tenantID);

        try {
            List<InterestDTO> interests = interestService.getInterestsByTenantId(tenantID);
            return ResponseEntity.ok(ResultResponse.<List<InterestDTO>>builder()
                    .success(true)
                    .data(interests)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting interests by tenant ID: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<InterestDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
    
    /**
     * Retrieves interests by property ID.
     *
     * @param propertyId The ID of the property.
     * @return ResponseEntity containing the list of InterestDTOs or an error response.
     */
    @GetMapping("/property/{propertyId}")
    public ResponseEntity<ResultResponse<List<InterestDTO>>> getInterestsByPropertyId(
            @PathVariable("propertyId") String propertyID) {
        log.info("Received request to get interests by property ID: {}", propertyID);
        try {
            List<InterestDTO> interests = interestService.getInterestsByPropertyId(propertyID);
            return ResponseEntity.ok(ResultResponse.<List<InterestDTO>>builder()
                    .success(true)
                    .data(interests)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting interests by property ID: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<InterestDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
    
    /**
     * Deletes an interest by its ID, verifying the tenant ID.
     *
     * @param interestId The ID of the interest to delete.
     * @param tenantId The ID of the tenant making the request.
     * @return ResponseEntity with a success message or an error response.
     */
    @DeleteMapping("/{interestId}/tenant/{tenantId}")
    public ResponseEntity<ResultResponse<Boolean>> deleteInterestByTenant(
            @PathVariable("interestId") String interestID,
            @PathVariable("tenantId") String tenantID) {
        log.info("Received request to delete interest ID: {} by tenant ID: {}", interestID, tenantID);

        try {
            boolean deleted = interestService.deleteInterestByTenant(interestID, tenantID);
            return ResponseEntity.ok(ResultResponse.<Boolean>builder()
                    .success(true)
                    .data(deleted)
                    .message("Interest deleted successfully.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (InterestNotFoundException e) {
            log.error("Error deleting interest: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResultResponse.<Boolean>builder()
                    .success(false)
                    .message("Interest not found.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (UnauthorizedAccessException e) {
            log.error("Unauthorized access to delete interest: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ResultResponse.<Boolean>builder()
                    .success(false)
                    .message("Unauthorized access.")
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error deleting interest: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<Boolean>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }
    
}