package com.example.tenantmanagementmodule.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private JwtFilter jwtFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        return http.csrf(customizer -> customizer.disable())
                .authorizeHttpRequests(request -> request
                		
                		.requestMatchers(HttpMethod.OPTIONS, "/interest/post").permitAll()
                		.requestMatchers(HttpMethod.OPTIONS, "/tenant/update/**").permitAll()
                		.requestMatchers(HttpMethod.OPTIONS, "/tenant/profile/**").permitAll()
                		.requestMatchers(HttpMethod.OPTIONS, "/interest/tenant/**").permitAll()
                		.requestMatchers(HttpMethod.OPTIONS, "/interest/*/tenant/*").permitAll()
                       
                        // TenantController Endpoints
                        .requestMatchers("/tenant/register").permitAll() // Allow anyone to register
                        .requestMatchers("/tenant/profile/{tenantID}").permitAll()
                        .requestMatchers("/tenant/all").permitAll()
                        .requestMatchers("/tenant/update/{tenantID}").hasAuthority("TENANT")
                        .requestMatchers("/tenant/delete/{tenantID}").hasAuthority("TENANT") //or owner

                        // InterestController Endpoints
                        .requestMatchers("/interest/post").hasAuthority("TENANT")
                        .requestMatchers("/interest/update").hasAuthority("OWNER")
                        .requestMatchers("/interest/{interestID}").permitAll()
                        .requestMatchers("/interest/tenant/{tenantId}").hasAuthority("TENANT")
                        .requestMatchers("/interest/property/{propertyId}").hasAuthority("OWNER")
                        .requestMatchers("/interest/{interestId}/tenant/{tenantId}").hasAuthority("TENANT")

                        // Publicly accessible Endpoints (if any)
                        .anyRequest().authenticated())
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }
    
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins("http://localhost:3000")
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                        .allowedHeaders("*")
                        .allowCredentials(true);
            }
        };
    }
}