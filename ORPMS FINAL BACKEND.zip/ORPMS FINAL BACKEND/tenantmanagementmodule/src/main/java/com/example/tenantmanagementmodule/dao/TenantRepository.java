package com.example.tenantmanagementmodule.dao;

import com.example.tenantmanagementmodule.entity.Tenant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository interface for managing Tenant entities.
 * This interface extends JpaRepository to provide standard database operations
 * for the Tenant entity, and includes custom methods for specific retrieval and deletion needs.
 */
@Repository
public interface TenantRepository extends JpaRepository<Tenant, String> {

    /**
     * Finds a Tenant entity by its ID.
     *
     * @param tenantID The ID of the tenant.
     * @return An Optional containing the found Tenant entity, or an empty Optional if not found.
     */
    Optional<Tenant> findById(String tenantID);

    /**
     * Checks if a Tenant entity exists with the given ID.
     *
     * @param tenantID The ID of the tenant.
     * @return true if a Tenant entity exists with the given ID, false otherwise.
     */
    boolean existsById(String tenantID);

    /**
     * Deletes a Tenant entity by its ID.
     *
     * @param tenantID The ID of the tenant.
     */
    void deleteById(String tenantID);
}