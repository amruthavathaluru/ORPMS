package com.example.tenantmanagementmodule.dao;

import com.example.tenantmanagementmodule.entity.Interest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for managing Interest entities.
 * This interface extends JpaRepository to provide standard database operations
 * for the Interest entity, and adds custom query methods.
 */
@Repository
public interface InterestRepository extends JpaRepository<Interest, String> {

    /**
     * Finds an Interest entity by the tenant ID and property ID.
     *
     * @param tenantID   The ID of the tenant.
     * @param propertyID The ID of the property.
     * @return An Optional containing the found Interest entity, or an empty Optional if not found.
     */
    Optional<Interest> findByTenant_TenantIDAndPropertyID(String tenantID, String propertyID);

    /**
     * Finds an Interest entity by its ID.
     *
     * @param interestID The ID of the interest.
     * @return An Optional containing the found Interest entity, or an empty Optional if not found.
     */
    Optional<Interest> findById(String interestID);

    /**
     * Finds all Interest entities associated with a specific tenant ID.
     *
     * @param tenantID The ID of the tenant.
     * @return A List of Interest entities associated with the tenant.
     */
    List<Interest> findByTenant_TenantID(String tenantID);

    /**
     * Finds all Interest entities associated with a specific property ID.
     *
     * @param propertyID The ID of the property.
     * @return A List of Interest entities associated with the property.
     */
    List<Interest> findByPropertyID(String propertyID);

    /**
     * Deletes all Interest entities associated with a specific tenant ID.
     *
     * @param tenantID The ID of the tenant.
     */
    void deleteByTenantTenantID(String tenantID);
}