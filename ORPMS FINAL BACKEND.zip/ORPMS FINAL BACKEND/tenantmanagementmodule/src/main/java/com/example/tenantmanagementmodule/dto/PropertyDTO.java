package com.example.tenantmanagementmodule.dto;

import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown=true)
public class PropertyDTO {
	
	@NotNull
    private UUID propertyID;
	
	@NotNull
    private UUID ownerID;
	
    private String propertyName;
	
    private String address;
	
	
    private String type;
	
	@Positive(message="Price cannot be a negative Number")
    private double price;
	
    private String rentalTerms;
    
    private String availabilityStatus;
}