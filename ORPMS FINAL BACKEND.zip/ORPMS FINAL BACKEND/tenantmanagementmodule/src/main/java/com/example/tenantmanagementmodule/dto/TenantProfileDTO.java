package com.example.tenantmanagementmodule.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.util.UUID;

import org.springframework.validation.annotation.Validated;

import com.example.tenantmanagementmodule.entity.Tenant;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class TenantProfileDTO {

    @NotNull(message = "Tenant ID cannot be null")
    private UUID tenantID;

    @NotBlank(message = "Tenant name cannot be blank")
    @Size(min = 2, max = 100, message = "Tenant name must be between 2 and 100 characters")
    private String name;

    @NotBlank(message = "Contact number cannot be blank")
    @Pattern(regexp = "^[0-9]{10}$", message = "Contact number must be 10 digits")
    private String contactNo;

//    @NotBlank(message = "Email cannot be blank")
//    @Email(message = "Invalid email format")
//    private String email;

    @NotBlank(message = "Gender cannot be blank")
    @Pattern(regexp = "(?i)^(Male|Female|Other)$", message = "Gender must be Male, Female, or Other")
    private String gender;



    public TenantProfileDTO(Tenant tenant) {
        this.tenantID = UUID.fromString(tenant.getTenantID());
        this.name = tenant.getName();
        this.contactNo = tenant.getContactNo();
        //this.email = tenant.getEmail();
        this.gender = tenant.getGender();
    }
}