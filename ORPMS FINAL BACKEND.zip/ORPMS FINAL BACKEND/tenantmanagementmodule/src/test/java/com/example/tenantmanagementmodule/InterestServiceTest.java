package com.example.tenantmanagementmodule;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.tenantmanagementmodule.dao.InterestRepository;
import com.example.tenantmanagementmodule.dao.TenantRepository;
import com.example.tenantmanagementmodule.dto.InterestDTO;
import com.example.tenantmanagementmodule.dto.InterestUpdateDTO;
import com.example.tenantmanagementmodule.entity.Interest;
import com.example.tenantmanagementmodule.entity.Tenant;
import com.example.tenantmanagementmodule.exceptions.DuplicateInterestException;
import com.example.tenantmanagementmodule.exceptions.InterestNotFoundException;
import com.example.tenantmanagementmodule.exceptions.TenantNotFoundException;
import com.example.tenantmanagementmodule.service.InterestService;
import com.example.tenantmanagementmodule.client.PropertyServiceClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;
import java.util.UUID;

class InterestServiceTest {

    @Mock
    private InterestRepository interestRepository;

    @Mock
    private TenantRepository tenantRepository;

    @Mock
    private PropertyServiceClient propertyServiceClient;

    @InjectMocks
    private InterestService interestService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void recordInterest_whenTenantNotFound_throwsTenantNotFoundException() {
        UUID tenantId = UUID.randomUUID();
        InterestDTO interestDTO = new InterestDTO();
        interestDTO.setTenantID(tenantId);

        when(tenantRepository.findById(tenantId.toString())).thenReturn(Optional.empty());

        assertThrows(TenantNotFoundException.class, () -> interestService.recordInterest(interestDTO));
    }

    @Test
    void recordInterest_whenDuplicateInterestFound_throwsDuplicateInterestException() {
        UUID tenantId = UUID.randomUUID();
        UUID propertyId = UUID.randomUUID();
        InterestDTO interestDTO = new InterestDTO();
        interestDTO.setTenantID(tenantId);
        interestDTO.setPropertyID(propertyId);

        Tenant tenant = new Tenant();
        tenant.setTenantID(tenantId.toString());

        when(tenantRepository.findById(tenantId.toString())).thenReturn(Optional.of(tenant));
        when(interestRepository.findByTenant_TenantIDAndPropertyID(tenantId.toString(), propertyId.toString()))
                .thenReturn(Optional.of(new Interest()));

        assertThrows(DuplicateInterestException.class, () -> interestService.recordInterest(interestDTO));
    }

    @Test
    void updateInterestStatus_whenInterestNotFound_throwsInterestNotFoundException() {
        UUID interestId = UUID.randomUUID();
        InterestUpdateDTO updateDTO = new InterestUpdateDTO();
        updateDTO.setInterestID(interestId);

        when(interestRepository.findById(interestId.toString())).thenReturn(Optional.empty());

        assertThrows(InterestNotFoundException.class, () -> interestService.updateInterestStatus(updateDTO, UUID.randomUUID()));
    }

    @Test
    void getInterestById_whenInterestNotFound_throwsInterestNotFoundException() {
        UUID interestId = UUID.randomUUID();

        when(interestRepository.findById(interestId.toString())).thenReturn(Optional.empty());

        assertThrows(InterestNotFoundException.class, () -> interestService.getInterestById(interestId.toString()));
    }

    @Test
    void getInterestById_returnsInterestDTO() {
        UUID interestId = UUID.randomUUID();
        Interest interest = new Interest();
        interest.setInterestID(interestId.toString());

        when(interestRepository.findById(interestId.toString())).thenReturn(Optional.of(interest));

        InterestDTO result = interestService.getInterestById(interestId.toString());
        assertNotNull(result);
        assertEquals(interestId.toString(), result.getInterestID());
    }
}
