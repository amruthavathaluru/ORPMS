package com.example.tenantmanagementmodule;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.tenantmanagementmodule.dao.InterestRepository;
import com.example.tenantmanagementmodule.dao.TenantRepository;
import com.example.tenantmanagementmodule.dto.TenantDTO;
import com.example.tenantmanagementmodule.dto.TenantProfileDTO;
import com.example.tenantmanagementmodule.entity.Tenant;
import com.example.tenantmanagementmodule.exceptions.DuplicateTenantException;
import com.example.tenantmanagementmodule.exceptions.TenantNotFoundException;
import com.example.tenantmanagementmodule.service.TenantService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;
import java.util.UUID;
import java.util.Arrays;
import java.util.List;

class TenantServiceTest {

    @Mock
    private TenantRepository tenantRepository;

    @Mock
    private InterestRepository interestRepository;

    @InjectMocks
    private TenantService tenantService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void registerTenant_whenDuplicateTenantExists_throwsDuplicateTenantException() {
        TenantDTO tenantDTO = new TenantDTO();
        tenantDTO.setTenantID(UUID.randomUUID());
        tenantDTO.setName("John Doe");

        Tenant tenant = new Tenant();
        tenant.setTenantID(tenantDTO.getTenantID().toString());
        tenant.setName(tenantDTO.getName());

        when(tenantRepository.save(any())).thenThrow(new org.springframework.dao.DataIntegrityViolationException("Duplicate tenant"));

        assertThrows(DuplicateTenantException.class, () -> tenantService.registerTenant(tenantDTO));
    }

    @Test
    void getTenantProfileById_whenTenantNotFound_throwsTenantNotFoundException() {
        String tenantID = UUID.randomUUID().toString();

        when(tenantRepository.findById(tenantID)).thenReturn(Optional.empty());

        assertThrows(TenantNotFoundException.class, () -> tenantService.getTenantProfileById(tenantID));
    }

    @Test
    void getTenantProfileById_returnsTenantProfile() {
        String tenantID = UUID.randomUUID().toString();

        Tenant tenant = new Tenant();
        tenant.setTenantID(tenantID);
        tenant.setName("John Doe");

        when(tenantRepository.findById(tenantID)).thenReturn(Optional.of(tenant));

        TenantProfileDTO profileDTO = tenantService.getTenantProfileById(tenantID);
        assertNotNull(profileDTO);
        assertEquals(tenantID, profileDTO.getTenantID());
        assertEquals("John Doe", profileDTO.getName());
    }

    @Test
    void getAllTenants_returnsListOfTenantDTO() {
        Tenant tenant1 = new Tenant();
        tenant1.setTenantID(UUID.randomUUID().toString());
        tenant1.setName("John Doe");

        Tenant tenant2 = new Tenant();
        tenant2.setTenantID(UUID.randomUUID().toString());
        tenant2.setName("Jane Doe");

        List<Tenant> tenants = Arrays.asList(tenant1, tenant2);

        when(tenantRepository.findAll()).thenReturn(tenants);

        List<TenantDTO> tenantDTOs = tenantService.getAllTenants();
        assertEquals(2, tenantDTOs.size());
        assertEquals("John Doe", tenantDTOs.get(0).getName());
        assertEquals("Jane Doe", tenantDTOs.get(1).getName());
    }

    @Test
    void updateTenantDetails_whenTenantNotFound_throwsTenantNotFoundException() {
        TenantDTO tenantDTO = new TenantDTO();
        tenantDTO.setTenantID(UUID.randomUUID());

        when(tenantRepository.findById(tenantDTO.getTenantID().toString())).thenReturn(Optional.empty());

        assertThrows(TenantNotFoundException.class, () -> tenantService.updateTenantDetails(tenantDTO));
    }

    @Test
    void updateTenantDetails_returnsUpdatedTenantDTO() {
        TenantDTO tenantDTO = new TenantDTO();
        tenantDTO.setTenantID(UUID.randomUUID());
        tenantDTO.setName("Updated Name");

        Tenant tenant = new Tenant();
        tenant.setTenantID(tenantDTO.getTenantID().toString());
        tenant.setName("Original Name");

        when(tenantRepository.findById(tenantDTO.getTenantID().toString())).thenReturn(Optional.of(tenant));
        when(tenantRepository.save(any(Tenant.class))).thenReturn(tenant);

        TenantDTO updatedTenantDTO = tenantService.updateTenantDetails(tenantDTO);
        assertEquals("Updated Name", updatedTenantDTO.getName());
    }

    @Test
    void deleteTenantById_whenTenantNotFound_throwsTenantNotFoundException() {
        String tenantID = UUID.randomUUID().toString();

        when(tenantRepository.existsById(tenantID)).thenReturn(false);

        assertThrows(TenantNotFoundException.class, () -> tenantService.deleteTenantById(tenantID));
    }

    @Test
    void deleteTenantById_deletesTenantSuccessfully() {
        String tenantID = UUID.randomUUID().toString();

        when(tenantRepository.existsById(tenantID)).thenReturn(true);

        boolean deleted = tenantService.deleteTenantById(tenantID);
        assertTrue(deleted);
        verify(interestRepository).deleteByTenantTenantID(tenantID);
        verify(tenantRepository).deleteById(tenantID);
    }
}
