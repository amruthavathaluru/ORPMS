package com.leasemanagement.lease.enums;

public enum PaymentStatus {
	payment_initiated,
	payment_received,
	pending,

}
