package com.leasemanagement.lease.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.leasemanagement.lease.dto.LeaseNotificationDTO;
import com.leasemanagement.lease.dto.OwnerDTO;
import com.leasemanagement.lease.dto.PropertyDTO;
import com.leasemanagement.lease.response.ResultResponse;

@FeignClient(name="propertylisting")
public interface PropertyClient {

	
	@GetMapping("properties/{propertyId}")
	public ResponseEntity<ResultResponse<PropertyDTO>> getPropertyById(@PathVariable String propertyId);
	
	@GetMapping("owners/{ownerId}")
    public ResponseEntity<ResultResponse<OwnerDTO>> getOwnerById(@PathVariable("ownerId") String ownerId);
	//ownerid from ownerdto or propertydto
	
//	 @PostMapping("/api/notify")
//	  void sendNotification(LeaseNotificationDTO notification);
	
	@PutMapping("properties/{propertyId}/rented/{tenantId}")
    public ResponseEntity<ResultResponse<PropertyDTO>> markPropertyAsRented(@PathVariable String propertyId,@PathVariable String tenantId);
	
	
	 
}
