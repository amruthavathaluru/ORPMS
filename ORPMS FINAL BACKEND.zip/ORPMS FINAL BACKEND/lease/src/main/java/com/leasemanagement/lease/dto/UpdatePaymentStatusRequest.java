package com.leasemanagement.lease.dto;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.leasemanagement.lease.enums.PaymentStatus;

//import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdatePaymentStatusRequest {

    @NotNull(message = "Lease ID cannot be null") // Use @NotNull for UUID
    private UUID leaseID;

    @NotNull(message = "Payment status cannot be null") // Uncomment if needed
    private PaymentStatus paymentStatus;
}
