package com.leasemanagement.lease.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.leasemanagement.lease.service.LeaseService;

@Component
public class LeaseNotificationScheduler {

    @Autowired
    private LeaseService leaseService; // Your service that handles the notification logic

    /**
     * Scheduled task that runs every day at 8:00 AM
     * Cron Expression Breakdown:
     * - "0 0 8 * * ?" -> Trigger at 8:00 AM every day
     */
    @Scheduled(cron = "0 0 8 * * ?")
    public void sendLeaseNotifications() {
        try {
            leaseService.notifyTenantsForExpiringLeases();
            System.out.println("Daily lease notification task executed successfully.");
        } catch (Exception e) {
            // Handle exceptions gracefully and log them
            System.err.println("Error while sending lease notifications: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

