package com.leasemanagement.lease.dto;

import java.util.UUID;

import lombok.Data;


@Data
public class LeaseNotificationDTO {
    private UUID leaseID; // Lease identifier
    private UUID tenantID; // Tenant identifier
    private UUID ownerID;  // Owner identifier
    private String message;  // Notification message

    
   
}
