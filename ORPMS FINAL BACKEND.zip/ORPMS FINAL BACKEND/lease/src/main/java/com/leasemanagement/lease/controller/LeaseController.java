package com.leasemanagement.lease.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.leasemanagement.lease.dto.InterestDTO;
//import com.leasemanagement.lease.dto.LeaseRequestDTO;
import com.leasemanagement.lease.dto.LeaseResponseDTO;
import com.leasemanagement.lease.dto.RentPaymentsDTO;
import com.leasemanagement.lease.dto.UpdatePaymentStatusRequest;
import com.leasemanagement.lease.model.Lease;
import com.leasemanagement.lease.response.ResultResponse;
import com.leasemanagement.lease.service.LeaseService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/lease")
@Slf4j
public class LeaseController {

	@Autowired
	private LeaseService leaseService;
	
	@PostMapping("/display")
	public ResponseEntity<ResultResponse<LeaseResponseDTO>> showLease(@Valid @RequestBody InterestDTO interestDTO)
	{
		log.info("Displaying Lease Details ");
		
		try {
			log.info("Inside try block");
			LeaseResponseDTO leaseResponseDTO = leaseService.showLease(interestDTO);
			log.info("exiting try block");
			return ResponseEntity.ok(ResultResponse.<LeaseResponseDTO>builder()
					.success(true)
					.data(leaseResponseDTO)
					.timestamp(LocalDateTime.now())
					.build());
		}catch (Exception e) {
            log.error("Error getting lease details: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<LeaseResponseDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
		
		
	}
	
	
	
	 @GetMapping("/details/{leaseID}")
	    public ResponseEntity<ResultResponse<RentPaymentsDTO>> getLeaseDetails(@PathVariable String leaseID) {
	        log.info("Initiating payment for lease ID: {}", leaseID);

	        try {
	            log.info("Inside try block");
	            RentPaymentsDTO paymentDto = leaseService.initiatePayment(leaseID);
	            log.info("Exiting try block");
	            return ResponseEntity.ok(ResultResponse.<RentPaymentsDTO>builder()
	                    .success(true)
	                    .data(paymentDto)
	                    .timestamp(LocalDateTime.now())
	                    .build());
	        } catch (Exception e) {
	            log.error("Error initiating payment: {}", e.getMessage(), e);
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<RentPaymentsDTO>builder()
	                    .success(false)
	                    .message("Internal server error")
	                    .timestamp(LocalDateTime.now())
	                    .build());
	        }
	    }


	
	@PutMapping("update/paid")
	public ResponseEntity<ResultResponse<String>> paymentStatusUpdate(@Valid @RequestBody UpdatePaymentStatusRequest updatePaymentDTO )
	{
		log.info("Updating  payment status in lease table");
		
		try {
			log.info("Inside try block");
			
			String updateStatus = leaseService.paymentStatusUpdate(updatePaymentDTO);
			log.info("Exiting try block");
			return ResponseEntity.ok(ResultResponse.<String>builder()
					.success(true)
					.data(updateStatus)
					.timestamp(LocalDateTime.now())
					.build());
		}catch(Exception e) {
			  log.error("Error getting lease details: {}", e.getMessage(), e);
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<String>builder()
	                    .success(false)
	                    .message("Internal server error")
	                    .timestamp(LocalDateTime.now())
	                    .build());
		}
			
	}
	
	@GetMapping("tenant/{tenantID}") // New endpoint to fetch all leases
    public ResponseEntity<ResultResponse<List<LeaseResponseDTO>>> getAllLeasesByTenantID(@Valid @PathVariable String tenantID) {
        log.info("Getting all leases by tenant Id");
        try {
            log.info("Inside try block");
            List<LeaseResponseDTO> leaseResponseDTOList = leaseService.getAllLeasesByTenantID(tenantID);
            log.info("Exiting try block");
            return ResponseEntity.ok(ResultResponse.<List<LeaseResponseDTO>>builder()
                    .success(true)
                    .data(leaseResponseDTOList)
                    .timestamp(LocalDateTime.now())
                    .build());
        } catch (Exception e) {
            log.error("Error getting all Lease Details by Tenant ID: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<List<LeaseResponseDTO>>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
    }

	
	@PutMapping("renewal/{leaseId}")
	public ResponseEntity<ResultResponse<LeaseResponseDTO>> renewLease(@Valid @PathVariable String leaseId)
	{
		log.info("Displaying Lease Details ");
		
		try {
			log.info("Inside try block");
			LeaseResponseDTO leaseResponseDTO = leaseService.renewLease(leaseId);
			log.info("exiting try block");
			return ResponseEntity.ok(ResultResponse.<LeaseResponseDTO>builder()
					.success(true)
					.data(leaseResponseDTO)
					.timestamp(LocalDateTime.now())
					.build());
		}catch (Exception e) {
            log.error("Error getting lease details: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<LeaseResponseDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
        }
		
		
	}
	
	
	@DeleteMapping("delete/{leaseId}")
	public ResponseEntity<ResultResponse<String>> deleteLeaseById(@PathVariable String leaseId) {
	    log.info("Deleting lease with ID: {}", leaseId);

	    try {
	        log.info("Inside try block");
	        leaseService.deleteLeaseById(leaseId); // Assuming this method is implemented in LeaseService
	        log.info("Lease successfully deleted, exiting try block");
	        return ResponseEntity.ok(ResultResponse.<String>builder()
	                .success(true)
	                .message("Lease deleted successfully")
	                .timestamp(LocalDateTime.now())
	                .build());
	    } catch (Exception e) {
	        log.error("Error deleting lease: {}", e.getMessage(), e);
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<String>builder()
	                .success(false)
	                .message("Internal server error")
	                .timestamp(LocalDateTime.now())
	                .build());
	    }
	}

	
	@GetMapping("leaseID/{leaseID}")
	public ResponseEntity<ResultResponse<LeaseResponseDTO>> getLeaseByLeaseID(@PathVariable String leaseID)
	{
		log.info("Getting lease by lease Id");
		try {
			log.info("Inisde try block");
			LeaseResponseDTO leaseResponseDTO = leaseService.getLeaseByLeaseID(leaseID);
			log.info("Exiting try block");
			return ResponseEntity.ok(ResultResponse.<LeaseResponseDTO>builder()
					.success(true)
					.data(leaseResponseDTO)
					.timestamp(LocalDateTime.now())
					.build());
		}catch(Exception e) {
			log.error("Error getting Lease Details: {}",e.getMessage(),e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ResultResponse.<LeaseResponseDTO>builder()
                    .success(false)
                    .message("Internal server error")
                    .timestamp(LocalDateTime.now())
                    .build());
		}
	}
	
	
}

   
	

