package com.leasemanagement.lease.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.leasemanagement.lease.model.Lease;

@Repository
public interface LeaseRepository extends JpaRepository<Lease ,String> {

	Lease findByTenantID(String tenantID);
	
	List<Lease> findByEndDate(LocalDate endDate);
	
	// New method to fetch multiple leases by tenantID
    List<Lease> findAllByTenantID(String tenantID);

}
