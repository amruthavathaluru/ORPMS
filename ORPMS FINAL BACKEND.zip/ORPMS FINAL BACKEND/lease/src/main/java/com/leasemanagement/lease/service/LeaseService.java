package com.leasemanagement.lease.service;

import com.leasemanagement.lease.client.InterestClient;



import com.leasemanagement.lease.client.PropertyClient;
import com.leasemanagement.lease.client.RentPaymentClient;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.leasemanagement.lease.dto.InterestDTO;
import com.leasemanagement.lease.dto.LeaseResponseDTO;
import com.leasemanagement.lease.dto.OwnerDTO;
import com.leasemanagement.lease.dto.RentPaymentsDTO;
import com.leasemanagement.lease.dto.PropertyDTO;
import com.leasemanagement.lease.dto.TenantProfileDTO;
import com.leasemanagement.lease.dto.UpdatePaymentStatusRequest;
import com.leasemanagement.lease.dto.LeaseNotificationDTO;
import com.leasemanagement.lease.enums.LeaseStatus;
import com.leasemanagement.lease.enums.PaymentStatus;
import com.leasemanagement.lease.model.Lease;
import com.leasemanagement.lease.repository.LeaseRepository;

import feign.FeignException;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LeaseService {

	
		@Autowired
		private PropertyClient propertyClient;
		
		@Autowired
		private InterestClient interestClient;
		
		@Autowired
		private RentPaymentClient rentPaymentClient;
		
		
		
		
		@Autowired
		private LeaseRepository leaseRepo;

		public LeaseResponseDTO showLease(InterestDTO interestDTO) {
			
			 
			 
		 TenantProfileDTO tenantDTO = interestClient.getTenantProfile(interestDTO.getTenantID().toString()).getBody().getData();
	//	ResultResponse<TenantProfileDTO> ten = tenantResponse.getBody();
					 
		PropertyDTO propertyDTO =  propertyClient.getPropertyById(interestDTO.getPropertyID().toString()).getBody().getData(); 
//		PropertyDTO prop = propertyDTO.getBody();
		
		OwnerDTO ownerDTO = propertyClient.getOwnerById(propertyDTO.getOwnerID().toString()).getBody().getData();
		
		
		     
		// ResponseEntity<ResultResponse<OwnerDTO>>	     
		//ResponseEntity<ResultResponse<TenantProfileDTO>>
		
		log.info("LeaseDTO: {}", tenantDTO);
		log.info("HiiiiiiHIIIIII");
		     
		     
		      
		      
		     //Fetching data from other modules and adding it to Response DTO
		     
		     LeaseResponseDTO leaseDto = new LeaseResponseDTO();
		     
		     
		     leaseDto.setTenantName(tenantDTO.getName());
		     leaseDto.setTenantContactNo(tenantDTO.getContactNo());
		     leaseDto.setOwnerName(ownerDTO.getName());
		     leaseDto.setOwnerContactNo(ownerDTO.getContactNo());
		     leaseDto.setPropertyAddress(propertyDTO.getAddress());
		     leaseDto.setPropertyPrice(propertyDTO.getPrice());
		     leaseDto.setStartDate(LocalDate.now());
		     leaseDto.setEndDate(LocalDate.now().plusMonths(11));
		     leaseDto.setLeaseStatus(LeaseStatus.agreement_initiated);
		     leaseDto.setOwnerID(ownerDTO.getOwnerID());
		     leaseDto.setPropertyID(propertyDTO.getPropertyID());
		     leaseDto.setTenantID(tenantDTO.getTenantID());
		  
		     //Saving to the Database
		     
		     Lease lease = new Lease();
		     
		     lease.setTenantName(leaseDto.getTenantName());
		     lease.setTenantContactNo(leaseDto.getTenantContactNo());
		     lease.setOwnerName(leaseDto.getOwnerName());
		     lease.setOwnerContactNo(leaseDto.getOwnerContactNo());
		     lease.setPropertyAddress(leaseDto.getPropertyAddress());
		     lease.setPropertyPrice(leaseDto.getPropertyPrice());
		     lease.setStartDate(leaseDto.getStartDate());
		     lease.setEndDate(leaseDto.getEndDate());
		     lease.setLeaseStatus(LeaseStatus.agreement_initiated);
		     lease.setOwnerID(ownerDTO.getOwnerID().toString());
		     lease.setPropertyID(propertyDTO.getPropertyID().toString());
		     lease.setTenantID(tenantDTO.getTenantID().toString());
		     		     
		     
		     leaseRepo.save(lease);  
		     
		     leaseDto.setLeaseID(UUID.fromString(lease.getLeaseID()));
		     log.info("Lease UUID successfully set: {}", leaseDto.getLeaseID());
		     
		   
		     return leaseDto;
		     
		}
		
		
		   public RentPaymentsDTO initiatePayment(String leaseID) { 
		  RentPaymentsDTO paymentDTO = new RentPaymentsDTO();
		  Lease lease = leaseRepo.findById(leaseID)
					 .orElseThrow(() -> new RuntimeException("Lease Id not found"));
		  
		  
		  
		 
		  paymentDTO.setLeaseID(UUID.fromString(lease.getLeaseID())); 
		  paymentDTO.setTenantID(UUID.fromString(lease.getTenantID()));
		  paymentDTO.setOwnerID(UUID.fromString(lease.getOwnerID()));
		  paymentDTO.setStartDate(lease.getStartDate());
		  paymentDTO.setPropertyPrice(lease.getPropertyPrice());
		 // paymentDTO.setPaymentStatus(PaymentStatus.payment_initiated);
		  
		  return paymentDTO;
		   }
		  

		public String paymentStatusUpdate(UpdatePaymentStatusRequest rentPaymentDTO) {
					 
	
			 Lease lease = leaseRepo.findById(rentPaymentDTO.getLeaseID().toString())
			            .orElseThrow(() -> new EntityNotFoundException("Lease with ID " + rentPaymentDTO.getLeaseID() + " not found"));
			 
			 log.info("HIII BEFORE FEIGN");
			 
			// UpdatePaymentStatusRequest rentPaymentDTO = rentPaymentClient.leaseStatusUpdate(leaseID).getBody().getData();
			 
			 log.info("AFTER FEIGN");
			 
			 if (rentPaymentDTO.getPaymentStatus().equals(PaymentStatus.payment_received)) {
		            lease.setLeaseStatus(LeaseStatus.agreement_initiated);
		            log.info("CHECKING LOGGER");
		            log.info("Lease id {}", lease.getLeaseID());
		            log.info("property id {}", lease.getPropertyID());
		            log.info("tenant id {}", lease.getTenantID());
		            leaseRepo.save(lease);

		            try {
		                propertyClient.markPropertyAsRented(lease.getPropertyID(), lease.getTenantID());
		                log.info("Successfully marked property {} as rented for tenant {}", lease.getPropertyID(), lease.getTenantID());
		            } catch (FeignException e) {
		                log.error("Error marking property as rented:", e);
		                // Consider a fallback action:
		                // - Revert the lease status? (Potentially complex and might need another transaction)
		                // - Send a notification for manual intervention?
		                // - Throw a custom exception to indicate partial success?
		                return "Payment Done and Lease Generated, but failed to update property status. Property ID: " + lease.getPropertyID() + ", Tenant ID: " + lease.getTenantID() + ". Please investigate.";
		            }
		        }

		        return "Payment Done and Lease Generated";
		}
		

		public List<LeaseResponseDTO> getAllLeasesByTenantID(String tenantID) {
	        log.info("Getting all leases by tenant Id: {}", tenantID);
	        List<Lease> leases = leaseRepo.findAllByTenantID(tenantID);
	        return leases.stream()
	                .map(this::mapLeaseToLeaseResponseDTO)
	                .collect(Collectors.toList());
	    }

	    private LeaseResponseDTO mapLeaseToLeaseResponseDTO(Lease lease) {
	        LeaseResponseDTO dto = new LeaseResponseDTO();
	        dto.setTenantName(lease.getTenantName());
	        dto.setTenantContactNo(lease.getTenantContactNo());
	        dto.setOwnerName(lease.getOwnerName());
	        dto.setOwnerContactNo(lease.getOwnerContactNo());
	        dto.setPropertyAddress(lease.getPropertyAddress());
	        dto.setPropertyPrice(lease.getPropertyPrice());
	        dto.setStartDate(lease.getStartDate());
	        dto.setEndDate(lease.getEndDate());
	        dto.setLeaseStatus(lease.getLeaseStatus());
	        dto.setOwnerID(UUID.fromString(lease.getOwnerID()));
	        dto.setPropertyID(UUID.fromString(lease.getPropertyID()));
	        dto.setTenantID(UUID.fromString(lease.getTenantID()));
	        dto.setLeaseID(UUID.fromString(lease.getLeaseID()));
	        return dto;
	    }

		public LeaseResponseDTO renewLease(String leaseId) {
			// TODO Auto-generated method stub
			
			Lease lease = leaseRepo.findById(leaseId)
					.orElseThrow(() ->  new RuntimeException("Lease not found"));
			
			 LocalDate updatedDate = fetchRenewalDate(lease.getEndDate());
			
			
			lease.setStartDate(updatedDate);
	        lease.setEndDate(updatedDate.plusMonths(11));
	        
	        LeaseResponseDTO leaseResponseDTO = new LeaseResponseDTO();
	        
	        leaseResponseDTO.setTenantName(lease.getTenantName());
			leaseResponseDTO.setTenantContactNo(lease.getTenantContactNo());
			leaseResponseDTO.setOwnerName(lease.getOwnerName());
			leaseResponseDTO.setOwnerContactNo(lease.getOwnerContactNo());
			leaseResponseDTO.setPropertyAddress(lease.getPropertyAddress());
			leaseResponseDTO.setPropertyPrice(lease.getPropertyPrice());
			leaseResponseDTO.setStartDate(lease.getStartDate());
			leaseResponseDTO.setEndDate(lease.getEndDate());
			leaseResponseDTO.setLeaseStatus(LeaseStatus.agreement_initiated);
			leaseResponseDTO.setOwnerID(UUID.fromString(lease.getOwnerID()));
			leaseResponseDTO.setTenantID(UUID.fromString(lease.getTenantID()));
			leaseResponseDTO.setPropertyID(UUID.fromString(lease.getPropertyID()));
			leaseResponseDTO.setLeaseID(UUID.fromString(lease.getLeaseID()));
			
	        
	        return leaseResponseDTO;
		}
		
		
		 public static LocalDate fetchRenewalDate(LocalDate endDate)
		    {
		    	 LocalDate updatedDate = endDate.plusDays(1);
		    	
		    	return updatedDate;
		    }
		
		
		 
		 public void deleteLeaseById(String leaseId) {
			    // Add logic to delete the lease using your repository
			    leaseRepo.deleteById(leaseId);
			}
		 
		 
		 public void notifyTenantsForExpiringLeases() {
			    LocalDate today = LocalDate.now();
			    LocalDate notificationDate = today.plusDays(5);

			    // Fetch leases ending in 5 days
			    List<Lease> expiringLeases = leaseRepo.findByEndDate(notificationDate);

			    for (Lease lease : expiringLeases) {
			        sendNotification(lease);
			    }
			}

		 public void sendNotification(Lease lease) {
		        LeaseNotificationDTO notification = new LeaseNotificationDTO();
		        notification.setLeaseID(UUID.fromString(lease.getLeaseID()));
		        notification.setTenantID(UUID.fromString(lease.getTenantID()));
		        notification.setMessage("Your lease is expiring on " + lease.getEndDate() + ". Please take action.");

		        // Send notification to the tenant
		        interestClient.sendNotification(notification);

		        // Send notification to the owner
		       

		        log.info("Notification sent to both Tenant and Owner for Lease ID: " + lease.getLeaseID());
		    }
		 
		 public String findPropertyIDByTenantID(String tenantID)
		 {
			 Lease lease= leaseRepo.findByTenantID(tenantID);
			 String propertyID = lease.getPropertyID();
			 
			 return propertyID;
		 }	
		 
		 public LeaseResponseDTO getLeaseByLeaseID(String leaseID)
		 {
			 Lease lease = leaseRepo.findById(leaseID)
					 .orElseThrow(() -> new RuntimeException("Lease Id not found"));
			 
			 LeaseResponseDTO leaseResponseDTO = new LeaseResponseDTO();
			 
			    leaseResponseDTO.setTenantName(lease.getTenantName());
				leaseResponseDTO.setTenantContactNo(lease.getTenantContactNo());
				leaseResponseDTO.setOwnerName(lease.getOwnerName());
				leaseResponseDTO.setOwnerContactNo(lease.getOwnerContactNo());
				leaseResponseDTO.setPropertyAddress(lease.getPropertyAddress());
				leaseResponseDTO.setPropertyPrice(lease.getPropertyPrice());
				leaseResponseDTO.setStartDate(lease.getStartDate());
				leaseResponseDTO.setEndDate(lease.getEndDate());
				leaseResponseDTO.setLeaseStatus(LeaseStatus.agreement_initiated);
				leaseResponseDTO.setOwnerID(UUID.fromString(lease.getOwnerID()));
				leaseResponseDTO.setTenantID(UUID.fromString(lease.getTenantID()));
				leaseResponseDTO.setPropertyID(UUID.fromString(lease.getPropertyID()));
				leaseResponseDTO.setLeaseID(UUID.fromString(lease.getLeaseID()));
				
				return leaseResponseDTO;
		 }
		 
		 
}
