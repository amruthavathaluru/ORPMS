package com.leasemanagement.lease.dto;

import java.time.LocalDate;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.leasemanagement.lease.enums.PaymentStatus;

import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Data
@JsonIgnoreProperties(ignoreUnknown=true)
public class RentPaymentsDTO {

    @NotBlank(message = "Lease ID cannot be blank")
    private UUID leaseID;
    
    @NotBlank(message = "Tenant ID cannot be blank")
    private UUID tenantID;
    
    @NotBlank(message = "Owner ID cannot be blank")
    private UUID ownerID;
    
    @NotBlank(message= "Rent Amount cannot be null")
    private double propertyPrice;

  //  @NotNull(message = "Payment status cannot be null")
    private PaymentStatus paymentStatus;
    
    @NotBlank(message = "Start Date cannot be Null")
    private LocalDate startDate;
    
    
    
}
