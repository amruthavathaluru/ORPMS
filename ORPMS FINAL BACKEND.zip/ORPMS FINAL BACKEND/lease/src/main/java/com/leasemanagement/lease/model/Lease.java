package com.leasemanagement.lease.model;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import com.leasemanagement.lease.enums.LeaseStatus;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import lombok.Data;

@Entity
@Data
public class Lease {
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @PrePersist
    public void generateuuid() {
        this.leaseID = UUID.randomUUID().toString();
        this.createdAt = LocalDateTime.now();
    }

    @PreUpdate
    public void updateAtMethod() {
        this.updatedAt = LocalDateTime.now();
    }

    @Id
    @Column(name = "leaseID", unique = true)
    private String leaseID;

//    @OneToMany(mappedBy = "lease", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//    private Set<RentPayments> rentPayments = new HashSet<>();


    @Column(name = "propertyID", nullable = false)
    private String propertyID;


    @Column(name = "tenantID", nullable = false )
    private String tenantID;


    @Column(name = "ownerID", nullable = false)
    private String ownerID;

    private LocalDate startDate;
    private LocalDate endDate;

    @Column(name = "rentAmount", nullable = false, unique = false, updatable = true)
    private double rentAmount;

    @Enumerated(EnumType.STRING)
    private LeaseStatus leaseStatus = LeaseStatus.agreement_initiated ;

    // Additional fields for tenant and owner details
    private String tenantName;
    private String tenantContactNo;
    private String ownerName;
    private String ownerContactNo;
    private String propertyAddress;
    private double propertyPrice;
}
