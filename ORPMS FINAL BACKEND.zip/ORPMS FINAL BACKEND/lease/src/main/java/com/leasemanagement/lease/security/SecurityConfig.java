package com.leasemanagement.lease.security;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	 @Autowired
	 private JwtFilter jwtFilter;

	 @Bean
	 public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

		 return http.csrf(csrf -> csrf.disable())
				 .authorizeHttpRequests(requests -> requests


						 // LeaseController Endpoints
						 .requestMatchers("/lease/display").hasAuthority("TENANT")
						 .requestMatchers("/lease/details/{leaseID}").permitAll()
						 .requestMatchers("/lease/update/paid").permitAll()
						 .requestMatchers("/lease/tenant/*").hasAuthority("TENANT")
						 .requestMatchers("/lease/renewal/{leaseId}").hasAuthority("TENANT")
						 .requestMatchers("/lease/delete/{leaseId}").hasAuthority("TENANT")

						 // Default behavior
						 .anyRequest().authenticated())
				 .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
				 .cors(cors -> cors.configure(http)) // Enable CORS using the bean below
				 .build();
	 }

	 @Bean
	 public WebMvcConfigurer corsConfigurer() {
		 return new WebMvcConfigurer() {
			 @Override
			 public void addCorsMappings(CorsRegistry registry) {
				 registry.addMapping("/**")
						 .allowedOrigins("http://localhost:3000") // Allow your React app's origin
						 .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
						 .allowedHeaders("*")
						 .allowCredentials(true);
			 }
		 };
	 }
}