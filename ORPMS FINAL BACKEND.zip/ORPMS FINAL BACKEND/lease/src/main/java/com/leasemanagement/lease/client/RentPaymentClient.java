package com.leasemanagement.lease.client;

import org.springframework.cloud.openfeign.FeignClient;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import com.leasemanagement.lease.dto.RentPaymentsDTO;
import com.leasemanagement.lease.dto.UpdatePaymentStatusRequest;
import com.leasemanagement.lease.response.ResultResponse;


@FeignClient(name="rentpaymentmodule")
public interface RentPaymentClient {
	
//	@GetMapping("rentpayment/{paymentID}")
//    ResponseEntity<RentPaymentsDTO> getPaymentById(@PathVariable("paymentID") String propertyId);
//	update with true values
	
	
	@GetMapping("api/rentpayments/lease/status/{leaseID}")
    public ResponseEntity<ResultResponse<UpdatePaymentStatusRequest>> leaseStatusUpdate(@PathVariable String leaseID);
}
