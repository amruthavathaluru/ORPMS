package com.leasemanagement.lease.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class TenantProfileDTO {

    @NotBlank(message = "Tenant ID cannot be blank")
    private UUID tenantID;

    @NotBlank(message = "Tenant Name cannot be blank")
    @Size(max = 100, message = "Tenant Name cannot exceed 100 characters")
    private String name;

    @NotBlank(message = "Tenant Contact cannot be blank")
    private String contactNo;
}
