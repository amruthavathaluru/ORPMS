package com.leasemanagement.lease.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.leasemanagement.lease.dto.InterestDTO;
import com.leasemanagement.lease.dto.LeaseNotificationDTO;
import com.leasemanagement.lease.dto.TenantProfileDTO;
import com.leasemanagement.lease.response.ResultResponse;



@FeignClient(name = "tenantmanagementmodule")
public interface InterestClient {
	
	  @GetMapping("/interest/{interestID}")
	   ResponseEntity<ResultResponse<InterestDTO>> getInterestById(@PathVariable("interestID") String interestID);
	  
	  @GetMapping("tenant/profile/{tenantID}")
	   ResponseEntity<ResultResponse<TenantProfileDTO>> getTenantProfile(@PathVariable("tenantID") String tenantID);
	    
	  @PostMapping("tenant/notify")
	   void sendNotification(LeaseNotificationDTO notification); 
}
