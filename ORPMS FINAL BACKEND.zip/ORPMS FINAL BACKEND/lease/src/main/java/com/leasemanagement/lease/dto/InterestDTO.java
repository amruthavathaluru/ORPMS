package com.leasemanagement.lease.dto;

 

 
import java.util.UUID;

import org.springframework.validation.annotation.Validated;
 

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.leasemanagement.lease.enums.InterestStatus;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
@Data
@NoArgsConstructor
@AllArgsConstructor
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class InterestDTO {
 
    @NotNull(message = "Interest ID cannot be null")
    private UUID interestID;
 
    @NotNull(message = "Tenant ID cannot be null")
    private UUID tenantID;
 
    @NotNull(message = "Property ID cannot be null")
    private UUID propertyID;
}
