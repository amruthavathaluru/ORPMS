package com.leasemanagement.lease.dto;
 
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.validation.constraints.*; // Import validation annotations
 
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class OwnerDTO {
 
	@Null(message = "Owner ID should not be provided; it will be generated automatically")
	private UUID ownerID;
 
 
    @NotBlank(message = "Name cannot be blank")
    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
    private String name;
    
 
    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Email must be a valid email address")
    private String contactNo;

}