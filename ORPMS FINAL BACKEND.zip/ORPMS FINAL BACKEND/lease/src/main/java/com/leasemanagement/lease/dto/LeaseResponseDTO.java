package com.leasemanagement.lease.dto;

import java.time.LocalDate;
import java.util.UUID;

import com.leasemanagement.lease.enums.LeaseStatus;
import com.leasemanagement.lease.model.Lease;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LeaseResponseDTO {
	
	@NotBlank(message = "Lease id Name cannot be blank")
	private UUID leaseID;
	
	@NotBlank(message = "property id Name cannot be blank")
	private UUID propertyID;
	    
	@NotBlank(message = "owner id Name cannot be blank")
	private UUID ownerID;
	    
	@NotBlank(message = "tenant id Name cannot be blank")
	private UUID tenantID;

    @NotBlank(message = "Tenant Name cannot be blank")
    private String tenantName;

    @NotBlank(message = "Tenant Email cannot be blank")
    @Email(message = "Invalid email format for tenant email")
    private String tenantContactNo;

    @NotBlank(message = "Owner Name cannot be blank")
    private String ownerName;

    @NotBlank(message = "Owner Email cannot be blank")
    @Email(message = "Invalid email format for owner email")
    private String ownerContactNo;

    @NotBlank(message = "Property Address cannot be blank")
    private String propertyAddress;

    @Positive(message = "Property Price must be greater than 0")
    private double propertyPrice;

    @NotNull(message = "Start Date cannot be null")
    @FutureOrPresent(message = "Start Date must be today or in the future")
    private LocalDate startDate;

    @NotNull(message = "End Date cannot be null")
    @Future(message = "End Date must be in the future")
    private LocalDate endDate;

    @NotNull(message = "Lease Status cannot be null")
    private LeaseStatus leaseStatus;
    
   
    
//    public LeaseResponseDTO(Lease lease)
//    {
//    	this.leaseID = UUID.fromString(lease.getLeaseID());
//    }
}
