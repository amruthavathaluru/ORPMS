// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Registration from './components/Registration';
import { AuthProvider } from './context/AuthContext';
import TenantDashboard from './components/TenantDashboard';
import OwnerDashboard from './components/OwnerDashboard';
import ProtectedRoute from './components/ProtectedRoute'; 
import TenantLandingPage from './components/TenantLandingPage';
import PropertyListingsPage from './components/PropertyListingPage';
import InterestsPage from './components/InterestsPage';
import OwnerInterestsPage from './components/OwnerInterestsPage';
import TenantProfilePage from './components/TenantProfilePage';
import RegisterProperty from './components/RegisterProperty';
import TenantPropertiesPage from './components/TenantPropertiesPage';
import NotificationsPage from './Notifications/NotificationsPage';
import UpdatePaymentStatus from './Payments/UpdatePaymentStatus';
import PaymentSuccessPage from './Payments/PaymentSuccessPage';
import CreateRentPayment from './Payments/CreateRentPayment';
import TenantLeasesList from './components/TenantLeaseList';
import TenantMaintenanceRequestsPage from './components/TenantMaintenanceRequestsPage';
import RaiseMaintenanceRequest from './components/RaiseMaintenanceRequest';
import PropertyDetailsTenant from './components/PropertyDetailsTenant';
import PropertyDetails from './components/PropertyDetails';
import AvailabilityAnalytics from './components/AvailabilityAnalytics';
import OwnerMaintenancePage from './components/OwnerMaintenancePage';
import EditProperty from './components/EditProperty';
import WelcomePage from './components/WelcomePage';

const App = () => {
    return (
        <AuthProvider>
            <Router>
                <Routes>
                    <Route path="/" element={<WelcomePage />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Registration />} />

                    {/* Tenant Specific Routes */}
                    <Route path="/tenant-dashboard" element={<ProtectedRoute allowedRoles={['TENANT']}><TenantDashboard /></ProtectedRoute>} />
                    <Route path="/tenant/home" element={<ProtectedRoute allowedRoles={['TENANT']}><TenantLandingPage /></ProtectedRoute>} />
                    <Route path="/tenant/listings" element={<ProtectedRoute allowedRoles={['TENANT']}><PropertyListingsPage /></ProtectedRoute>} />
                    <Route path="/tenant/rentals" element={<ProtectedRoute allowedRoles={['TENANT']}><TenantPropertiesPage /></ProtectedRoute>} />
                    <Route path="/tenant/interests" element={<ProtectedRoute allowedRoles={['TENANT']}><InterestsPage /></ProtectedRoute>} />
                    <Route path="/tenant/maintenance" element={<ProtectedRoute allowedRoles={['TENANT']}><TenantMaintenanceRequestsPage /></ProtectedRoute>} />
                    <Route path="/tenant/notifications" element={<ProtectedRoute allowedRoles={['TENANT']}><NotificationsPage /></ProtectedRoute>} />
                    <Route path="/tenant/profile" element={<ProtectedRoute allowedRoles={['TENANT']}><TenantProfilePage /></ProtectedRoute>} />
                    <Route path="/tenant/payment/success" element={<ProtectedRoute allowedRoles={['TENANT']}><PaymentSuccessPage /></ProtectedRoute>} />
                    <Route path="/tenant/payment/create/:leaseId" element={<ProtectedRoute allowedRoles={['TENANT']}><CreateRentPayment /></ProtectedRoute>} />
                    <Route path="/tenant/payment" element={<ProtectedRoute allowedRoles={['TENANT']}><CreateRentPayment /></ProtectedRoute>} />
                    <Route path="/tenant/leases" element={<ProtectedRoute allowedRoles={['TENANT']}><TenantLeasesList /></ProtectedRoute>} />
                    <Route path="/tenant/maintenance/request/:propertyId" element={<ProtectedRoute allowedRoles={['TENANT']}><RaiseMaintenanceRequest /></ProtectedRoute>} />
                    <Route path="/tenant/property/:propertyId" element={<ProtectedRoute allowedRoles={['TENANT']}><PropertyDetailsTenant /></ProtectedRoute>} />

                    {/* Owner Specific Routes */}
                    <Route path="/owner-dashboard" element={<ProtectedRoute allowedRoles={['OWNER']}><OwnerDashboard /></ProtectedRoute>} />
                    <Route path="/owner/register-property" element={<ProtectedRoute allowedRoles={['OWNER']}><RegisterProperty /></ProtectedRoute>} />
                    <Route path="/owner/properties" element={<ProtectedRoute allowedRoles={['OWNER']}><div>Owner Properties Page (Coming Soon)</div></ProtectedRoute>} />
                    <Route path="/owner/property/:propertyId/interests" element={<ProtectedRoute allowedRoles={['OWNER']}><OwnerInterestsPage /></ProtectedRoute>} />
                    <Route path="/owner/notifications" element={<ProtectedRoute allowedRoles={['OWNER']}><NotificationsPage /></ProtectedRoute>} />
                    <Route path="/owner/property/:propertyId" element={<ProtectedRoute allowedRoles={['OWNER']}><PropertyDetails /></ProtectedRoute>} />
                     <Route path="/owner/lease/:leaseId/payment/update" element={<ProtectedRoute allowedRoles={['OWNER']}><UpdatePaymentStatus /></ProtectedRoute>} />
                    <Route path="/owner/payments/:paymentId/update-status" element={<ProtectedRoute allowedRoles={['OWNER']}><UpdatePaymentStatus /></ProtectedRoute>} />
                    <Route path="/owner/payments/:paymentId" element={<ProtectedRoute allowedRoles={['OWNER']}><UpdatePaymentStatus /></ProtectedRoute>} />
                    <Route path="/owner/property/edit/:propertyId" element={<ProtectedRoute allowedRoles={['OWNER']}><EditProperty /></ProtectedRoute>} />
                    <Route path="/owner/analytics" element={<ProtectedRoute allowedRoles={['OWNER']}><AvailabilityAnalytics /></ProtectedRoute>} />
                    <Route path="/owner/property/:propertyId/maintenance" element={<ProtectedRoute allowedRoles={['OWNER']}><OwnerMaintenancePage /></ProtectedRoute>} />

                </Routes>
            </Router>
        </AuthProvider>
    );
};

export default App;
