// UpdatePaymentStatus.js
 import React, { useState, useEffect } from 'react';
 import { useParams, Link } from 'react-router-dom';
 import './UpdatePaymentStatus.css';
 import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
 import {
   faCheckCircle,
   faTimesCircle,
   faHourglassHalf,
   faCoins,
   faArrowLeft
 } from '@fortawesome/free-solid-svg-icons';
 import axios from 'axios';

 const UpdatePaymentStatus = () => {
   const { leaseId } = useParams();
   const [paymentDetails, setPaymentDetails] = useState(null);
   const [message, setMessage] = useState('');
   const [error, setError] = useState('');
   const [loading, setLoading] = useState(true);
   const [updating, setUpdating] = useState(false);

   const fetchPaymentDetails = async () => {
     setLoading(true);
     setError('');
     try {
       const response = await axios.get(`http://localhost:8086/api/rentpayments/lease/${leaseId}`);
       console.log('Fetch Payment Details Response:', response);
       if (response.data.success && response.data.data && response.data.data.length > 0) {
         setPaymentDetails(response.data.data[0]);
       } else if (response.data.success && response.data.data.length === 0) {
         setMessage('No rent payments found for this lease.');
       } else {
         setError(response.data.message || `Failed to fetch payment details for lease ID: ${leaseId}`);
       }
     } catch (err) {
       setError('There was an error connecting to the payment details server.');
       console.error('Fetch Error (Payment Details):', err);
     } finally {
       setLoading(false);
     }
   };

   useEffect(() => {
     fetchPaymentDetails();
   }, [leaseId]);

   const handleMarkAsReceived = async () => {
     setMessage('');
     setError('');
     setUpdating(true);

     if (!paymentDetails?.paymentID) {
       setError('Could not find Payment ID to update.');
       setUpdating(false);
       return;
     }

     const paymentIdToUpdate = paymentDetails.paymentID;

     try {
       const apiUrl = `http://localhost:8086/api/rentpayments/${paymentIdToUpdate}/status`;
       const response = await axios.put(apiUrl, {
         leaseID: leaseId, // Include the leaseId in the request body
         paymentStatus: 'payment_received',
       });

       console.log('Update Payment Status Response:', response);

       if (response.data.success) {
         setMessage(`Payment with ID ${paymentIdToUpdate} marked as received successfully!`);
         fetchPaymentDetails();
       } else {
         setError(response.data.message || 'Failed to update payment status.');
       }
     } catch (err) {
       setError('There was an error connecting to the payment update server.');
       console.error('API Error (Mark as Received):', err);
     } finally {
       setUpdating(false);
     }
   };

   if (loading) {
     return <div className="loading-container"><FontAwesomeIcon icon={faHourglassHalf} spin size="2x" /> Loading payment details...</div>;
   }

   if (error) {
     return <div className="feedback-message error"><FontAwesomeIcon icon={faTimesCircle} className="message-icon" /> {error}</div>;
   }

   if (!paymentDetails) {
     return (
       <div className="update-payment-container">
         <Link to={`/owner-dashboard`} className="back-link">
           <FontAwesomeIcon icon={faArrowLeft} /> Back to Home
         </Link>
         <div>{message || 'No payment details to display.'}</div>
       </div>
     );
   }

   return (
     <div className="update-payment-container">
       <Link to={`/owner-dashboard`} className="back-link">
         <FontAwesomeIcon icon={faArrowLeft} /> Back to Home
       </Link>

       <h2>Update Payment Status for Lease: {leaseId}</h2>

       {message && <div className="feedback-message success"><FontAwesomeIcon icon={faCheckCircle} className="message-icon" /> {message}</div>}

       <div className="payment-info">
         <h3>Payment Details:</h3>
         <p><strong>Payment ID:</strong> {paymentDetails.paymentID}</p>
         {paymentDetails.propertyPrice && <p><strong>Property Price:</strong> {paymentDetails.propertyPrice}</p>}
         {paymentDetails.method && <p><strong>Payment Method:</strong> {paymentDetails.method}</p>}
         <p><strong>Status:</strong> {paymentDetails.status}</p>
         {paymentDetails.startDate && <p><strong>Start Date:</strong> {new Date(paymentDetails.startDate).toLocaleDateString()}</p>}

         {paymentDetails.status !== 'payment_received' && (
           <button onClick={handleMarkAsReceived} disabled={updating}>
             {updating ? <FontAwesomeIcon icon={faHourglassHalf} spin /> : <FontAwesomeIcon icon={faCoins} />} Mark as Received
           </button>
         )}
         {paymentDetails.status === 'payment_received' && (
           <span className="received-status"><FontAwesomeIcon icon={faCheckCircle} /> Received</span>
         )}
       </div>
     </div>
   );
 };

 export default UpdatePaymentStatus;