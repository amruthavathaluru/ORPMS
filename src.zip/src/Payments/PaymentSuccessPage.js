import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './PaymentSuccessPage.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons';
 
const PaymentSuccessPage = () => {
  const location = useLocation();
  const [paymentDetails, setPaymentDetails] = useState(null);
  // Assuming you might pass a paymentId in the location state during navigation
  const paymentId = location.state?.paymentId;
 
  useEffect(() => {
    const fetchPaymentDetails = async () => {
      if (paymentId) {
        try {
          const response = await fetch(`http://localhost:8086/api/rentpayments/${paymentId}`); // Adjust API endpoint
          if (response.ok) {
            const data = await response.json();
            setPaymentDetails(data);
          } else {
            console.error('Failed to fetch payment details.');
          }
        } catch (error) {
          console.error('Error fetching payment details:', error);
        }
      }
    };
 
    fetchPaymentDetails();
  }, [paymentId]);
 
  return (
    <div className="payment-success-container">
      <div className="success-card">
        <FontAwesomeIcon icon={faCheckCircle} className="success-icon" />
        <h1 className="success-title">Payment Successful!</h1>
        <p className="success-message">Your payment has been successfully processed and received by the owner.</p>
        {paymentDetails && (
          <div className="payment-details">
            <p><strong>Payment ID:</strong> {paymentDetails.paymentID}</p>
            <p><strong>Amount:</strong> ₹{paymentDetails.amount}</p>
            {/* Add other details you want to display */}
          </div>
        )}
        <div className="actions">
          <Link to="/tenant/home" className="dashboard-link">
            Back to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
};
 
export default PaymentSuccessPage;