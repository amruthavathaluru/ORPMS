// CreateRentPayment.js
import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useParams } from 'react-router-dom';
import './CreateRentPayment.css';
 
function CreateRentPayment() {
    const [paymentType, setPaymentType] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const { leaseId } = useParams(); // Get the leaseId directly from the URL parameter
 
    useEffect(() => {
        // The leaseId is now directly available from the URL params
        if (leaseId) {
            console.log('Lease ID from URL:', leaseId);
            // You can perform any initial setup or API calls here using the leaseId
        }
    }, [leaseId]);
 
    const handleSubmit = async (event) => {
        event.preventDefault();
        setMessage('');
        setError('');
 
        if (!leaseId) {
            setError('Lease ID is missing.');
            return;
        }
 
        if (!paymentType) {
            setError('Please select a Payment Type.');
            return;
        }
 
        // Simulate a successful API call with hardcoded data
        setTimeout(() => {
            setMessage('Rent payment initiated successfully (Simulated)!');
            setPaymentType('');
            navigate('/tenant/payment/success');
        }, 1500);
 
        // In a real scenario, you would have your actual API call here:
 
        try {
            const response = await fetch('http://localhost:8086/api/rentpayments/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ leaseId, paymentType }),
            });
 
            const data = await response.json();
 
            if (response.ok && data.success) {
                setMessage('Rent payment initiated successfully!');
                setPaymentType('');
                navigate('/tenant/payment/success');
            } else {
                setError(data.message || 'Failed to create rent payment.');
            }
        } catch (err) {
            setError('There was an error connecting to the server.');
            console.error('API Error:', err);
        }
 
    };
 
    return (
        <div className="formContainer">
            <h2>Payment Page</h2>
            <form onSubmit={handleSubmit}>
                <div className="inputGroup">
                    <label htmlFor="leaseId" className="label">Lease ID:</label>
                    <div className="leaseIdDisplay"> {/* Changed to a div for display */}
                        {leaseId}
                    </div>
                </div>
                <div className="inputGroup">
                    <label htmlFor="paymentType" className="label">Payment Type:</label>
                    <select
                        id="paymentType"
                        value={paymentType}
                        onChange={(e) => setPaymentType(e.target.value)}
                        className="input"
                    >
                        <option value="">Select Payment Type</option>
                        <option value="debit">Debit Card</option>
                        <option value="upi">UPI</option>
                        <option value="credit">Credit Card</option>
                        <option value="cash">Cash</option>
                    </select>
                </div>
                <div className="formActions">
                    <button type="submit" className="button">Create Payment</button>
                    <Link to="/tenant/home" className="dashboard-link">
                        Back to Dashboard
                    </Link>
                </div>
 
                {message && <p className="successMessage">{message}</p>}
                {error && <p className="errorMessage">{error}</p>}
            </form>
        </div>
    );
}
 
export default CreateRentPayment;