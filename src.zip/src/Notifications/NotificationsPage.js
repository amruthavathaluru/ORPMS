// src/components/NotificationsPage.js
import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import './NotificationsPage.css'; 
import { useNavigate } from 'react-router-dom';

const NotificationsPage = () => {
    const [notifications, setNotifications] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const { userId, userRole, token } = useContext(AuthContext); // Get user info and token
    const navigate = useNavigate();

    useEffect(() => {
        const fetchNotifications = async () => {
            if (userId && userRole && token) {
                setLoading(true);
                setError(null);
                let apiUrl = '';
                const backendBaseUrl = 'http://localhost:8086';
                const headers = {
                    'Authorization': `Bearer ${token}`, // Include token for authorization
                };

                if (userRole === 'TENANT') {
                    apiUrl = `${backendBaseUrl}/notifications/tenant/${userId}`;
                } else if (userRole === 'OWNER') {
                    apiUrl = `${backendBaseUrl}/notifications/owner/${userId}`;
                }

                if (apiUrl) {
                    try {
                        const response = await fetch(apiUrl, { headers });
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        const data = await response.json();
                        const formattedNotifications = data.map(n => ({
                            id: n.notificationId,
                            type: n.type,
                            message: n.message,
                            timestamp: n.createdAt,
                            read: n.isRead,
                        }));
                        setNotifications(formattedNotifications);
                    } catch (error) {
                        console.error('Error fetching notifications:', error);
                        setError('Failed to load notifications.');
                    } finally {
                        setLoading(false);
                    }
                } else {
                    setLoading(false);
                    setError('User role not recognized.');
                }
            }
        };

        fetchNotifications();
    }, [userId, userRole, token]);

    const handleMarkAsRead = async (notificationId) => {
        if (userId && token) {
            const backendBaseUrl = 'http://localhost:8086'; 
            const apiUrl = `${backendBaseUrl}/notifications/${notificationId}/read?recipientId=${userId}`;
            const headers = {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`, 
            };

            try {
                const response = await fetch(apiUrl, {
                    method: 'PUT',
                    headers: headers,
                });

                if (response.ok) {
                    const updatedNotification = await response.json();
                    setNotifications(notifications.map(n =>
                        n.id === notificationId ? { ...n, read: updatedNotification.isRead } : n
                    ));
                } else {
                    console.error('Failed to mark notification as read:', response.status);
                    
                }
            } catch (error) {
                console.error('Error marking notification as read:', error);
            }
        }
    };

    const handleMarkAllAsRead = async () => {
        if (userId && userRole && token) {
            const backendBaseUrl = 'http://localhost:8086';
            let apiUrl = '';
            const headers = {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`, // Include token for authorization
            };

            if (userRole === 'TENANT') {
                apiUrl = `${backendBaseUrl}/notifications/tenant/${userId}/read-all`;
            } else if (userRole === 'OWNER') {
                apiUrl = `${backendBaseUrl}/notifications/owner/${userId}/read-all`;
            }

            if (apiUrl) {
                try {
                    const response = await fetch(apiUrl, {
                        method: 'PUT',
                        headers: headers,
                    });

                    if (response.ok) {
                        setNotifications(notifications.map(n => ({ ...n, read: true })));
                    } else {
                        console.error('Failed to mark all notifications as read:', response.status);
                       
                    }
                } catch (error) {
                    console.error('Error marking all as read:', error);
                    
                }
            }
        }
    };

    const handleGoBack = () => {
        navigate(-1); 
    };

    return (
        <div className="notifications-page">
            <div className="notifications-container">
                <div className="header-section">
                    <h2>Notifications</h2>
                    <button onClick={handleGoBack} className="back-button">Back</button>
                </div>
                {notifications.length === 0 ? (
                    <p>No notifications yet.</p>
                ) : (
                    <>
                        <button onClick={handleMarkAllAsRead} className="mark-all-read-button">Mark All as Read</button>
                        <ul className="notifications-list">
                            {notifications.map(notification => (
                                <li key={notification.id} className={`notification-item ${notification.read ? 'read' : 'unread'}`}>
                                    <div className="notification-content">
                                        <span className="notification-type">{notification.type}</span>
                                        <p className="notification-message">{notification.message}</p>
                                        <span className="notification-timestamp">{new Date(notification.timestamp).toLocaleString()}</span>
                                    </div>
                                    {!notification.read && (
                                        <button onClick={() => handleMarkAsRead(notification.id)} className="mark-read-button">
                                            Mark as Read
                                        </button>
                                    )}
                                </li>
                            ))}
                        </ul>
                    </>
                )}
            </div>
        </div>
    );
};

export default NotificationsPage;