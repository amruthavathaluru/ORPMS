// LeaseDetailsModal.js
import React, { useState, useEffect, useContext, useRef } from 'react';
import { AuthContext } from '../context/AuthContext';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import LeaseDetailsDisplay from './LeaseDisplay'; // Ensure this points to your updated LeaseDetailsDisplay
import LeaseAgreementSign from './LeaseAgreementSign';
 
const TenantLeaseDetails = ({ lease: initialLease, propertyId, onClose }) => {
    const [leaseDetails, setLeaseDetails] = useState(initialLease || null);
    const [loading, setLoading] = useState(!initialLease);
    const [error, setError] = useState(null);
    const { token, userId: tenantID } = useContext(AuthContext);
    const navigate = useNavigate();
    const [agreed, setAgreed] = useState(false);
    const [paymentInitiating, setPaymentInitiating] = useState(false);
    const [paymentError, setPaymentError] = useState(null);
    const printRef = useRef(); // Ref to the LeaseDetailsDisplay component when printing
 
    useEffect(() => {
        if (initialLease) {
            setLeaseDetails(initialLease);
        } else if (tenantID && token && propertyId) {
            setLoading(true);
            setError(null);
            axios.get(
                `http://localhost:8069/lease/tenant/${tenantID}`,
                { headers: { Authorization: `Bearer ${token}` } }
            )
            .then(response => {
                if (response.status >= 200 && response.status < 300 && response.data && response.data.data) {
                    const agreementInitiatedLease = response.data.data.find(
                        (l) => l.leaseStatus === 'agreement_initiated' && l.propertyID === propertyId
                    );
                    setLeaseDetails(agreementInitiatedLease);
                } else if (response.status === 404) {
                    setError('No lease agreement in "agreement_initiated" status found for this property.');
                } else {
                    setError(`Failed to fetch lease details: Status ${response.status}`);
                }
            })
            .catch(err => {
                setError(`Error fetching lease details: ${err.message}`);
            })
            .finally(() => setLoading(false));
        }
    }, [initialLease, token, tenantID, propertyId]);
 
    const handleClose = () => {
        if (onClose) {
            onClose();
        } else {
            navigate('/tenant/interests');
        }
    };
 
    const handleAgreementChange = (event) => {
        setAgreed(event.target.checked);
    };
 
    const handleInitiatePayment = () => {
        if (!agreed) {
            setPaymentError('Please agree to all the terms and conditions.');
            return;
        }
 
        if (!leaseDetails?.leaseID) {
            setPaymentError('Lease information is missing.');
            return;
        }
 
        setPaymentInitiating(true);
        setPaymentError(null);
 
        const paymentUrl = `/tenant/payment/create/${leaseDetails.leaseID}`;
        console.log("Navigating to:", paymentUrl);
        navigate(paymentUrl);
    };
 
    const handlePrintLease = () => {
        if (leaseDetails) {
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                    <head>
                        <title>Lease Details - ${leaseDetails.leaseID}</title>
                        <style>
                            body { font-family: sans-serif; margin: 20px; line-height: 1.6; }
                            h3 { background-color: #f0f0f0; padding: 10px; border-radius: 5px; margin-bottom: 15px; text-align: center;}
                            strong { font-weight: bold; }
                            .section { margin-bottom: 15px; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
                            .section-title { font-weight: bold; margin-bottom: 5px; }
                            .terms-block { background-color: #e9ecef; padding: 10px; border-radius: 5px; margin-bottom: 15px; white-space: pre-wrap; word-break: break-word; margin-left: 10px; }
                            .rules-list { margin-left: 20px; margin-bottom: 15px; list-style-type: decimal; }
                            .disclaimer { font-size: 0.9em; color: #555; margin-top: 20px; text-align: center; }
                        </style>
                    </head>
                    <body>
                        <h3>Lease Agreement</h3>
                        ${renderLeaseDetailsForPrint(leaseDetails)}
                    </body>
                </html>
            `);
            printWindow.document.close();
            printWindow.print();
        } else {
            alert('Lease details are not available to print.');
        }
    };
 
    const renderLeaseDetailsForPrint = (details) => {
        if (!details) {
            return '<p>No lease details available.</p>';
        }
 
        const formatDate = (dateString) => {
            try {
                return new Date(dateString).toLocaleDateString();
            } catch (error) {
                return '';
            }
        };
 
        return `
            <div style="font-family: sans-serif; line-height: 1.6; margin: 20px;">
                <div class="section">
                    <div class="section-title">Property Information</div>
                    ${details.propertyName ? `<p><strong>Property Name:</strong> ${details.propertyName}</p>` : ''}
                    <p><strong>Address:</strong> ${details.propertyAddress || 'N/A'}</p>
                </div>
 
                <div class="section">
                    <div class="section-title">Parties</div>
                    <p>
                        <strong>Tenant:</strong> ${details.tenantName || 'N/A'} (Contact: ${details.tenantContactNo || 'N/A'})<br/>
                        <strong>Landlord:</strong> ${details.ownerName || 'N/A'} (Contact: ${details.ownerContactNo || 'N/A'})
                    </p>
                </div>
 
                <div class="section">
                    <div class="section-title">Lease Term</div>
                    <p>
                        <strong>Start Date:</strong> ${formatDate(details.startDate) || 'N/A'}<br/>
                        <strong>End Date:</strong> ${formatDate(details.endDate) || 'N/A'}
                    </p>
                </div>
 
                <div class="section">
                    <div class="section-title">Financial Terms</div>
                    <p>
                        <strong>Rent:</strong> ₹ ${details.propertyPrice || 'N/A'} per month<br/>
                        ${details.securityDeposit ? `<strong>Security Deposit:</strong> $${details.securityDeposit}<br/>` : ''}
                        ${details.paymentFrequency ? `<strong>Payment Frequency:</strong> ${details.paymentFrequency}<br/>` : ''}
                    </p>
                </div>
 
                ${details.rentalTerms ? `
                    <div class="section">
                        <div class="section-title">Rental Terms</div>
                        <p class="terms-block">${details.rentalTerms}</p>
                    </div>
                ` : ''}
 
                ${details.specialClauses ? `
                    <div class="section">
                        <div class="section-title">Special Clauses</div>
                        <p class="terms-block">${details.specialClauses}</p>
                    </div>
                ` : ''}
 
                <h4 style="margin-top: 20px; margin-bottom: 10px;">Standard Lease Rules:</h4>
                <ol class="rules-list">
                    <li>Tenant agrees to pay the rent on time as specified.</li>
                    <li>The property shall be used for residential purposes only.</li>
                    <li>Tenant shall maintain the property in a clean and safe condition.</li>
                    <li>No illegal activities are permitted on the property.</li>
                    <li>Any alterations or modifications to the property require the landlord's written consent.</li>
                    <li>Tenant shall notify the landlord of any necessary repairs or maintenance.</li>
                    ${details.latePaymentPolicy ? `<li><strong>Late Payment Policy:</strong> ${details.latePaymentPolicy}</li>` : ''}
                    ${details.petPolicy ? `<li><strong>Pet Policy:</strong> ${details.petPolicy}</li>` : ''}
                    ${details.utilitiesIncluded ? `<li><strong>Utilities Included:</strong> ${details.utilitiesIncluded}</li>` : ''}
                    ${details.tenantResponsibilities ? `<li><strong>Tenant Responsibilities:</strong> ${details.tenantResponsibilities}</li>` : ''}
                    ${details.landlordResponsibilities ? `<li><strong>Landlord Responsibilities:</strong> ${details.landlordResponsibilities}</li>` : ''}
                    ${details.termsAndConditions ? `<li><strong>Additional Terms:</strong> ${details.termsAndConditions}</li>` : ''}
 
                </ol>
            </div>
        `;
    };
 
    if (loading) {
        return <div style={styles.modal}><div style={styles.modalContent}><h3>Lease Details</h3><p>Loading lease details...</p><div style={styles.modalActions}><button style={styles.closeButton} onClick={handleClose}>Close</button></div></div></div>;
    }
 
    if (error) {
        return <div style={styles.modal}><div style={styles.modalContent}><h3>Lease Details</h3><p style={styles.error}>{error}</p><div style={styles.modalActions}><button style={styles.closeButton} onClick={handleClose}>Close</button></div></div></div>;
    }
 
    if (!leaseDetails) {
        return <div style={styles.modal}><div style={styles.modalContent}><h3>Lease Details</h3><p>No lease agreement details found.</p><div style={styles.modalActions}><button style={styles.closeButton} onClick={handleClose}>Close</button></div></div></div>;
    }
 
    const isAgreementInitiated = leaseDetails && leaseDetails.leaseStatus === 'agreement_initiated';
    const isLeaseAvailable = leaseDetails && leaseDetails.leaseStatus !== 'agreement_initiated';
 
    return (
        <div style={styles.modal}>
            <div style={styles.modalContent}>
                <h3>Lease Details</h3>
                {leaseDetails && <LeaseDetailsDisplay leaseDetails={leaseDetails} />}
 
                {isAgreementInitiated && (
                    <LeaseAgreementSign
                        agreed={agreed}
                        onAgreementChange={handleAgreementChange}
                        onInitiatePayment={handleInitiatePayment}
                        paymentError={paymentError}
                        paymentInitiating={paymentInitiating}
                    />
                )}
 
                <div style={styles.modalActions}>
                    <button style={styles.closeButton} onClick={handleClose}>Close</button>
                    {isLeaseAvailable && (
                        <button style={styles.downloadButton} onClick={handlePrintLease}>
                            Print Lease
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};
 
const styles = {
    modal: { position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', backgroundColor: 'rgba(0, 0, 0, 0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 },
    modalContent: { backgroundColor: 'white', padding: '20px', borderRadius: '5px', boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)', maxWidth: '600px', width: '90%', overflowY: 'auto', maxHeight: '80vh' },
    modalActions: { display: 'flex', justifyContent: 'space-between', marginTop: '15px' },
    closeButton: { backgroundColor: '#dc3545', color: 'white', padding: '8px 12px', border: 'none', borderRadius: '3px', cursor: 'pointer', fontSize: '0.9em' },
    downloadButton: { backgroundColor: '#007bff', color: 'white', padding: '8px 12px', border: 'none', borderRadius: '3px', cursor: 'pointer', fontSize: '0.9em' },
    error: { color: 'red', marginTop: '10px', fontSize: '0.9em' },
    success: { color: 'green', marginTop: '10px' },
};
 
export default TenantLeaseDetails;