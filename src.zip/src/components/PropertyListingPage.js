import React, { useState, useEffect, useContext } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import '../css/PropertyListingPage.css';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';


const PropertyListingPage = () => {
  
  const [properties, setProperties] = useState([]);

  
  const [loading, setLoading] = useState(true);

  
  const [error, setError] = useState(null);

  
  const navigate = useNavigate();

  
  const location = useLocation();

  
  const searchParams = new URLSearchParams(location.search);

  
  const { userId, token } = useContext(AuthContext);

  
  const [propertyNameSearch, setPropertyNameSearch] = useState(searchParams.get('propertyName') || '');

  
  const [locationFilter, setLocationFilter] = useState(searchParams.get('location') || '');

  
  const [propertyTypeFilter, setPropertyTypeFilter] = useState(searchParams.get('type') || '');

  
  const [minPriceFilter, setMinPriceFilter] = useState(searchParams.get('minPrice') || '');

  
  const [maxPriceFilter, setMaxPriceFilter] = useState(searchParams.get('maxPrice') || '');

  
  const [showInterestConfirmation, setShowInterestConfirmation] = useState(false);

  
  const [selectedPropertyForInterest, setSelectedPropertyForInterest] = useState(null);

  
  const [popupMessage, setPopupMessage] = useState(null);

  
  const [showPopup, setShowPopup] = useState(false);

  
  const fetchProperties = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get('http://localhost:8084/properties/search', {
        params: {
          propertyName: propertyNameSearch || undefined,
          location: locationFilter || undefined,
          type: propertyTypeFilter || undefined,
          minPrice: minPriceFilter || undefined,
          maxPrice: maxPriceFilter || undefined,
        },
      });

      if (response.status >= 200 && response.status < 300) {
        setProperties(response.data.data);
        setLoading(false);
      } else {
        setError(`Failed to fetch properties: Status ${response.status}`);
        setLoading(false);
      }
    } catch (err) {
      setError(`Error fetching properties: ${err.message}`);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  
  useEffect(() => {
    fetchProperties();
  }, [location.search]);

 
  const handleInterestedClick = (property) => {
    setSelectedPropertyForInterest(property);
    setShowInterestConfirmation(true);
  };

  
  const confirmInterest = async () => {
    if (!selectedPropertyForInterest) return;

    setPopupMessage(null);
    setShowPopup(false);
    setShowInterestConfirmation(false);

    try {
      if (!userId) {
        setPopupMessage('Tenant ID not found. Please log in again.');
        setShowPopup(true);
        return;
      }

      const interestData = {
        tenantID: userId,
        propertyID: selectedPropertyForInterest.propertyID,
      };

      const response = await axios.post('http://localhost:8083/interest/post', interestData, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });

      
      if (response.status >= 200 && response.status < 300 && response.data && response.data.success) {
        setPopupMessage(`Successfully expressed interest in "${selectedPropertyForInterest.propertyName}".`);
        setShowPopup(true);
        console.log('Interest submitted:', response.data);
      }

    } catch (error) {
      console.error('Error submitting interest:', error);
      if (error.response && error.response.status === 409 && error.response.data && !error.response.data.success && error.response.data.message === "Interest already exists.") {
        setPopupMessage(`You have already expressed interest in "${selectedPropertyForInterest.propertyName}".`);
        setShowPopup(true);
      } else {
        setPopupMessage(`Error submitting interest for "${selectedPropertyForInterest.propertyName}": ${error.message}`);
        setShowPopup(true);
      }
    } finally {
      setSelectedPropertyForInterest(null);
    }
  };

  
  const cancelInterest = () => {
    setShowInterestConfirmation(false);
    setSelectedPropertyForInterest(null);
  };

 
  const closePopup = () => {
    setShowPopup(false);
    setPopupMessage(null);
  };

 
  const handleViewDetails = (propertyId) => {
    navigate(`/tenant/property/${propertyId}`);
  };


  const handleFilterChange = (event) => {
    const { name, value } = event.target;
    switch (name) {
      case 'propertyName':
        setPropertyNameSearch(value);
        break;
      case 'location':
        setLocationFilter(value);
        break;
      case 'type':
        setPropertyTypeFilter(value);
        break;
      case 'minPrice':
        setMinPriceFilter(value);
        break;
      case 'maxPrice':
        setMaxPriceFilter(value);
        break;
      default:
        break;
    }
  };

  
  const handleApplyFilters = () => {
    const newSearchParams = new URLSearchParams();
    if (propertyNameSearch) newSearchParams.append('propertyName', propertyNameSearch);
    if (locationFilter) newSearchParams.append('location', locationFilter);
    if (propertyTypeFilter) newSearchParams.append('type', propertyTypeFilter);
    if (minPriceFilter) newSearchParams.append('minPrice', minPriceFilter);
    if (maxPriceFilter) newSearchParams.append('maxPrice', maxPriceFilter);

    navigate(`/tenant/listings?${newSearchParams.toString()}`);
  };

  
  const handleClearFilters = () => {
    setPropertyNameSearch('');
    setLocationFilter('');
    setPropertyTypeFilter('');
    setMinPriceFilter('');
    setMaxPriceFilter('');
    navigate('/tenant/listings');
  };

  const logoImageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1XTI8gu469dLlP3P-h8yFNdqjQ8ymadjMDQ&s';

  if (loading) {
    return <div className="property-listings-page"><h2>Loading Properties...</h2></div>;
  }

  if (error) {
    return <div className="property-listings-page"><h2>Error: {error}</h2></div>;
  }

  return (
    <div className="property-listings-page">
      {/* Navigation bar */}
      <nav className="navigation-bar">
        <ul>
          <li>
            <Link to="/" className="navbar-logo">
              <img src={logoImageUrl} alt="Logo" />
            </Link>
          </li>
          <li><Link to="/tenant/home">Home</Link></li>
          <li><Link to="/tenant/rentals">Rentals</Link></li>
          <li><Link to="/tenant/interests">Interests</Link></li>
          <li><Link to="/tenant/maintenance">Maintenance Requests</Link></li>
          <li><Link to="/tenant/notifications">Notifications</Link></li>
          <li><Link to="/tenant/profile">Profile</Link></li>
        </ul>
      </nav>

      {/* Filter options bar */}
      <div className="filter-options-bar">
        <input
          type="text"
          className="filter-input"
          placeholder="Search by Property Name or use Filters"
          name="propertyName"
          value={propertyNameSearch}
          onChange={handleFilterChange}
        />
        <select name="location" className="filter-dropdown" value={locationFilter} onChange={handleFilterChange}>
          <option value="">Any Location</option>
          <option value="Coimbatore">Coimbatore</option>
          <option value="Bangalore">Bangalore</option>
          <option value="Chennai">Chennai</option>
          <option value="Hyderabad">Hyderabad</option>
        </select>
        <select name="type" className="filter-dropdown" value={propertyTypeFilter} onChange={handleFilterChange}>
          <option value="">Any Type</option>
          <option value="Residential">Residential</option>
          <option value="Commercial">Commercial</option>
          <option value="Industrial">Industrial</option>
        </select>
        <select name="minPrice" className="filter-dropdown" value={minPriceFilter} onChange={handleFilterChange}>
          <option value="">Min Price</option>
          <option value="1000">₹1,000</option>
          <option value="2000">₹2,000</option>
          <option value="5000">₹5,000</option>
          <option value="10000">₹10,000</option>
        </select>
        <select name="maxPrice" className="filter-dropdown" value={maxPriceFilter} onChange={handleFilterChange}>
          <option value="">Max Price</option>
          <option value="5000">₹5,000</option>
          <option value="10000">₹10,000</option>
          <option value="20000">₹20,000</option>
          <option value="50000">₹50,000</option>
        </select>
        <div className="filter-buttons">
          <button className="apply-filters-button" onClick={handleApplyFilters}>Apply Filters</button>
          <button className="clear-filters-button" onClick={handleClearFilters}>Clear Filters</button>
        </div>
      </div>

      <h2>Property Listings</h2>

      <div className="property-list">
        {properties.map(property => (
          <div key={property.propertyID} className="property-card">
            <h3>{property.propertyName}</h3>
            <p>Address: {property.address}</p>
            <p>Type: {property.type}</p>
            <p>Price: ₹{property.price}</p>
            <p>Terms: {property.rentalTerms}</p>
            <div className="card-actions">
              <button className="interested-button" onClick={() => handleInterestedClick(property)}>
                Interested
              </button>
              <button className="view-details-button" onClick={() => handleViewDetails(property.propertyID)}>
                View Details
              </button>
            </div>
          </div>
        ))}
        {properties.length === 0 && !loading && <p>No properties found based on your filters.</p>}
      </div>

      {/* Express Interest Confirmation Modal */}
      {showInterestConfirmation && selectedPropertyForInterest && (
        <div className="modal">
          <div className="modal-content">
            <h3>Express Interest</h3>
            <p>Do you want to express interest in "{selectedPropertyForInterest.propertyName}"?</p>
            <div className="modal-actions">
              <button className="confirm-button" onClick={confirmInterest}>Yes</button>
              <button className="cancel-button" onClick={cancelInterest}>No</button>
            </div>
          </div>
        </div>
      )}

      {/* Popup Notification */}
      {showPopup && popupMessage && (
        <div className="modal">
          <div className="modal-content">
            <p>{popupMessage}</p>
            <button className="close-button" onClick={closePopup}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PropertyListingPage;