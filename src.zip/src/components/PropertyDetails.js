import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { FaHome, FaEdit, FaTrashAlt, FaUsers, FaTools, FaArrowLeft, FaExclamationTriangle } from 'react-icons/fa';
import { Carousel } from 'react-bootstrap'; 
 
const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.5, ease: "easeOut" } },
    exit: { opacity: 0 },
};
 
const imageStyle = {
    width: '100%',
    height: 'auto',
    borderRadius: '0.5rem',
    boxShadow: '0 0.5rem 1rem rgba(0,0,0,0.15)',
    marginBottom: '1.5rem',
    objectFit: 'cover',
    maxHeight: '400px',
};
 
const detailItemStyle = {
    marginBottom: '1rem',
};
 
const badgeStyle = {
    fontSize: '0.9rem',
    fontWeight: '500',
    padding: '0.4rem 0.8rem',
    borderRadius: '0.3rem',
    marginBottom: '0.5rem',
    display: 'inline-block',
};
 
const buttonStyle = {
    borderRadius: '0.3rem',
    padding: '0.6rem 1.2rem',
    fontSize: '1rem',
};
 
const backButtonStyle = {
    position: 'absolute',
    top: '1rem',
    left: '1rem',
    zIndex: 10,
    borderRadius: '0.3rem',
    padding: '0.5rem 1rem',
    fontSize: '0.9rem',
};
 
function PropertyDetails() {
    const { propertyId } = useParams();
    const { token } = useContext(AuthContext);
    const [property, setProperty] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();
 
    useEffect(() => {
        const fetchPropertyDetails = async () => {
            setLoading(true);
            setError('');
            try {
                const response = await axios.get(`http://localhost:8084/properties/${propertyId}`, {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                });
                if (response.status >= 200 && response.status < 300 && response.data.data) {
                    setProperty(response.data.data);
                } else {
                    setError(`Failed to fetch property details: Status ${response.status}`);
                }
            } catch (err) {
                setError(`Error fetching property details: ${err.message}`);
            } finally {
                setLoading(false);
            }
        };
 
        fetchPropertyDetails();
    }, [propertyId, token]);
 
    const getImageDataUrl = (imageData, contentType) => {
        if (imageData && contentType) {
            return `data:${contentType};base64,${imageData}`;
        }
        return null;
    };
 
    if (loading) {
        return (
            <motion.div className="container mt-5 d-flex justify-content-center align-items-center" variants={containerVariants} initial="hidden" animate="visible" exit="exit" style={{ minHeight: '80vh' }}>
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </motion.div>
        );
    }
    
    if (error) {
        return (
            <motion.div className="container mt-5 alert alert-danger shadow-sm" variants={containerVariants} initial="hidden" animate="visible" exit="exit">
                <FaExclamationTriangle className="me-2" /> {error}
            </motion.div>
        );
    }
 
    if (!property) {
        return (
            <motion.div className="container mt-5 alert alert-warning shadow-sm" variants={containerVariants} initial="hidden" animate="visible" exit="exit">
                <FaExclamationTriangle className="me-2" /> Property not found.
            </motion.div>
        );
    }
 
    const isRented = property.availabilityStatus.toLowerCase() === 'rented';
 
    return (
        <motion.div className="bg-light py-5" variants={containerVariants} initial="hidden" animate="visible" exit="exit" style={{ minHeight: '100vh' }}>
            <div className="container" style={{ maxWidth: '90%', boxShadow: '0 0.5rem 1rem rgba(0,0,0,0.1)' }}>
                <div className="card rounded-3">
                    <div className="card-body p-4 p-md-5">
                        <Link to="/owner-dashboard" className="btn btn-outline-secondary rounded-pill mb-3" style={backButtonStyle}>
                            <FaArrowLeft className="me-2" /> Back
                        </Link>
                        <div className="row">
                            {/* Image Section (Left - 50%) */}
                            <div className="col-md-6">
                                {property.images && property.images.length > 0 ? (
                                    <Carousel>
                                        {property.images.map((image, index) => (
                                            <Carousel.Item key={index}>
                                                <img
                                                    style={imageStyle}
                                                    className="d-block w-100"
                                                    src={getImageDataUrl(image.imageData, image.imageContentType)}
                                                    alt={`Property ${index + 1}`}
                                                />
                                                <Carousel.Caption>
                                                    {/* You can add a caption here if needed */}
                                                </Carousel.Caption>
                                            </Carousel.Item>
                                        ))}
                                    </Carousel>
                                ) : (
                                    <div className="bg-secondary text-white rounded p-5 d-flex justify-content-center align-items-center" style={{ height: '300px' }}>
                                        No Image Available
                                    </div>
                                )}
                            </div>
 
                            {/* Details Section (Right - 50%) */}
                            <div className="col-md-6">
                                <h2 className="mb-4 fw-bold text-primary">{property.propertyName}</h2>
                                <p style={detailItemStyle}><strong className="text-muted">Address:</strong> {property.address}</p>
                                <p style={detailItemStyle}><strong className="text-muted">Type:</strong> <span className="badge bg-info" style={badgeStyle}>{property.type}</span></p>
                                <p style={detailItemStyle}><strong className="text-muted">Price:</strong> <span className="badge bg-success" style={badgeStyle}>₹{property.price}</span></p>
                                <p style={detailItemStyle}><strong className="text-muted">Rental Terms:</strong> <span className="badge bg-secondary" style={badgeStyle}>{property.rentalTerms}</span></p>
                                <p style={detailItemStyle}><strong className="text-muted">Availability:</strong>
                                    {property.availabilityStatus === 'available' ? (
                                        <span className="badge bg-success" style={badgeStyle}>Available</span>
                                    ) : (
                                        <span className="badge bg-warning text-dark" style={badgeStyle}>Occupied</span>
                                    )}
                                </p>
                                {property.description && <p style={detailItemStyle}><strong className="text-muted">Description:</strong> <br /> {property.description}</p>}
 
                                {/* Bottom Buttons */}
                                <div className="mt-4 d-flex gap-2">
                                    <Link to={`/owner/property/edit/${propertyId}`} className="btn btn-primary rounded-pill" style={buttonStyle}>
                                        <FaEdit className="me-2" /> Edit
                                    </Link>
                                    
                                    <Link to={`/owner/property/${propertyId}/interests`} className="btn btn-info rounded-pill" style={buttonStyle}>
                                        <FaUsers className="me-2" /> Interests
                                    </Link>
                                    <Link
                                        to={isRented ? `/owner/property/${propertyId}/maintenance` : '#'}
                                        className={`btn rounded-pill ${isRented ? 'btn-warning' : 'btn-secondary disabled'}`}
                                        style={buttonStyle}
                                    >
                                        <FaTools className="me-2" /> Maintenance
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </motion.div>
    );
}
 
export default PropertyDetails;