import React from 'react';

function DefaultDashboard() {
  return (
    <div>
      <h1>Error!!!</h1>
    </div>
  );
}

export default DefaultDashboard;