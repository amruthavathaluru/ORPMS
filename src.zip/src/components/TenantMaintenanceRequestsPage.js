// src/components/TenantMaintenanceRequestsPage.js
import React, { useState, useEffect, useContext } from 'react';
import '../css/TenantMaintenanceRequestsPage.css'; // Ensure you have this CSS
import { AuthContext } from '../context/AuthContext';
import { Link } from 'react-router-dom';
import axios from 'axios';


const TenantMaintenanceRequestsPage = () => {
  
  const [maintenanceRequests, setMaintenanceRequests] = useState([]);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState('');

  
  const { userId, token } = useContext(AuthContext); // Get userId and token

 
  useEffect(() => {
    const fetchMaintenanceRequests = async () => {
      setLoading(true);
      setError('');

      // Check if userId and token are available
      if (!userId || !token) {
        setError('Authentication failed. Please log in again.');
        setLoading(false);
        return;
      }

      const apiUrl = `http://localhost:8081/api/maintenance-requests/tenant/${userId}`;

      try {
        const response = await axios.get(apiUrl, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (response.data.success && response.data.data) {
          // Fetch property name for each request
          const requestsWithProperty = await Promise.all(
            response.data.data.map(async (request) => {
              try {
                const propertyResponse = await axios.get(`http://localhost:8084/properties/${request.propertyID}`);
                if (propertyResponse.data.success && propertyResponse.data.data) {
                  return { ...request, propertyName: propertyResponse.data.data.propertyName };
                } else {
                  return { ...request, propertyName: 'N/A' };
                }
              } catch (propertyError) {
                console.error('Error fetching property details:', propertyError);
                return { ...request, propertyName: 'N/A' };
              }
            })
          );
          setMaintenanceRequests(requestsWithProperty);
        } else {
          setError(response.data.message || 'Failed to fetch maintenance requests.');
        }
      } catch (err) {
        console.error('Error fetching maintenance requests:', err);
        setError(`Failed to fetch maintenance requests: ${err.message}`);
      } finally {
        setLoading(false);
      }
    };

    fetchMaintenanceRequests();
  }, [userId, token]);

  
  const formatStatus = (status) => {
    if (!status) return 'N/A';
    return status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString();
    } catch (e) {
      return dateString;
    }
  };

  const logoImageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1XTI8gu469dLlP3P-h8yFNdqjQ8ymadjMDQ&s'; // Replace with your logo URL

  return (
    <div className="tenant-maintenance-requests-page">
      {/* Navigation bar for tenant section */}
      <nav className="navigation-bar">
        <ul>
          <li>
            <Link to="/tenant/home" className="navbar-logo">
              <img src={logoImageUrl} alt="Logo" style={{ height: '30px', width: 'auto', verticalAlign: 'middle' }} />
            </Link>
          </li>
          <li><Link to="/tenant/home">Home</Link></li>
          <li><Link to="/tenant/rentals">Rentals</Link></li>
          <li><Link to="/tenant/interests">Interests</Link></li>
          <li><Link to="/tenant/maintenance" className="active-link">Maintenance Requests</Link></li>
          <li><Link to="/tenant/notifications">Notifications</Link></li>
          <li><Link to="/tenant/profile">Profile</Link></li>
        </ul>
      </nav>

      <div className="maintenance-container">
        <h1>My Maintenance Requests</h1>
        {loading ? (
          <p>Loading maintenance requests...</p>
        ) : error ? (
          <p className="error">{error}</p>
        ) : maintenanceRequests.length > 0 ? (
          <div className="maintenance-cards-grid">
            {maintenanceRequests.map(request => (
              <div key={request.requestID} className="maintenance-card">
                <h3 className="card-title">{request.propertyName}</h3>
                <p className="card-description">
                  <strong>Description:</strong> {request.issueDescription.length > 100 ? `${request.issueDescription.substring(0, 100)}...` : request.issueDescription}
                </p>
                <p className="card-date">
                  <strong>Submitted On:</strong> {formatDate(request.createdAt)}
                </p>
                <p className={`card-status status-${request.status}`}>
                  <strong>Status:</strong> {formatStatus(request.status)}
                </p>
                {/* You can add more details or actions here if needed */}
              </div>
            ))}
          </div>
        ) : (
          <p className="no-requests">No maintenance requests found.</p>
        )}
      </div>
    </div>
  );
};

export default TenantMaintenanceRequestsPage;