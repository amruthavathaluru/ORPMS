import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { FaArrowLeft, FaMapMarkerAlt, FaBuilding, FaRupeeSign, FaFileContract, FaCheckCircle, FaTimesCircle } from 'react-icons/fa';
import { Carousel } from 'react-bootstrap'; // Import Carousel
 
const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.6, ease: "easeInOut" } },
    exit: { opacity: 0, transition: { duration: 0.4 } },
};
 
const imageStyle = {
    width: '100%',
    height: 'auto',
    borderRadius: '0.75rem',
    boxShadow: '0 0.75rem 1.5rem rgba(0,0,0,0.18)',
    marginBottom: '2rem',
    objectFit: 'cover',
    maxHeight: '500px',
};
 
const detailItemStyle = {
    marginBottom: '1.25rem',
    fontSize: '1.1rem',
};
 
const badgeStyle = {
    fontSize: '1rem',
    fontWeight: '600',
    padding: '0.5rem 1rem',
    borderRadius: '0.375rem',
    marginBottom: '0.75rem',
    display: 'inline-block',
};
 
const backButtonStyle = {
    position: 'absolute',
    top: '1.5rem',
    left: '1.5rem',
    zIndex: 10,
    borderRadius: '0.375rem',
    padding: '0.6rem 1.2rem',
    fontSize: '1rem',
    backgroundColor: 'rgba(255, 255, 255, 0.85)',
    boxShadow: '0 0.25rem 0.5rem rgba(0,0,0,0.08)',
    backdropFilter: 'blur(10px)',
    border: '1px solid rgba(255, 255, 255, 0.5)',
    color: '#333',
    transition: 'all 0.3s ease-in-out',
    '&:hover': {
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        boxShadow: '0 0.3rem 0.6rem rgba(0,0,0,0.12)',
    },
};
 
const primaryTextStyle = {
    color: '#007bff',
    fontWeight: 'bold',
};
 
const secondaryTextStyle = {
    color: '#6c757d',
};
 
function PropertyDetailsTenant() {
    const { propertyId } = useParams();
    const { token } = useContext(AuthContext);
    const [property, setProperty] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const [showInterestConfirmation, setShowInterestConfirmation] = useState(false);
    const [popupMessage, setPopupMessage] = useState(null);
    const [showPopup, setShowPopup] = useState(false);
    const { userId } = useContext(AuthContext);
 
    useEffect(() => {
        const fetchPropertyDetails = async () => {
            setLoading(true);
            setError('');
            try {
                const response = await axios.get(`http://localhost:8084/properties/${propertyId}`, {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                });
                if (response.status >= 200 && response.status < 300 && response.data.data) {
                    setProperty(response.data.data);
                } else {
                    setError(`Failed to fetch property details: Status ${response.status}`);
                }
            } catch (err) {
                setError(`Error fetching property details: ${err.message}`);
            } finally {
                setLoading(false);
            }
        };
 
        fetchPropertyDetails();
    }, [propertyId, token]);
 
    const getImageDataUrl = (imageData, contentType) => {
        if (imageData && contentType) {
            return `data:${contentType};base64,${imageData}`;
        }
        return null;
    };
 
    const handleInterestedClick = () => {
        if (property && property.availabilityStatus === 'available') {
            setShowInterestConfirmation(true);
        } else if (property && property.availabilityStatus === 'rented') {
            setPopupMessage(`"${property.propertyName}" is currently rented and not available for interest.`);
            setShowPopup(true);
        } else {
            setPopupMessage("Property availability status is unknown.");
            setShowPopup(true);
        }
    };
 
    const confirmInterest = async () => {
        if (!property || !userId) return;
 
        setPopupMessage(null);
        setShowPopup(false);
        setShowInterestConfirmation(false);
 
        try {
            const interestData = {
                tenantID: userId,
                propertyID: property.propertyID,
            };
 
            const response = await axios.post('http://localhost:8083/interest/post', interestData, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
            });
 
            if (response.status >= 200 && response.status < 300 && response.data && response.data.success) {
                setPopupMessage(`Successfully expressed interest in "${property.propertyName}".`);
                setShowPopup(true);
                console.log('Interest submitted:', response.data);
            }
 
        } catch (error) {
            console.error('Error submitting interest:', error);
            if (error.response && error.response.status === 409 && error.response.data && !error.response.data.success && error.response.data.message === "Interest already exists.") {
                setPopupMessage(`You have already expressed interest in "${property.propertyName}".`);
                setShowPopup(true);
            } else {
                setPopupMessage(`Error submitting interest for "${property.propertyName}": ${error.message}`);
                setShowPopup(true);
            }
        }
    };
 
    const cancelInterest = () => {
        setShowInterestConfirmation(false);
    };
 
    const closePopup = () => {
        setShowPopup(false);
        setPopupMessage(null);
    };
 
    if (loading) {
        return (
            <motion.div className="container mt-5 d-flex justify-content-center align-items-center" variants={containerVariants} initial="hidden" animate="visible" exit="exit" style={{ minHeight: '80vh' }}>
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </motion.div>
        );
    }
 
    if (error) {
        return (
            <motion.div className="container mt-5 alert alert-danger shadow-sm" variants={containerVariants} initial="hidden" animate="visible" exit="exit">
                {error}
            </motion.div>
        );
    }
 
    if (!property) {
        return (
            <motion.div className="container mt-5 alert alert-warning shadow-sm" variants={containerVariants} initial="hidden" animate="visible" exit="exit">
                Property not found.
            </motion.div>
        );
    }
 
    return (
        <motion.div className="bg-white py-5" variants={containerVariants} initial="hidden" animate="visible" exit="exit" style={{ minHeight: '100vh' }}>
            <div className="container" style={{ maxWidth: '90%', boxShadow: '0 1rem 2rem rgba(0,0,0,0.12)', borderRadius: '1rem' }}>
                <div className="card rounded-3 overflow-hidden shadow-lg">
                    <div className="row g-0">
                        {/* Image Section (Left - 60%) */}
                        <div className="col-lg-6 bg-light d-flex align-items-center justify-content-center p-4">
                            {property.images && property.images.length > 0 ? (
                                <Carousel>
                                    {property.images.map((image, index) => (
                                        <Carousel.Item key={index}>
                                            <img
                                                style={imageStyle}
                                                className="d-block w-100"
                                                src={getImageDataUrl(image.imageData, image.imageContentType)}
                                                alt={`Property ${index + 1}`}
                                            />
                                            <Carousel.Caption>
                                                {/* You can add a caption here if needed */}
                                            </Carousel.Caption>
                                        </Carousel.Item>
                                    ))}
                                </Carousel>
                            ) : (
                                <div className="bg-secondary text-white rounded p-5 d-flex justify-content-center align-items-center" style={{ height: '400px' }}>
                                    No Image Available
                                </div>
                            )}
                        </div>
 
                        {/* Details Section (Right - 40%) */}
                        <div className="col-lg-6 p-4">
                            <Link to="/tenant/listings" className="btn btn-outline-secondary rounded-pill mb-3" style={backButtonStyle}>
                                <FaArrowLeft className="me-2" /> Back
                            </Link>
                            <div className="p-lg-3">
                                <h2 className="mb-4 fw-bold" style={primaryTextStyle}>{property.propertyName}</h2>
                                <p style={detailItemStyle}><strong style={secondaryTextStyle}><FaMapMarkerAlt className="me-1" /> Address:</strong> {property.address}</p>
                                <p style={detailItemStyle}><strong style={secondaryTextStyle}><FaBuilding className="me-1" /> Type:</strong> <span className="badge bg-info" style={badgeStyle}>{property.type}</span></p>
                                <p style={detailItemStyle}><strong style={secondaryTextStyle}><FaRupeeSign className="me-1" /> Price:</strong> <span className="badge bg-success" style={badgeStyle}>₹{property.price}</span></p>
                                <p style={detailItemStyle}><strong style={secondaryTextStyle}><FaFileContract className="me-1" /> Terms:</strong> <span className="badge bg-secondary" style={badgeStyle}>{property.rentalTerms}</span></p>
                                <p style={detailItemStyle}><strong style={secondaryTextStyle}>Availability:</strong>
                                    {property.availabilityStatus === 'available' ? (
                                        <span className="badge bg-success" style={badgeStyle}>Available</span>
                                    ) : (
                                        <span className="badge bg-warning text-dark" style={badgeStyle}>Occupied</span>
                                    )}
                                </p>
                                {property.description && <p style={detailItemStyle}><strong style={secondaryTextStyle}>Description:</strong> <br /> {property.description}</p>}
 
                                <div className="mt-4">
                                    <button
                                        className="btn btn-success rounded-pill px-4 py-2 fs-16 fw-bold shadow-sm"
                                        onClick={handleInterestedClick}
                                        disabled={property.availabilityStatus !== 'available' || !userId}
                                        style={{ transition: 'all 0.3s ease-in-out', '&:hover': { transform: 'scale(1.05)' } }}
                                    >
                                        {property.availabilityStatus === 'rented' ? 'Rented' : 'Express Interest'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 
            {showInterestConfirmation && (
                <div className="modal fade show animate__animated animate__fadeIn" tabIndex="-1" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-dialog-centered animate__animated animate__slideInDown">
                        <div className="modal-content">
                            <div className="modal-header bg-light">
                                <h5 className="modal-title fw-bold text-primary">Confirm Interest</h5>
                                <button type="button" className="btn-close" onClick={cancelInterest} aria-label="Close"></button>
                            </div>
                            <div className="modal-body">
                                <p className="fs-16">Are you sure you want to express interest in <strong className="text-primary">{property.propertyName}</strong>?</p>
                            </div>
                            <div className="modal-footer bg-light">
                                <button type="button" className="btn btn-secondary rounded-pill px-3" onClick={cancelInterest}>
                                    <FaTimesCircle className="me-1" /> No
                                </button>
                                <button type="button" className="btn btn-primary rounded-pill px-4" onClick={confirmInterest}>
                                    <FaCheckCircle className="me-1" /> Yes
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
 
            {showPopup && popupMessage && (
                <div className="modal fade show animate__animated animate__fadeIn" tabIndex="-1" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className="modal-dialog modal-dialog-centered animate__animated animate__slideInDown">
                        <div className="modal-content">
                            <div className="modal-body">
                                <p className="mb-0 fs-16">{popupMessage}</p>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-primary rounded-pill px-3" onClick={closePopup}>Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </motion.div>
    );
}
 
export default PropertyDetailsTenant;