import React from 'react';

function TenantDashboard() {
  return (
    <div>
      <h1>Welcome to the Tenant Dashboard</h1>
    </div>
  );
}

export default TenantDashboard;