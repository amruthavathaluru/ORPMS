// src/components/ProtectedRoute.js
import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { Navigate, useNavigate } from 'react-router-dom';

const ProtectedRoute = ({ allowedRoles, children }) => {
    const { token, userRole } = useContext(AuthContext);
    const navigate = useNavigate();

    const handleGoToLogin = () => {
        navigate('/login');
    };

    if (!token) {
        // Not authenticated, redirect to login
        return <Navigate to="/login" replace />;
    }

    if (allowedRoles.includes(userRole)) {
        // User is authenticated and has the required role, render the children
        return children;
    }

    // User is authenticated but doesn't have the required role
    return (
        <div className="container mt-5">
            <div className="alert alert-danger" role="alert">
                <h4 className="alert-heading">Access Denied</h4>
                <p>You do not have permission to access this page.</p>
                <hr />
                <button className="btn btn-secondary" onClick={handleGoToLogin}>OK</button>
            </div>
        </div>
    );
};

export default ProtectedRoute;