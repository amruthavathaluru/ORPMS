// src/components/LeaseCreation.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const LeaseCreation = ({ interest, onClose, onLeaseCreated }) => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [tenantName, setTenantName] = useState('');
    const [propertyName, setPropertyName] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchDetails = async () => {
            setLoading(true);
            setError(null);
            try {
                // Fetch tenant details
                const tenantResponse = await axios.get(
                    `http://localhost:8083/tenant/profile/${interest.tenantID}`
                );
                if (tenantResponse.data.success && tenantResponse.data.data) {
                    setTenantName(tenantResponse.data.data.name || 'N/A');
                } else {
                    console.error('Failed to fetch tenant details:', tenantResponse.data?.message);
                    setTenantName('N/A');
                }

                // Fetch property details
                const propertyResponse = await axios.get(
                    `http://localhost:8084/properties/${interest.propertyID}`
                );
                if (propertyResponse.data.success && propertyResponse.data.data) {
                    setPropertyName(propertyResponse.data.data.propertyName || 'N/A');
                } else {
                    console.error('Failed to fetch property details:', propertyResponse.data?.message);
                    setPropertyName('N/A');
                }
            } catch (err) {
                console.error('Error fetching details:', err);
                setError('Failed to fetch tenant and property details.');
                setTenantName('N/A');
                setPropertyName('N/A');
            } finally {
                setLoading(false);
            }
        };

        if (interest && interest.tenantID && interest.propertyID) {
            fetchDetails();
        }
    }, [interest]);

    const handleCreateLease = async () => {
        setLoading(true);
        setError(null);

        const leaseCreationData = {
            interestID: interest.interestID,
            tenantID: interest.tenantID,
            propertyID: interest.propertyID,
        };

        try {
            const response = await axios.post(
                'http://localhost:8069/lease/display',
                leaseCreationData
            );

            if (response.data.success && response.data.data) {
                setLoading(false);

                console.log('Lease Details:', response.data.data);
                if (onLeaseCreated) {
                    onLeaseCreated(response.data.data); // Pass the lease details back to the parent
                }
                if (onClose) {
                    onClose(); // Close the modal after successful lease display/creation
                }

            } else {
                setError(response.data.message || 'Failed to create/display lease.');
                setLoading(false);
            }
        } catch (error) {
            if (error.response && error.response.status === 409) {
                setError('Lease already exists for this property.');
            } else {
                setError(error.message || 'An unexpected error occurred while creating/displaying the lease.');
            }
            setLoading(false);
        }
    };

    return (
        <div style={styles.modal}>
            <div style={styles.modalContent}>
                <h3>Confirm Lease Creation</h3>
                <p>Are you sure you want to create a lease for this interest?</p>
                <p>Tenant Name: {tenantName}</p>
                <p>Property Name: {propertyName}</p>

                {error && <p style={styles.error}>{error}</p>}

                <div style={styles.modalActions}>
                    <button style={styles.closeButton} onClick={onClose}>Cancel</button>
                    <button
                        style={styles.createButton}
                        onClick={handleCreateLease}
                        disabled={loading}
                    >
                        {loading ? 'Creating Lease...' : 'Create Lease'}
                    </button>
                </div>
            </div>
        </div>
    );
};

const styles = {
    modal: {
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 1000,
    },
    modalContent: {
        backgroundColor: 'white',
        padding: '20px',
        borderRadius: '5px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        maxWidth: '400px',
        width: '90%',
    },
    modalActions: {
        display: 'flex',
        justifyContent: 'flex-end',
        marginTop: '20px',
    },
    closeButton: {
        backgroundColor: '#6c757d',
        color: 'white',
        padding: '8px 12px',
        border: 'none',
        borderRadius: '3px',
        cursor: 'pointer',
        marginRight: '10px',
    },
    createButton: {
        backgroundColor: '#28a745',
        color: 'white',
        padding: '8px 12px',
        border: 'none',
        borderRadius: '3px',
        cursor: 'pointer',
        disabled: false,
    },
    error: {
        color: 'red',
        marginTop: '10px',
    },
};

export default LeaseCreation;