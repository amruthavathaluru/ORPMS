import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/Registration.css'; 


function Registration() {
  
  const [error, setError] = useState('');

  const navigate = useNavigate();

  const baseURL = 'http://localhost:8087/auth';

  const validationSchema = yup.object().shape({
    email: yup.string().email('Enter a valid email').required('Email is required'),
    password: yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
    userType: yup.string().required('Role is required'),
    name: yup.string().required('Name is required').matches(/^[a-zA-Z\s]+$/, 'Name must contain only letters and spaces'),
    contactNo: yup.string().matches(/^[1-9][0-9]{9}$/, 'Enter a valid 10-digit contact number').required('Contact number is required'),
    gender: yup.string().required('Gender is required'),
  });

  
  const {
    register, // Function to register input fields with the form
    handleSubmit, // Function to handle form submission
    formState: { errors }, // Object containing validation errors for each registered field
  } = useForm({
    resolver: yupResolver(validationSchema), // Integrates Yup schema validation with react-hook-form
  });

  
  const [userType, setUserType] = useState('');

  
  const onSubmit = async (formData) => {
    setError(''); // Clear any previous error messages

    const registrationData = {
      email: formData.email,
      password: formData.password,
      userType: formData.userType,
      details: {
        name: formData.name,
        contactNo: formData.contactNo,
        gender: formData.gender,
      },
    };

    try {
      const response = await axios.post(`${baseURL}/register`, registrationData);
      console.log('Registration successful:', response.data);
      navigate('/login'); // Redirect to the login page after successful registration
    } catch (err) {
      // Handle registration errors
      if (err.response && err.response.data && err.response.data.message) {
        setError(err.response.data.message); // Sets error message from the backend
      } else {
        setError('Registration failed. Please try again.'); // Sets a generic error message
      }
    }
  };

  return (
    <div className="registration-container">
      <div className="registration-card">
        <h2 className="registration-title">Registration</h2>
        {/* Display any registration error messages */}
        {error && <div className="alert alert-danger">{error}</div>}
        {/* Registration form */}
        <form onSubmit={handleSubmit(onSubmit)} className="registration-form">
          <div className="form-group">
            <label htmlFor="email" className="form-label">Email</label>
            <input
              type="email"
              {...register('email')} // Register the email input with react-hook-form
              className={`form-control ${errors.email ? 'is-invalid' : ''}`} // Apply 'is-invalid' class for validation errors
              id="email"
            />
            {/* Display email validation error message */}
            {errors.email && <div className="invalid-feedback">{errors.email.message}</div>}
          </div>
          <div className="form-group">
            <label htmlFor="password" className="form-label">Password</label>
            <input
              type="password"
              {...register('password')} // Register the password input with react-hook-form
              className={`form-control ${errors.password ? 'is-invalid' : ''}`} // Apply 'is-invalid' class for validation errors
              id="password"
            />
            {/* Display password validation error message */}
            {errors.password && <div className="invalid-feedback">{errors.password.message}</div>}
          </div>
          <div className="form-group">
            <label className="form-label">Role</label>
            <div>
              <div className="form-check form-check-inline">
                <input
                  className={`form-check-input ${errors.userType ? 'is-invalid' : ''}`} 
                  type="radio"
                  name="userType"
                  id="tenant"
                  value="TENANT"
                  {...register('userType')} // Register the tenant radio button with react-hook-form
                  onChange={() => setUserType('TENANT')} // Update userType state on change
                />
                <label className="form-check-label" htmlFor="tenant">Tenant</label>
              </div>
              <div className="form-check form-check-inline">
                <input
                  className={`form-check-input ${errors.userType ? 'is-invalid' : ''}`} 
                  type="radio"
                  name="userType"
                  id="owner"
                  value="OWNER"
                  {...register('userType')} // Register the owner radio button with react-hook-form
                  onChange={() => setUserType('OWNER')} // Update userType state on change
                />
                <label className="form-check-label" htmlFor="owner">Owner</label>
              </div>
              {/* Display userType validation error message */}
              {errors.userType && <div className="invalid-feedback d-block">{errors.userType.message}</div>}
            </div>
          </div>

          {/* Conditionally render additional details fields based on userType */}
          {(userType === 'TENANT' || userType === 'OWNER') && (
            <>
              <div className="form-group">
                <label htmlFor="name" className="form-label">Name</label>
                <input
                  type="text"
                  {...register('name')} // Register the name input with react-hook-form
                  className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                  id="name"
                />
                {/* Display name validation error message */}
                {errors.name && <div className="invalid-feedback">{errors.name.message}</div>}
              </div>
              <div className="form-group">
                <label htmlFor="contactNo" className="form-label">Contact Number</label>
                <input
                  type="text"
                  {...register('contactNo')} // Register the contactNo input with react-hook-form
                  className={`form-control ${errors.contactNo ? 'is-invalid' : ''}`} 
                  id="contactNo"
                />
                {/* Display contact number validation error message */}
                {errors.contactNo && <div className="invalid-feedback">{errors.contactNo.message}</div>}
              </div>
              <div className="form-group">
                <label className="form-label">Gender</label>
                <div>
                  <div className="form-check form-check-inline">
                    <input
                      className={`form-check-input ${errors.gender ? 'is-invalid' : ''}`} 
                      type="radio"
                      name="gender"
                      id="male"
                      value="Male"
                      {...register('gender')} // Register the male radio button with react-hook-form
                    />
                    <label className="form-check-label" htmlFor="male">Male</label>
                  </div>
                  <div className="form-check form-check-inline">
                    <input
                      className={`form-check-input ${errors.gender ? 'is-invalid' : ''}`} 
                      type="radio"
                      name="gender"
                      id="female"
                      value="Female"
                      {...register('gender')} // Register the female radio button with react-hook-form
                    />
                    <label className="form-check-label" htmlFor="female">Female</label>
                  </div>
                  <div className="form-check form-check-inline">
                    <input
                      className={`form-check-input ${errors.gender ? 'is-invalid' : ''}`} 
                      type="radio"
                      name="gender"
                      id="other"
                      value="Other"
                      {...register('gender')} // Register the other radio button with react-hook-form
                    />
                    <label className="form-check-label" htmlFor="other">Other</label>
                  </div>
                  {/* Display gender validation error message */}
                  {errors.gender && <div className="invalid-feedback d-block">{errors.gender.message}</div>}
                </div>
              </div>
            </>
          )}

          {/* Submit button */}
          <button type="submit" className="btn btn-primary registration-button">
            Register
          </button>
        </form>
        {/* Link to the login page */}
        <p className="registration-login-text">
          Already have an account? <Link to="/login" className="registration-login-link">Login</Link>
        </p>
      </div>
    </div>
  );
}

export default Registration;