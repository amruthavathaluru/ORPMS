import React, { useState, useEffect, useContext } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { FaHome, FaArrowLeft } from 'react-icons/fa';
import { parseISO, format } from 'date-fns'; // For date formatting
 
const OwnerMaintenancePage = () => {
    const { propertyId } = useParams();
    const { token } = useContext(AuthContext);
    const [maintenanceRequests, setMaintenanceRequests] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [updatedRequestData, setUpdatedRequestData] = useState({}); 
    const [showUpdateMessage, setShowUpdateMessage] = useState(false);
    const navigate = useNavigate();
 
    const fetchMaintenanceRequests = async () => {
        setLoading(true);
        setError('');
        try {
            const response = await axios.get(
                `http://localhost:8081/api/maintenance-requests/property/${propertyId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            );
            if (response.status >= 200 && response.data.success && response.data.data) {
                setMaintenanceRequests(response.data.data);
                
                const initialUpdatedData = {};
                response.data.data.forEach(req => {
                    initialUpdatedData[req.requestID] = {
                        requestID: req.requestID,
                        tenantID: req.tenantID,
                        propertyID: req.propertyID,
                        issueDescription: req.issueDescription,
                        status: req.status, 
                        createdAt: req.createdAt,
                        updatedAt: req.updatedAt
                    };
                });
                setUpdatedRequestData(initialUpdatedData);
            } else {
                setError('Failed to fetch maintenance requests.');
            }
        } catch (err) {
            setError(`Error fetching maintenance requests: ${err.message}`);
        } finally {
            setLoading(false);
        }
    };
 
    useEffect(() => {
        fetchMaintenanceRequests();
    }, [propertyId, token]);
 
    const handleStatusChange = (requestId, newStatus) => {
        setUpdatedRequestData(prevData => ({
            ...prevData,
            [requestId]: {
                ...prevData[requestId], 
                status: newStatus,
            },
        }));
    };
 
    const handleUpdateRequest = async (requestId) => {
        try {
            const requestBody = updatedRequestData[requestId];
 
            const response = await axios.put(
                `http://localhost:8081/api/maintenance-requests/update/${requestId}`,
                requestBody,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            );
            console.log('Update Response:', response);
            if (response.status >= 200 && response.data && response.data.success) {
                setShowUpdateMessage(true);
                setTimeout(() => {
                    setShowUpdateMessage(false);
                    fetchMaintenanceRequests(); 
                }, 2000); // Show message for 2 seconds
            } else {
                console.error('Update Failed Response:', response);
                setError('Failed to update maintenance request status.');
            }
        } catch (err) {
            console.error('Error updating maintenance request status:', err);
            setError('Failed to update maintenance request status.');
        }
    };
 
    if (loading) {
        return <div className="container mt-5">Loading maintenance requests...</div>;
    }
 
    if (error) {
        return <div className="container mt-5 alert alert-danger">{error}</div>;
    }
 
    return (
        <div className="container mt-5">
            <Link to={`/owner/property/${propertyId}`} className="btn btn-outline-secondary mb-3">
                <FaArrowLeft className="me-2" /> Back to Property Details
            </Link>
            <h2>Maintenance Requests for Property ID: {propertyId}</h2>
            {showUpdateMessage && (
                <div className="alert alert-success alert-slide-up">
                    Maintenance request updated successfully!
                </div>
            )}
            {maintenanceRequests.length === 0 ? (
                <p>No maintenance requests found for this property.</p>
            ) : (
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Submitted At</th>
                            <th>type</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {maintenanceRequests.map(request => {
                            const requestData = updatedRequestData[request.requestID] || request;
                            return (
                            <tr key={request.requestID}>
                                <td>{request.requestID}</td>
                                <td>{request.createdAt ? format(parseISO(request.createdAt), 'yyyy-MM-dd HH:mm:ss') : 'N/A'}</td>
                                 <td>{request.category ? request.category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) : 'N/A'}</td>
                                <td>{request.issueDescription}</td>
                                <td>
                                    <select
                                        className="form-select form-select-sm"
                                        value={requestData.status}
                                        onChange={(e) => handleStatusChange(request.requestID, e.target.value)}
                                    >
                                        <option value="REQUEST_SUBMITTED">Request Submitted</option>
                                        <option value="REQUEST_RECEIVED">Request Received</option>
                                        <option value="ASSIGNED_TO_SERVICE_PROVIDER">Assigned to Service Provider</option>
                                        <option value="REQUEST_CLOSED">Request Closed</option>
                                    </select>
                                </td>
                                <td>
                                    <button
                                        className="btn btn-sm btn-primary"
                                        onClick={() => handleUpdateRequest(request.requestID)}
                                    >
                                        Update
                                    </button>
                                </td>
                            </tr>
                        )})}
                    </tbody>
                </table>
            )}
            <Link to="/owner-dashboard" className="btn btn-primary mt-3">
                <FaHome className="me-2" /> Back to Dashboard
            </Link>
        </div>
    );
};
 
export default OwnerMaintenancePage;
 