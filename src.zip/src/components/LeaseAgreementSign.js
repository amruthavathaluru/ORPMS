// src/components/LeaseAgreementSign.js
import React from 'react';

const LeaseAgreementSign = ({ agreed, onAgreementChange, onInitiatePayment, paymentError, paymentInitiating }) => {
    return (
        <div style={styles.agreementSection}>
            <label style={styles.agreementLabel}>
                <input
                    type="checkbox"
                    checked={agreed}
                    onChange={onAgreementChange}
                    style={styles.agreementCheckbox}
                />
                I have read and agree to all the terms and conditions of this lease agreement.
            </label>
            {paymentError && <p style={styles.error}>{paymentError}</p>}
            <button
                style={styles.paymentButton}
                onClick={onInitiatePayment}
                disabled={paymentInitiating || !agreed}
            >
                {paymentInitiating ? 'Initiating Payment...' : 'Proceed to Payment'}
            </button>
        </div>
    );
};

const styles = {
    agreementSection: {
        marginTop: '20px',
        padding: '15px',
        border: '1px solid #eee',
        borderRadius: '3px',
        backgroundColor: '#f9f9f9',
    },
    agreementLabel: {
        display: 'block',
        marginBottom: '10px',
    },
    agreementCheckbox: {
        marginRight: '8px',
    },
    paymentButton: {
        backgroundColor: '#007bff',
        color: 'white',
        padding: '10px 15px',
        border: 'none',
        borderRadius: '3px',
        cursor: 'pointer',
        fontSize: '1em',
        marginTop: '10px',
    },
    error: {
        color: 'red',
        marginTop: '10px',
        fontSize: '0.9em',
    },
};

export default LeaseAgreementSign;