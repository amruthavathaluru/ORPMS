// AvailabilityAnalytics.js
import React, { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AuthContext } from '../context/AuthContext';
import axios from 'axios';
import { motion, AnimatePresence } from 'framer-motion';
import { FaHome, FaListAlt } from 'react-icons/fa';
import '../css/AvailabilityAnalytics.css';
import TenantLeaseDetails from './TenantLeaseList'; 

const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.7, ease: 'easeOut' } },
};

const headerVariants = {
    hidden: { opacity: 0, y: -15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.2, ease: 'easeOut' } },
};

const propertyCardVariants = {
    initial: { opacity: 0, y: 5 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.3, ease: 'easeInOut' } },
    hover: { scale: 1.02, boxShadow: '0 6px 12px rgba(0, 0, 0, 0.1)' },
};

const AvailabilityAnalytics = () => {
    const { token, userId } = useContext(AuthContext);
    const [properties, setProperties] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [selectedLease, setSelectedLease] = useState(null);
    const [showLeaseModal, setShowLeaseModal] = useState(false);

    useEffect(() => {
        const fetchOwnerProperties = async () => {
            setLoading(true);
            setError('');

            if (!userId || !token) {
                console.error('Authentication failed: No owner ID or token found.');
                setError('Authentication failed.');
                setLoading(false);
                return;
            }

            try {
                const response = await axios.get(`http://localhost:8084/properties/owner/${userId}`, {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                });
                if (response.status >= 200 && response.status < 300 && response.data && response.data.data) {
                    setProperties(response.data.data);
                } else {
                    console.error('Failed to fetch properties:', response);
                    setError('Failed to fetch properties.');
                }
            } catch (err) {
                console.error('Error fetching properties:', err);
                setError(`Error fetching properties: ${err.message}`);
            } finally {
                setLoading(false);
            }
        };

        fetchOwnerProperties();
    }, [token, userId]);

    const fetchLeaseDetails = async (propertyId) => {
        if (!token || !propertyId) {
            console.error('Token or Property ID missing for fetching lease details.');
            setError('Could not fetch lease details.');
            return;
        }

        setLoading(true);
        setError('');

        try {
            const response = await axios.get(
                `http://localhost:8069/lease/property/${propertyId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                    },
                }
            );

            if (response.status >= 200 && response.status < 300 && response.data && response.data.data) {
                setSelectedLease(response.data.data); 
                setShowLeaseModal(true);
            } else if (response.status === 404) {
                setError('No lease agreement found for this property.');
            } else {
                setError(`Failed to fetch lease details: Status ${response.status}`);
            }
        } catch (error) {
            console.error('Error fetching lease details:', error);
            setError(`Error fetching lease details: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    const handleViewLease = (propertyId) => {
        fetchLeaseDetails(propertyId);
    };

    const closeLeaseModal = () => {
        setShowLeaseModal(false);
        setSelectedLease(null);
        setError(''); // Clear any previous errors
        setLoading(false); // Ensure loading is off
    };

    if (loading) {
        return (
            <div className="container mt-5 d-flex justify-content-center align-items-center">
                <div className="spinner-border text-info" role="status" style={{ width: '3rem', height: '3rem', borderWidth: '0.3em' }}>
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="container mt-5">
                <div className="alert alert-danger shadow-sm rounded">{error}</div>
            </div>
        );
    }

    return (
        <motion.div
            className="container py-5 beautiful-analytics-container"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
        >
            <motion.div
                className="d-flex justify-content-between align-items-center mb-4"
                variants={headerVariants}
            >
                <h1 className="beautiful-analytics-title"><FaListAlt className="me-2" /> Property Listings</h1>
                <Link to="/owner-dashboard" className="btn btn-outline-primary rounded-pill btn-lg beautiful-dashboard-link">
                    <FaHome className="me-1" /> Dashboard
                </Link>
            </motion.div>

            <div className="mt-5">
                <h3 className="beautiful-listings-title mb-4"><FaListAlt className="me-2" /> Current Property Listings</h3>
                <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 beautiful-property-grid">
                    <AnimatePresence>
                        {properties.map(property => (
                            <motion.div
                                key={property.propertyID}
                                className="col"
                                variants={propertyCardVariants}
                                initial="initial"
                                animate="animate"
                                whileHover="hover"
                            >
                                <div className="card beautiful-property-card">
                                    <div className="card-body p-3 text-center">
                                        <div className="beautiful-property-icon-wrapper">
                                            <FaHome className="beautiful-property-icon" />
                                        </div>
                                        <h6 className="beautiful-property-name mb-2">{property.propertyName}</h6>
                                        <p className="beautiful-property-address mb-2">{property.address}</p>
                                        <div className="beautiful-status-badge-wrapper">
                                            <span
                                                className={`beautiful-status-badge ${property.availabilityStatus.toLowerCase()}`}
                                            >
                                                {property.availabilityStatus}
                                            </span>
                                        </div>
                                        <Link
                                            to={`/owner/property/${property.propertyID}`}
                                            className="btn beautiful-view-button mt-3"
                                        >
                                            View Details
                                        </Link>
                                        {property.availabilityStatus.toLowerCase() === 'rented' && (
                                            <button
                                                className="btn beautiful-view-button mt-2"
                                                onClick={() => handleViewLease(property.propertyID)} // Pass propertyID directly
                                            >
                                                View Lease
                                            </button>
                                        )}
                                        
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                    {properties.length === 0 && !loading && !error && (
                        <div className="col-12">
                            <div className="alert beautiful-no-properties">No properties listed yet.</div>
                        </div>
                    )}
                </div>
            </div>

            {showLeaseModal && selectedLease && (
                <TenantLeaseDetails lease={selectedLease} onClose={closeLeaseModal} />
            )}
        </motion.div>
    );
};

export default AvailabilityAnalytics;