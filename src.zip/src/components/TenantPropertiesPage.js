// TenantPropertiesPage.js
import React, { useState, useEffect, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../css/PropertyListingPage.css';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import TenantLeaseDetails from './TenantLeaseList';


const TenantPropertiesPage = () => {
  
  const [properties, setProperties] = useState([]);

  
  const [leaseDetails, setLeaseDetails] = useState([]);

  
  const [loading, setLoading] = useState(true);

  
  const [error, setError] = useState(null);

  
  const { userId, token } = useContext(AuthContext);

 
  const [popupMessage, setPopupMessage] = useState(null);

 
  const [showPopup, setShowPopup] = useState(false);

  
  const navigate = useNavigate();

  
  const [showLeaseDetailsModal, setShowLeaseDetailsModal] = useState(false);

  
  const [selectedLeaseForModal, setSelectedLeaseForModal] = useState(null);

  
  const fetchTenantProperties = async () => {
    try {
      const response = await axios.get(`http://localhost:8084/properties/tenant/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.status >= 200 && response.status < 300 && response.data && response.data.data) {
        setProperties(response.data.data);
      } else {
        setError(`Failed to fetch properties: Status ${response.status}`);
      }
    } catch (err) {
      setError(`Error fetching properties: ${err.message}`);
    }
  };

  
  const fetchTenantLease = async () => {
    try {
      const response = await axios.get(`http://localhost:8069/lease/tenant/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.status >= 200 && response.status < 300 && response.data && response.data.data) {
        setLeaseDetails(response.data.data);
      } else {
        console.warn(`Failed to fetch lease details: Status ${response.status}`);
        setLeaseDetails([]);
      }
    } catch (err) {
      console.error('Error fetching lease details:', err.message);
      setLeaseDetails([]);
    }
  };

  
  useEffect(() => {
    setLoading(true);
    setError(null);
    Promise.all([fetchTenantProperties(), fetchTenantLease()])
      .finally(() => setLoading(false));
  }, [userId, token]);

  
  const closePopup = () => {
    setShowPopup(false);
    setPopupMessage(null);
  };

  
  const handleRenewLease = (leaseId) => {
    navigate(`/tenant/lease/renew/${leaseId}`);
  };

  
  const handleDeleteLease = (leaseId) => {
    // Implement delete logic here
  };

  
  const fetchPropertyName = async (propertyId) => {
    try {
      const response = await axios.get(`http://localhost:8084/properties/${propertyId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.status >= 200 && response.status < 300 && response.data && response.data.data) {
        return response.data.data.propertyName;
      } else {
        console.warn(`Failed to fetch property name for ID ${propertyId}: Status ${response.status}`);
        return null;
      }
    } catch (err) {
      console.error(`Error fetching property name for ID ${propertyId}:`, err.message);
      return null;
    }
  };

  
  const handleViewLease = async (lease) => {
    const propertyName = await fetchPropertyName(lease.propertyID);
    setSelectedLeaseForModal({ ...lease, propertyName });
    setShowLeaseDetailsModal(true);
  };

  
  const closeLeaseDetailsModal = () => {
    setShowLeaseDetailsModal(false);
    setSelectedLeaseForModal(null);
  };

  
  const isRenewalAvailable = (endDate) => {
    if (!endDate) return false;
    const endDateObj = new Date(endDate);
    const now = new Date();
    const oneMonthFromNow = new Date(now.setMonth(now.getMonth() + 1));
    return endDateObj <= oneMonthFromNow;
  };

  
  const handleMaintenanceRequest = (propertyId) => {
    navigate(`/tenant/maintenance/request/${propertyId}`);
  };

  const logoImageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1XTI8gu469dLlP3P-h8yFNdqjQ8ymadjMDQ&s';

  if (loading) {
    return (
      <div className="property-listings-page tenant-properties-page">
        <nav className="navigation-bar">
          <ul>
            <li>
              <Link to="/tenant/home" className="navbar-logo">
                <img src={logoImageUrl} alt="Logo" style={{ height: '30px', width: 'auto', verticalAlign: 'middle' }} />
              </Link>
            </li>
            <li><Link to="/tenant/home">Home</Link></li>
            <li><Link to="/tenant/rentals">Rentals</Link></li>
            <li><Link to="/tenant/interests">Interests</Link></li>
            <li><Link to="/tenant/maintenance">Maintenance Requests</Link></li>
            <li><Link to="/tenant/notifications">Notifications</Link></li>
            <li><Link to="/tenant/profile">Profile</Link></li>
          </ul>
        </nav>
        <h2>Loading Your Properties and Lease Details...</h2>
      </div>
    );
  }

  if (error) {
    return (
      <div className="property-listings-page tenant-properties-page">
        <nav className="navigation-bar">
          <ul>
            <li>
              <Link to="/tenant/home" className="navbar-logo">
                <img src={logoImageUrl} alt="Logo" style={{ height: '30px', width: 'auto', verticalAlign: 'middle' }} />
              </Link>
            </li>
            <li><Link to="/tenant/home">Home</Link></li>
            <li><Link to="/tenant/rentals">Rentals</Link></li>
            <li><Link to="/tenant/interests">Interests</Link></li>
            <li><Link to="/tenant/maintenance">Maintenance Requests</Link></li>
            <li><Link to="/tenant/notifications">Notifications</Link></li>
            <li><Link to="/tenant/profile">Profile</Link></li>
          </ul>
        </nav>
        <h2>Error: {error}</h2>
      </div>
    );
  }

  return (
    <div className="property-listings-page tenant-properties-page">
      <nav className="navigation-bar">
        <ul>
          <li>
            <Link to="/tenant/home" className="navbar-logo">
              <img
                src={logoImageUrl}
                alt="Logo"
                style={{ height: '30px', width: 'auto', verticalAlign: 'middle' }}
              />
            </Link>
          </li>
          <li><Link to="/tenant/home">Home</Link></li>
          <li><Link to="/tenant/rentals">Rentals</Link></li>
          <li><Link to="/tenant/interests">Interests</Link></li>
          <li><Link to="/tenant/maintenance">Maintenance Requests</Link></li>
          <li><Link to="/tenant/notifications">Notifications</Link></li>
          <li><Link to="/tenant/profile">Profile</Link></li>
        </ul>
      </nav>
      <h2>Your Properties and Lease Details</h2>
      <div className="property-list">
        {properties.map(property => {
          const leaseForProperty = leaseDetails ? leaseDetails.find(lease => lease.propertyID === property.propertyID) : null;
          return (
            <div key={property.propertyID} className="property-card">
              <h3>{property.propertyName}</h3>
              <p>Address: {property.address}</p>
              <p>Type: {property.type}</p>
              <p>Rental Terms: {property.rentalTerms}</p>
              {leaseForProperty && (
                <>
                  <p>Rent: ₹ {leaseForProperty.propertyPrice}</p>
                  <div className="lease-details">
                    <h4>Lease Details</h4>
                    <p>Lease ID: {leaseForProperty.leaseID}</p>
                    <p>Start Date: {new Date(leaseForProperty.startDate).toLocaleDateString()}</p>
                    <p>End Date: {new Date(leaseForProperty.endDate).toLocaleDateString()}</p>
                    <p>Lease Status: {leaseForProperty.leaseStatus}</p>
                  </div>
                  <div className="card-actions">
                    <button
                      className="view-lease-button"
                      onClick={() => handleViewLease(leaseForProperty)}
                    >
                      View Lease
                    </button>
                    {leaseForProperty.leaseStatus === 'agreement_accepted' && (
                      <button
                        className="maintenance-request-button"
                        onClick={() => handleMaintenanceRequest(property.propertyID)}
                      >
                        Maintenance Request
                      </button>
                    )}
                    {isRenewalAvailable(leaseForProperty.endDate) && (
                      <>
                        <button className="renew-lease-button" onClick={() => handleRenewLease(leaseForProperty.leaseID)}>
                          Renew Lease
                        </button>
                        <button className="delete-lease-button" onClick={() => handleDeleteLease(leaseForProperty.leaseID)}>
                          Delete Lease
                        </button>
                      </>
                    )}
                  </div>
                </>
              )}
              {!leaseForProperty && <p>No active lease details found for this property.</p>}
            </div>
          );
        })}
        {properties.length === 0 && !loading && <p>You currently have no properties listed.</p>}
      </div>
      {showLeaseDetailsModal && selectedLeaseForModal && (
        <TenantLeaseDetails lease={selectedLeaseForModal} onClose={closeLeaseDetailsModal} />
      )}
      {showPopup && popupMessage && (
        <div className="modal">
          <div className="modal-content">
            <p>{popupMessage}</p>
            <button className="close-button" onClick={closePopup}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TenantPropertiesPage;