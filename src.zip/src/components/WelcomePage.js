import React from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/WelcomePage.css'; // Import the CSS file for custom styles

//functional component for welcome page
const WelcomePage = () => {
  
  // background image
  const backgroundImageURL = 'https://images4.alphacoders.com/212/212776.jpg';
  
  //jsx starts
  return (
    <div
      className="welcome-container"
      // inline styling to set background image
      style={{ backgroundImage: `url(${backgroundImageURL})` }}
    >
        {/* to increase readability */}
      <div className="welcome-overlay">
        
        <div className="welcome-content">
          
          <h1 className="welcome-title">Welcome to Rently</h1>

          <p className="welcome-subtitle">Your hassle-free rental property management platform.</p>

          <div className="welcome-buttons">

            {/* routes to login page*/}
            <Link to="/login" className="btn btn-primary btn-lg welcome-button">
              Login
            </Link>
            {/* routes to registration page*/}

            <Link to="/register" className="btn btn-primary btn-lg welcome-button">
              Sign Up
            </Link>
            
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomePage;