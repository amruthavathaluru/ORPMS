// src/components/TenantProfile.js
import React, { useState, useEffect, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../css/TenantProfilePage.css';
import axios from 'axios';
import { AuthContext } from '../../src/context/AuthContext';
import { jwtDecode } from 'jwt-decode';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

const logoImageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1XTI8gu469dLlP3P-h8yFNdqjQ8ymadjMDQ&s';
const BASE_URL_TENANT = 'http://localhost:8083';

const TenantProfilePage = () => {
    const { token, userId, logout } = useContext(AuthContext);
    const [tenantData, setTenantData] = useState(null);
    const [userEmail, setUserEmail] = useState('');
    const [isEditing, setIsEditing] = useState(false);
    const [updateProfileSuccess, setUpdateProfileSuccess] = useState(null);
    const [updateProfileError, setUpdateProfileError] = useState(null);
    const [showUpdateProfilePopup, setShowUpdateProfilePopup] = useState(false); // New state for the pop-up
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
    const navigate = useNavigate();

    // Validation schema using yup
    const validationSchema = yup.object().shape({
        name: yup.string().required('Name is required').matches(/^[a-zA-Z\s]+$/, 'Name must contain only letters and spaces'),
        contactNo: yup.string().matches(/^[1-9][0-9]{9}$/, 'Enter a valid 10-digit contact number').required('Contact number is required'),
        gender: yup.string().required('Gender is required'),
    });

    // Integrate with react-hook-form
    const {
        register,
        handleSubmit,
        setValue,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(validationSchema),
        defaultValues: {
            name: '',
            contactNo: '',
            gender: '',
        },
    });

    useEffect(() => {
        const fetchTenantProfile = async () => {
            setLoading(true);
            setError(null);
            try {
                const response = await axios.get(`${BASE_URL_TENANT}/tenant/profile/${userId}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setTenantData(response.data.data);
                setValue('name', response.data.data.name || '');
                setValue('gender', response.data.data.gender || '');
                setValue('contactNo', response.data.data.contactNo || '');
                setLoading(false);

                if (token) {
                    try {
                        const decodedToken = jwtDecode(token);
                        setUserEmail(decodedToken.email || decodedToken.sub || 'N/A');
                    } catch (decodeError) {
                        console.error('Error decoding token:', decodeError);
                        setUserEmail('N/A (Error decoding token)');
                    }
                } else {
                    setUserEmail('N/A (No token)');
                }

            } catch (error) {
                console.error('Error fetching tenant profile:', error);
                setError('Failed to load profile information.');
                setLoading(false);
            }
        };

        if (token && userId) {
            fetchTenantProfile();
        } else {
            setError('Authentication token or User ID not found.');
            setLoading(false);
        }
    }, [token, userId, setValue]);

    const handleEditProfile = () => {
        setIsEditing(true);
        setUpdateProfileSuccess(null);
        setUpdateProfileError(null);
    };

    const handleCancelEdit = () => {
        setIsEditing(false);
        setValue('name', tenantData?.name || '');
        setValue('gender', tenantData?.gender || '');
        setValue('contactNo', tenantData?.contactNo || '');
        setUpdateProfileSuccess(null);
        setUpdateProfileError(null);
    };

    const onSubmit = async (formData) => {
        setUpdateProfileSuccess(null);
        setUpdateProfileError(null);
        try {
            const response = await axios.put(
                `${BASE_URL_TENANT}/tenant/update/${userId}`,
                {
                    name: formData.name,
                    contactNo: formData.contactNo,
                    gender: formData.gender,
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );
            setTenantData(response.data.data);
            setShowUpdateProfilePopup(true);
            setIsEditing(false);
            setTimeout(() => setShowUpdateProfilePopup(false), 3000);
        } catch (error) {
            console.error('Error updating profile:', error);
            setUpdateProfileError('Failed to update profile.');
        }
    };

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    if (loading) {
        return <div className="tenant-profile-page"><h2>Loading Profile...</h2></div>;
    }

    if (error) {
        return <div className="tenant-profile-page"><h2>Error: {error}</h2></div>;
    }

    if (!tenantData) {
        return <div className="tenant-profile-page"><h2>No profile data found.</h2></div>;
    }

    return (
        <div className="tenant-profile-page">
            <nav className="navigation-bar">
                <ul>
                    <li>
                        <Link to="/" className="navbar-logo">
                            <img src={logoImageUrl} alt="Logo" />
                        </Link>
                    </li>
                    <li><Link to="/tenant/home">Home</Link></li>
                    <li><Link to="/tenant/rentals">Rentals</Link></li>
                    <li><Link to="/tenant/interests">Interests</Link></li>
                    <li><Link to="/tenant/maintenance">Maintenance Requests</Link></li>
                    <li><Link to="/tenant/notifications">Notifications</Link></li>
                    <li><Link to="/tenant/profile">Profile</Link></li>
                </ul>
            </nav>

            <div className="profile-container">
                <div className="profile-header">
                    <h2>My Profile</h2>
                    <button onClick={handleLogout} className="logout-button">Logout</button>
                </div>
                <div className="profile-card">
                    {updateProfileSuccess && <p className="success-message">{updateProfileSuccess}</p>}
                    {updateProfileError && <p className="error-message">{updateProfileError}</p>}

                    {!isEditing ? (
                        <>
                            <p><strong>Name:</strong> {tenantData.name}</p>
                            <p><strong>Gender:</strong> {tenantData.gender || 'N/A'}</p>
                            <p><strong>Contact No:</strong> {tenantData.contactNo || 'N/A'}</p>
                            <p><strong>Email:</strong> {userEmail}</p>
                            <div className="profile-actions">
                                <button onClick={handleEditProfile}>Edit Profile</button>
                            </div>
                        </>
                    ) : (
                        <form onSubmit={handleSubmit(onSubmit)} className="profile-edit-form">
                            <div className="form-group">
                                <label htmlFor="name">Name:</label>
                                <input
                                    type="text"
                                    id="name"
                                    {...register('name')}
                                    className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                                />
                                {errors.name && <div className="invalid-feedback">{errors.name.message}</div>}
                            </div>
                            <div className="form-group">
                                <label htmlFor="gender">Gender:</label>
                                <select
                                    id="gender"
                                    {...register('gender')}
                                    className={`form-control ${errors.gender ? 'is-invalid' : ''}`}
                                >
                                    <option value="">Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                                {errors.gender && <div className="invalid-feedback">{errors.gender.message}</div>}
                            </div>
                            <div className="form-group">
                                <label htmlFor="contactNo">Contact No:</label>
                                <input
                                    type="text"
                                    id="contactNo"
                                    {...register('contactNo')}
                                    className={`form-control ${errors.contactNo ? 'is-invalid' : ''}`}
                                />
                                {errors.contactNo && <div className="invalid-feedback">{errors.contactNo.message}</div>}
                            </div>
                            <div className="form-group">
                                <label htmlFor="email">Email:</label>
                                <input
                                    type="email"
                                    id="email"
                                    value={userEmail}
                                    className="form-control"
                                    readOnly
                                    disabled
                                />
                                <small>Email cannot be updated.</small>
                            </div>
                            <div className="profile-actions">
                                <button type="submit">Save Changes</button>
                                <button type="button" onClick={handleCancelEdit}>Cancel</button>
                            </div>
                        </form>
                    )}
                </div>

                {showUpdateProfilePopup && (
                    <div className="success-popup">
                        <p>Profile updated successfully!</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default TenantProfilePage;