import React, { useState, useEffect, useContext, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import backgroundImage from '../assets/dashboard-bg.jpg'; // Professional background
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { FaBell, FaPlusSquare, FaListAlt, FaChartLine, FaUserCircle, FaSignOutAlt, FaHome, FaFolderOpen, FaEye, FaExclamationTriangle } from 'react-icons/fa';

const dashboardStyle = {
    backgroundImage: `url(${backgroundImage})`,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    minHeight: '100vh',
    paddingTop: '80px',
    paddingBottom: '80px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
};

const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

const headerVariants = {
    hidden: { opacity: 0, y: -10 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, delay: 0.2, ease: "easeOut" } },
};

const cardVariants = {
    initial: { opacity: 0, y: 10 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
    hover: { scale: 1.02, boxShadow: "0 8px 15px rgba(0,0,0,0.1)" },
    tap: { scale: 0.98 },
};

const panelVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.4, ease: "easeInOut" } },
};

const buttonVariants = {
    hover: { scale: 1.05 },
    tap: { scale: 0.95 },
};

const listItemVariants = {
    initial: { opacity: 0, y: 5 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.3, ease: "easeOut" } },
};

function OwnerDashboard() {
    const { userId, token } = useContext(AuthContext);
    const [ownerDetails, setOwnerDetails] = useState({});
    const [properties, setProperties] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const [showPropertyList, setShowPropertyList] = useState(false);
    const ownerDetailsRef = useRef(null); // Create a ref for the owner details container

    useEffect(() => {
        if (!token) {
            navigate('/login', { replace: true });
        }
    }, [token, navigate]);

    useEffect(() => {
        const fetchOwnerDetails = async () => {
            setLoading(true);
            setError('');

            if (!userId || !token) {
                console.log('No token or owner ID found, redirecting to login.');
                setError('Authentication failed. Please log in again.');
                setLoading(false);
                navigate('/login');
                return;
            }

            try {
                const response = await axios.get(`http://localhost:8084/owners/${userId}`, {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                });

                console.log('Owner Details API Response:', response);
                if (response.status >= 200 && response.status < 300) {
                    console.log('Owner Details Response Data:', response.data.data);
                    setOwnerDetails(response.data.data);
                } else {
                    console.error('Failed to fetch owner details:', response);
                    setError(`Failed to fetch owner details: Status ${response.status}`);
                    // Consider more robust error handling or logout
                }
            } catch (err) {
                console.error('Error fetching owner details:', err);
                setError(`Failed to fetch owner details: ${err.message}`);
                // Consider more robust error handling or logout
            } finally {
                setLoading(false);
            }
        };

        const fetchOwnerProperties = async () => {
            if (!userId || !token) return;
            console.log("Fetching properties for owner ID:", userId); // ADD THIS LINE
            try {
                const response = await axios.get(`http://localhost:8084/properties/owner/${userId}`, {  //  <--- THIS LINE
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                });
                console.log('Owner Properties API Response:', response);
                if (response.status >= 200 && response.status < 300) {
                    setProperties(response.data.data);
                } else {
                    console.error('Failed to fetch owner properties:', response);
                    setError(`Failed to fetch owner properties: Status ${response.status}`);
                }
            } catch (err) {
                console.error('Error fetching owner properties:', err);
                setError(`Failed to fetch owner properties: ${err.message}`);
            }
        };

        fetchOwnerDetails();
        fetchOwnerProperties();
    }, [navigate, userId, token]);

    const togglePropertyList = () => {
        setShowPropertyList(!showPropertyList);
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        navigate('/login', { replace: true });
    };

    const navigateToAnalytics = () => {
        navigate('/owner/analytics'); // Programmatically navigate to the analytics page
    };

    const scrollToOwnerDetails = () => {
        ownerDetailsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    return (
        <motion.div className="container-fluid" style={dashboardStyle} initial="hidden" animate="visible" variants={containerVariants}>
            <div className="container" style={{ maxWidth: '1200px' }}>
                {/* Header */}
                <motion.div className="d-flex justify-content-between align-items-center mb-5" variants={headerVariants}>
                    <h1 className="fw-bold text-white display-5"><FaHome className="me-3" /> Owner Portal</h1>
                    <div>
                        <motion.button className="btn btn-outline-light rounded-pill px-4 py-2 me-3" onClick={scrollToOwnerDetails} style={{ fontSize: '1rem' }} variants={buttonVariants} whileHover="hover" whileTap="tap"><FaUserCircle className="me-2" /> Profile</motion.button>
                        <motion.button className="btn btn-danger rounded-pill px-4 py-2" onClick={handleLogout} style={{ fontSize: '1rem' }} variants={buttonVariants} whileHover="hover" whileTap="tap"><FaSignOutAlt className="me-2" /> Logout</motion.button>
                    </div>
                </motion.div>

                {/* Dashboard Cards */}
                <div className="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4 mb-5">
                    <div className="col">
                        <motion.div className="card h-100 shadow-lg border-0 rounded-3" variants={cardVariants} whileHover="hover" whileTap="tap">
                            <div className="card-body bg-primary text-white d-flex flex-column justify-content-center align-items-center p-4">
                                <FaBell className="fs-2 mb-3" />
                                <h5 className="card-title fw-semibold text-center mb-2" style={{ color:"white", fontSize: '1.2rem' }}>Notifications</h5>
                                <p className="card-text text-center small opacity-80">Stay updated on important alerts.</p>
                                <span className="badge bg-white text-primary rounded-pill mt-2">5 New</span>
                                <Link to="/owner/notifications" className="stretched-link"></Link>
                            </div>
                        </motion.div>
                    </div>
                    <div className="col">
                        <motion.div className="card h-100 shadow-lg border-0 rounded-3" variants={cardVariants} whileHover="hover" whileTap="tap">
                            <div className="card-body bg-success text-white d-flex flex-column justify-content-center align-items-center p-4">
                                <FaPlusSquare className="fs-2 mb-3" />
                                <h5 className="card-title fw-semibold text-center mb-2" style={{ color:"white", fontSize: '1.2rem' }}>List Property</h5>
                                <p className="card-text text-center small opacity-80">Add a new property to your listings.</p>
                                <Link to="/owner/register-property" className="btn btn-outline-light btn-sm rounded-pill mt-3" style={{ fontSize: '0.9rem' }}><FaPlusSquare className="me-1" /> Add Now</Link>
                            </div>
                        </motion.div>
                    </div>
                    <div className="col">
                        <motion.div className="card h-100 shadow-lg border-0 rounded-3" variants={cardVariants} whileHover="hover" whileTap="tap">
                            <div className="card-body bg-info text-white d-flex flex-column justify-content-center align-items-center p-4">
                                <FaListAlt className="fs-2 mb-3" />
                                <h5 className="card-title fw-semibold text-center mb-2" style={{ color:"white", fontSize: '1.2rem' }}>My Properties</h5>
                                <p className="card-text text-center small opacity-80">Manage and view your existing listings.</p>
                                <motion.button onClick={togglePropertyList} className="btn btn-outline-light btn-sm rounded-pill mt-3" style={{ fontSize: '0.9rem' }} variants={buttonVariants} whileHover="hover" whileTap="tap"><FaFolderOpen className="me-1" /> View All</motion.button>
                            </div>
                        </motion.div>
                    </div>
                    <div className="col">
                        <motion.div className="card h-100 shadow-lg border-0 rounded-3" variants={cardVariants} whileHover="hover" whileTap="tap">
                            <div className="card-body bg-warning text-dark d-flex flex-column justify-content-center align-items-center p-4">
                                <FaChartLine className="fs-2 mb-3" />
                                <h5 className="card-title fw-semibold text-center mb-2" style={{ color:"white", fontSize: '1.2rem' }}>Analytics</h5>
                                <p className="card-text text-center small opacity-80">Track the performance of your properties.</p>
                                <motion.button onClick={navigateToAnalytics} className="btn btn-outline-dark btn-sm rounded-pill mt-3" style={{ fontSize: '0.9rem' }} variants={buttonVariants} whileHover="hover" whileTap="tap"><FaChartLine className="me-1" /> View Insights</motion.button>
                            </div>
                        </motion.div>
                    </div>
                </div>

                {/* Owner Details Card */}
                <div ref={ownerDetailsRef}> {/* Attach the ref here */}
                    {loading ? (
                        <div className="alert alert-info shadow-sm rounded-3 p-3" role="alert">
                            <div className="d-flex align-items-center">
                                <div className="spinner-border spinner-border-sm me-2" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                                Loading your details...
                            </div>
                        </div>
                    ) : error ? (
                        <div className="alert alert-danger shadow-sm rounded-3 p-3" role="alert">
                            <FaExclamationTriangle className="me-2" /> {error}
                        </div>
                    ) : ownerDetails && Object.keys(ownerDetails).length > 0 ? (
                        <motion.div className="card bg-white shadow-lg rounded-3" variants={cardVariants}>
                            <div className="card-header bg-light py-3 rounded-top">
                                <h6 className="mb-0 fw-semibold"><FaUserCircle className="me-2" /> Account Information</h6>
                            </div>
                            <div className="card-body p-4">
                                <div className="row">
                                    <div className="col-md-6 mb-3">
                                        <p className="mb-1"><strong className="text-muted small">Name:</strong></p>
                                        <p className="mb-0 fw-medium">{ownerDetails?.name}</p>
                                    </div>
                                    <div className="col-md-6 mb-3">
                                        <p className="mb-1"><strong className="text-muted small">Contact:</strong></p>
                                        <p className="mb-0 fw-medium">{ownerDetails?.contactNo}</p>
                                    </div>
                                    <div className="col-md-6 mb-3">
                                        <p className="mb-1"><strong className="text-muted small">Gender:</strong></p>
                                        <p className="mb-0 fw-medium">{ownerDetails?.gender}</p>
                                    </div>
                                    {/* Add more details as needed */}
                                </div>
                                {/* <Link to="/owner/edit-profile" className="btn btn-outline-secondary btn-sm rounded-pill mt-3"><FaPencilAlt className="me-1" /> Edit Profile</Link> */}
                            </div>
                        </motion.div>
                    ) : (
                        <div className="alert alert-warning shadow-sm rounded-3 p-3" role="alert">
                            <FaExclamationTriangle className="me-2" /> No owner details found.
                        </div>
                    )}
                </div>

                {/* Property List Panel - REVISED */}
                {showPropertyList && (
                    <motion.div className="bg-white shadow-lg rounded-3 p-4 mt-4" style={{
                        position: 'fixed',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        zIndex: 1050,
                        width: '90%', // Adjust width
                        maxWidth: '600px', // Set a maximum width
                        maxHeight: '70vh', // Adjust maximum height
                        overflowY: 'auto',
                        boxSizing: 'border-box', // Important for padding and border to be inside width/height
                    }} variants={panelVariants}>
                        <div className="d-flex justify-content-between align-items-center mb-3">
                            <h5 className="fw-bold mb-0"><FaFolderOpen className="me-2" /> Your Properties</h5>
                            <button type="button" className="btn-close" onClick={togglePropertyList} aria-label="Close"></button>
                        </div>
                        <p className="text-muted small mb-3">Manage your current property listings:</p>
                        {properties.length > 0 ? (
                            <ul className="list-group">
                                {properties.map(property => (
                                    <motion.li key={property.propertyID} className="list-group-item d-flex justify-content-between align-items-center shadow-sm rounded-3 border-0 mb-2" variants={listItemVariants}>
                                        <div style={{ flexGrow: 1, overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                            <FaHome className="me-2 text-primary" /> <strong className="me-1">{property.propertyName}</strong> - {property.address}
                                        </div>
                                        <div style={{ flexShrink: 0 }}>
                                            <span className={`badge rounded-pill me-2 ${property.availabilityStatus === 'available' ? 'bg-success' : 'bg-info'}`}>{property.availabilityStatus}</span>
                                            <Link to={`/owner/property/${property.propertyID}`} className="btn btn-sm btn-outline-primary rounded-pill" style={{ fontSize: '0.8rem', marginRight: '5px' }}><FaEye className="me-1" /> View</Link>
                                            {/* Add Edit/Delete buttons here if needed */}
                                        </div>
                                    </motion.li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-muted small">No properties listed yet.</p>
                        )}
                        <div className="mt-3 d-flex justify-content-end">
                            <Link to="/owner/register-property" className="btn btn-primary btn-sm rounded-pill" style={{ fontSize: '0.9rem' }}><FaPlusSquare className="me-1" /> Add New</Link>
                        </div>
                    </motion.div>
                )}
            </div>
        </motion.div>
    );
}

export default OwnerDashboard;