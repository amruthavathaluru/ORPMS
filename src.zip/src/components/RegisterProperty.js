import React, { useState, useEffect, useContext, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FaHome, FaMapMarkerAlt, FaBuilding, FaRupeeSign, FaCalendarAlt, FaImage, FaCheckCircle, FaExclamationTriangle, FaPlus, FaTrash, FaArrowLeft } from 'react-icons/fa';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import '../css/RegisterProperty.css';
import backgroundImage from '../assets/register-bg.jpg'; // Adjust path if needed
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useForm } from 'react-hook-form';

const containerVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.6, ease: "easeInOut" } },
};

const inputVariants = {
    focus: { scale: 1.05, boxShadow: "0 0 8px rgba(0, 123, 255, 0.5)" },
};

const buttonVariants = {
    hover: { scale: 1.05, backgroundColor: "#0056b3", boxShadow: "0 2px 5px rgba(0, 0, 0, 0.3)" },
    tap: { scale: 0.95 },
};

const successMessageVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

const errorMessageVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

const propertyNameValidationSchema = yup.string()
    .required('Property Name is required')
    .matches(/^[a-zA-Z]+[a-zA-Z0-9\s]*$/, 'Property Name must start with a letter and can include letters, numbers, and spaces');

const addressValidationSchema = yup.string()
    .required('Address is required')
    .matches(/^(?=.*[a-zA-Z])[,.\'/#-\s0-9a-zA-Z]*$/, 'Address must contain at least one letter and can optionally include numbers, spaces, and symbols like ,.\'/#-');

const validationSchema = yup.object().shape({
    propertyName: propertyNameValidationSchema,
    address: addressValidationSchema,
    propertyType: yup.string().required('Property Type is required'),
    price: yup.number().required('Price is required').min(0, 'Price cannot be negative'),
    rentalTerms: yup.string(),
});

function RegisterProperty() {
    const { userId, token } = useContext(AuthContext);
    const [images, setImages] = useState([]);
    const [imageUrlsPreview, setImageUrlsPreview] = useState([]);
    const [registrationSuccess, setRegistrationSuccess] = useState(false);
    const [registrationError, setRegistrationError] = useState('');
    const navigate = useNavigate();
    const fileInputRef = useRef(null);
    const MAX_PREVIEW_SIZE = 80;
    const [isSubmitting, setIsSubmitting] = useState(false);

    const { register, handleSubmit, reset, formState: { errors } } = useForm({
        resolver: yupResolver(validationSchema),
        defaultValues: {
            propertyName: '',
            address: '',
            propertyType: '',
            price: '',
            rentalTerms: '',
        },
    });

    useEffect(() => {
        if (!userId) {
            setRegistrationError('User information not found. Please log in.');
            navigate('/login');
        }
    }, [userId, navigate]);

    const onSubmit = async (data) => {
        if (images.length === 0) {
            setRegistrationError('Please upload at least one property image.');
            return;
        }

        if (!userId) {
            setRegistrationError('User information is missing. Please ensure you are logged in.');
            return;
        }

        setIsSubmitting(true);
        setRegistrationError('');
        setRegistrationSuccess(false);

        const formData = new FormData();
        formData.append('propertyName', data.propertyName);
        formData.append('address', data.address);
        formData.append('type', data.propertyType);
        formData.append('price', parseFloat(data.price));
        formData.append('rentalTerms', data.rentalTerms);
        formData.append('availabilityStatus', 'available'); // Initial status
        images.forEach(image => formData.append('images', image));

        try {
            const response = await axios.post(
                `http://localhost:8084/properties/owner/${userId}`,
                formData,
                {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                        'Authorization': `Bearer ${token}`,
                    },
                }
            );
            setRegistrationSuccess(true);
            setRegistrationError('');
            reset();
            setImages([]);
            setImageUrlsPreview([]);
            setTimeout(() => {
                navigate('/owner-dashboard');
            }, 1500);

        } catch (error) {
            setRegistrationError(error.response?.data?.message || 'Something went wrong during registration.');
            setRegistrationSuccess(false);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleImageChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    let width = img.width;
                    let height = img.height;

                    if (width > MAX_PREVIEW_SIZE || height > MAX_PREVIEW_SIZE) {
                        if (width > height) {
                            height *= (MAX_PREVIEW_SIZE / width);
                            width = MAX_PREVIEW_SIZE;
                        } else {
                            width *= (MAX_PREVIEW_SIZE / height);
                            height = MAX_PREVIEW_SIZE;
                        }
                    }

                    const canvas = document.createElement('canvas');
                    canvas.width = width;
                    canvas.height = height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    const resizedDataURL = canvas.toDataURL(file.type);

                    setImages(prevImages => [...prevImages, file]);
                    setImageUrlsPreview(prevUrls => [...prevUrls, resizedDataURL]);
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
        event.target.value = null;
    };

    const handleAddImageClick = () => {
        fileInputRef.current.click();
    };

    const handleRemoveImage = (index) => {
        const newImages = [...images];
        newImages.splice(index, 1);
        setImages(newImages);

        const newPreviewUrls = [...imageUrlsPreview];
        newPreviewUrls.splice(index, 1);
        setImageUrlsPreview(newPreviewUrls);
    };

    return (
        <motion.div
            className="register-property-page"
            style={{
                backgroundImage: `url(${backgroundImage})`,
                backgroundSize: 'cover', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center'
            }}
            initial="hidden"
            animate="visible"
            variants={containerVariants}
        >
            <motion.div
                className="register-property-container"
                style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', padding: '40px', borderRadius: '15px', boxShadow: '0 8px 16px rgba(0, 0, 0, 0.2)', position: 'relative' }}
            >
                <Link to="/owner-dashboard" className="btn btn-outline-secondary rounded-pill mb-3" style={{ position: 'absolute', top: '1rem', left: '1rem', zIndex: 10 }}>
                    <FaArrowLeft className="me-2" /> Back
                </Link>
                <h2 className="fancy-heading" style={{ textAlign: 'center', color: '#2c3e50', marginBottom: '30px' }}>
                    <FaHome className="me-2" /> List Your Property!
                </h2>

                {registrationSuccess && (
                    <motion.div
                        className="alert alert-success d-flex align-items-center"
                        role="alert"
                        variants={successMessageVariants}
                        initial="hidden"
                        animate="visible"
                    >
                        <FaCheckCircle className="me-2" /> Property registered successfully! Redirecting...
                    </motion.div>
                )}

                {registrationError && (
                    <motion.div
                        className="alert alert-danger d-flex align-items-center"
                        role="alert"
                        variants={errorMessageVariants}
                        initial="hidden"
                        animate="visible"
                    >
                        <FaExclamationTriangle className="me-2" /> {registrationError}
                    </motion.div>
                )}

                {!registrationSuccess && (
                    <form onSubmit={handleSubmit(onSubmit)} className="interactive-form">
                        <div className="mb-3 animated-input">
                            <label htmlFor="propertyName" className="form-label fancy-label"><FaBuilding className="me-1" /> Property Name</label>
                            <motion.input
                                type="text"
                                className={`form-control fancy-input ${errors.propertyName ? 'is-invalid' : ''}`}
                                id="propertyName"
                                {...register('propertyName')}
                                required
                                whileFocus="focus"
                                variants={inputVariants}
                            />
                            {errors.propertyName && <div className="invalid-feedback">{errors.propertyName.message}</div>}
                        </div>

                        <div className="mb-3 animated-input">
                            <label htmlFor="address" className="form-label fancy-label"><FaMapMarkerAlt className="me-1" /> Address</label>
                            <motion.input
                                type="text"
                                className={`form-control fancy-input ${errors.address ? 'is-invalid' : ''}`}
                                id="address"
                                {...register('address')}
                                required
                                whileFocus="focus"
                                variants={inputVariants}
                            />
                            {errors.address && <div className="invalid-feedback">{errors.address.message}</div>}
                        </div>

                        <div className="mb-3 animated-input">
                            <label htmlFor="propertyType" className="form-label fancy-label"><FaBuilding className="me-1" /> Property Type</label>
                            <motion.select
                                className={`form-select fancy-input ${errors.propertyType ? 'is-invalid' : ''}`}
                                id="propertyType"
                                {...register('propertyType')}
                                required
                                whileFocus="focus"
                                variants={inputVariants}
                            >
                                <option value="">Select Type</option>
                                <option value="Residential">Residential</option>
                                <option value="Commercial">Commercial</option>
                                <option value="Industrial">Industrial </option>
                            </motion.select>
                            {errors.propertyType && <div className="invalid-feedback">{errors.propertyType.message}</div>}
                        </div>

                        <div className="mb-3 animated-input">
                            <label htmlFor="price" className="form-label fancy-label"><FaRupeeSign className="me-1" /> Price (RS)</label>
                            <div className="input-group">
                                <span className="input-group-text fancy-input-addon">RS</span>
                                <motion.input
                                    type="number"
                                    className={`form-control fancy-input ${errors.price ? 'is-invalid' : ''}`}
                                    id="price"
                                    {...register('price', { valueAsNumber: true })}
                                    min="0"
                                    required
                                    whileFocus="focus"
                                    variants={inputVariants}
                                />
                                {errors.price && <div className="invalid-feedback">{errors.price.message}</div>}
                            </div>
                        </div>

                        <div className="mb-3 animated-input">
                            <label htmlFor="rentalTerms" className="form-label fancy-label"><FaCalendarAlt className="me-1" /> Rental Terms</label>
                            <motion.input
                                type="text"
                                className="form-control fancy-input"
                                id="rentalTerms"
                                placeholder="e.g., no pets allowed"
                                {...register('rentalTerms')}
                                whileFocus="focus"
                                variants={inputVariants}
                            />
                            <small className="form-text fancy-text-muted">Specify rental terms if applicable.</small>
                        </div>

                        <div className="mb-3 animated-input">
                            <label htmlFor="imageUrls" className="form-label fancy-label"><FaImage className="me-1" /> Property Images</label>
                            <div className="image-upload-controls">
                                <input
                                    type="file"
                                    className="form-control fancy-input"
                                    id="imageUrls"
                                    onChange={handleImageChange}
                                    accept="image/*"
                                    style={{ display: 'none' }}
                                    ref={fileInputRef}
                                />
                                <motion.button
                                    type="button"
                                    className="btn btn-outline-primary fancy-button add-image-button"
                                    onClick={handleAddImageClick}
                                    whileHover="hover"
                                    whileTap="tap"
                                    variants={buttonVariants}
                                >
                                    <FaPlus className="me-1" /> Add Image
                                </motion.button>
                                <small className="form-text fancy-text-muted">Add property images one by one.</small>
                            </div>
                            {imageUrlsPreview.length > 0 && (
                                <div className="image-preview-area mt-2">
                                    <p className="fancy-label">Image Preview:</p>
                                    <div className="image-preview-grid">
                                        {imageUrlsPreview.map((url, index) => (
                                            <div key={index} className="image-preview-item">
                                                <img src={url} alt={`preview-${index}`} className="preview-image" />
                                                <button
                                                    type="button"
                                                    className="remove-image-button"
                                                    onClick={() => handleRemoveImage(index)}
                                                >
                                                    <FaTrash />
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                            {images.length === 0 && <div className="invalid-feedback d-block">Please upload at least one property image.</div>}
                        </div>

                        <div className="mb-3 animated-input">
                            <label htmlFor="availabilityStatus" className="form-label fancy-label"><FaCheckCircle className="me-1" /> Availability Status</label>
                            <motion.input
                                type="text"
                                className="form-control fancy-input"
                                id="availabilityStatus"
                                value="available"
                                readOnly
                                whileFocus="focus"
                                variants={inputVariants}
                            />
                            <small className="form-text fancy-text-muted">Initially set to 'available'.</small>
                        </div>

                        <motion.button
                            type="submit"
                            className="btn btn-primary fancy-button"
                            disabled={!userId || images.length === 0 || isSubmitting}
                            whileHover="hover"
                            whileTap="tap"
                            variants={buttonVariants}
                        >
                            {isSubmitting ? 'Registering...' : 'Register My Property!'}
                        </motion.button>
                        {!userId && (
                            <div className="mt-2 text-danger">
                                Please ensure you are logged in to register a property.
                            </div>
                        )}
                    </form>
                )}
            </motion.div>
        </motion.div>
    );
}

export default RegisterProperty;