// src/components/LeaseDetailsDisplay.js
import React from 'react';
 
const LeaseDetailsDisplay = ({ leaseDetails }) => {
    if (!leaseDetails) {
        return <p>No lease details available.</p>;
    }
 
    const formatDate = (dateString) => {
        try {
            return new Date(dateString).toLocaleDateString();
        } catch (error) {
            return '';
        }
    };
 
    return (
        <div style={{ fontFamily: 'sans-serif', lineHeight: '1.6' }}>
            <h3 style={{ backgroundColor: '#f0f0f0', padding: '10px', borderRadius: '5px', marginBottom: '15px' }}>
                Lease Agreement Summary
            </h3>
 
            <p>
                This lease agreement is made between <strong>Tenant:</strong> {leaseDetails.tenantName || 'N/A'} (Contact: {leaseDetails.tenantContactNo || 'N/A'})
                and <strong>Landlord:</strong> {leaseDetails.ownerName || 'N/A'} (Contact: {leaseDetails.ownerContactNo || 'N/A'})
                for the property located at <strong>Address:</strong> {leaseDetails.propertyAddress || 'N/A'}.
            </p>
 
            <p>
                The lease term commences on <strong>Start Date:</strong> {formatDate(leaseDetails.startDate) || 'N/A'}
                 and will end on <strong>End Date:</strong> {formatDate(leaseDetails.endDate) || 'N/A'}.
                The monthly <strong>Rent</strong> is ₹ {leaseDetails.propertyPrice || 'N/A'}.
                The current <strong>Lease Status</strong> is: {leaseDetails.leaseStatus || 'N/A'}.
            </p>
 
            {leaseDetails.securityDeposit && (
                <p>
                    A <strong>Security Deposit</strong> of ${leaseDetails.securityDeposit} is applicable as per this agreement.
                </p>
            )}
 
            {leaseDetails.paymentFrequency && (
                <p>
                    Rent is to be paid on a <strong>Payment Frequency</strong> of {leaseDetails.paymentFrequency}.
                </p>
            )}
 
            {leaseDetails.rentalTerms && (
                <div style={{ backgroundColor: '#e9ecef', padding: '10px', borderRadius: '5px', marginBottom: '15px' }}>
                    <p>
                        <strong>Rental Terms:</strong>
                    </p>
                    <p style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word', marginLeft: '10px' }}>
                        {leaseDetails.rentalTerms}
                    </p>
                </div>
            )}
 
            {leaseDetails.specialClauses && (
                <div style={{ backgroundColor: '#e9ecef', padding: '10px', borderRadius: '5px', marginBottom: '15px' }}>
                    <p>
                        <strong>Special Clauses:</strong>
                    </p>
                    <p style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word', marginLeft: '10px' }}>
                        {leaseDetails.specialClauses}
                    </p>
                </div>
            )}
 
            <h4 style={{ marginTop: '20px', marginBottom: '10px' }}>Standard Lease Rules:</h4>
            <ol style={{ marginLeft: '20px', marginBottom: '15px' }}>
                <li>Tenant agrees to pay the rent on time as specified.</li>
                <li>The property shall be used for residential purposes only.</li>
                <li>Tenant shall maintain the property in a clean and safe condition.</li>
                <li>No illegal activities are permitted on the property.</li>
                <li>Any alterations or modifications to the property require the landlord's written consent.</li>
                <li>Tenant shall notify the landlord of any necessary repairs or maintenance.</li>
                {leaseDetails.latePaymentPolicy && (
                    <li>
                        <strong>Late Payment Policy:</strong> {leaseDetails.latePaymentPolicy}
                    </li>
                )}
                {leaseDetails.petPolicy && (
                    <li>
                        <strong>Pet Policy:</strong> {leaseDetails.petPolicy}
                    </li>
                )}
                {leaseDetails.utilitiesIncluded && (
                    <li>
                        <strong>Utilities Included:</strong> {leaseDetails.utilitiesIncluded}
                    </li>
                )}
                {leaseDetails.tenantResponsibilities && (
                    <li>
                        <strong>Tenant Responsibilities:</strong> {leaseDetails.tenantResponsibilities}
                    </li>
                )}
                {leaseDetails.landlordResponsibilities && (
                    <li>
                        <strong>Landlord Responsibilities:</strong> {leaseDetails.landlordResponsibilities}
                    </li>
                )}
                {leaseDetails.termsAndConditions && (
                    <li>
                        <strong>Additional Terms:</strong> {leaseDetails.termsAndConditions}
                    </li>
                )}
                
            </ol>
 
            <p style={{ fontSize: '0.9em', color: '#555' }}>
                This is a summary of the lease agreement. Refer to the full document for complete terms and conditions.
            </p>
        </div>
    );
};
 
export default LeaseDetailsDisplay;