import React, { useState, useContext } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/Login.css'; // Import the CSS file

const validationSchema = yup.object().shape({
    email: yup.string().email('Enter a valid email').required('Email is required'),
    password: yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
    userType: yup.string().required('Role is required'),
});

function Login() {
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const { login } = useContext(AuthContext);
    const baseURL = 'http://localhost:8087/auth';

    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(validationSchema),
    });

    const onSubmit = async (data) => {
        setError('');

        try {
            const response = await axios.post(`${baseURL}/login`, data);
            const token = response.data.data.token;
            login(token);

            if (data.userType === 'TENANT') {
                navigate('/tenant/home'); // Redirect to the tenant landing page
            } else if (data.userType === 'OWNER') {
                navigate('/owner-dashboard'); // Redirect to the owner dashboard
            } else {
                navigate('/default-dashboard'); // Or handle other roles
            }
        } catch (err) {
            if (err.response && err.response.data && err.response.data.message) {
                setError(err.response.data.message);
            } else {
                setError('Login failed. Please check your credentials.');
            }
        }
    };

    return (
        <div className="login-container">
            <div className="login-card">
                <h2 className="login-title">Login</h2>
                {error && <div className="alert alert-danger">{error}</div>}
                <form onSubmit={handleSubmit(onSubmit)} className="login-form">
                    <div className="form-group">
                        <label htmlFor="email" className="form-label">Email</label>
                        <input
                            type="email"
                            {...register('email')}
                            className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                            id="email"
                        />
                        {errors.email && <div className="invalid-feedback">{errors.email.message}</div>}
                    </div>
                    <div className="form-group">
                        <label htmlFor="password" className="form-label">Password</label>
                        <input
                            type="password"
                            {...register('password')}
                            className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                            id="password"
                        />
                        {errors.password && <div className="invalid-feedback">{errors.password.message}</div>}
                    </div>
                    <div className="form-group">
                        <label className="form-label">Role</label>
                        <div>
                            <div className="form-check form-check-inline">
                                <input
                                    className={`form-check-input ${errors.userType ? 'is-invalid' : ''}`}
                                    type="radio"
                                    name="userType"
                                    id="tenant"
                                    value="TENANT"
                                    {...register('userType')}
                                />
                                <label className="form-check-label" htmlFor="tenant">Tenant</label>
                            </div>
                            <div className="form-check form-check-inline">
                                <input
                                    className={`form-check-input ${errors.userType ? 'is-invalid' : ''}`}
                                    type="radio"
                                    name="userType"
                                    id="owner"
                                    value="OWNER"
                                    {...register('userType')}
                                />
                                <label className="form-check-label" htmlFor="owner">Owner</label>
                            </div>
                            {errors.userType && <div className="invalid-feedback d-block">{errors.userType.message}</div>}
                        </div>
                    </div>
                    <button type="submit" className="btn btn-primary login-button">
                        Login
                    </button>
                </form>
                <p className="login-signup-text">
                    Don't have an account? <Link to="/register" className="login-signup-link">Register/Sign Up</Link>
                </p>
            </div>
        </div>
    );
}

export default Login;