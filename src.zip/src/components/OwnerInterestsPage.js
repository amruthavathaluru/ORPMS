import React, { useState, useEffect, useContext } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import '../css/PropertyListingPage.css';
import '../css/OwnerInterestsPage.css';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import LeaseCreation from '../components/LeaseCreation'; 

const OwnerInterestsPage = () => {
    const { propertyId } = useParams();
    const [propertyInterests, setPropertyInterests] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [propertyNameHeader, setPropertyNameHeader] = useState('');
    const { userId: ownerId } = useContext(AuthContext);
    const [showLeaseCreationModal, setShowLeaseCreationModal] = useState(false);
    const [selectedInterest, setSelectedInterest] = useState(null);
    const [leases, setLeases] = useState({}); 
    const navigate = useNavigate();

    useEffect(() => {
        const fetchInterestsWithDetails = async () => {
            setLoading(true);
            setError(null);
            try {
                const interestsResponse = await axios.get(`http://localhost:8083/interest/property/${propertyId}`);
                console.log('Interests Response:', interestsResponse);
                if (interestsResponse.data.success && interestsResponse.data.data) {
                    const interestsWithDetails = await Promise.all(
                        interestsResponse.data.data.map(async (interest) => {
                            try {
                                const tenantResponse = await axios.get(`http://localhost:8083/tenant/profile/${interest.tenantID}`);
                                console.log(`Tenant Response for ID ${interest.tenantID}:`, tenantResponse);
                                const propertyResponse = await axios.get(`http://localhost:8084/properties/${interest.propertyID}`);
                                console.log(`Property Response for ID ${interest.propertyID}:`, propertyResponse);
                                let leaseInfo = null;
                                try {
                                    const leaseResponse = await axios.get(`http://localhost:8069/lease/property/${interest.propertyID}`);
                                    console.log(`Initial Lease Response for Property ID ${interest.propertyID}:`, leaseResponse);
                                    if (leaseResponse.data.success && leaseResponse.data.data) { 
                                        leaseInfo = leaseResponse.data.data;
                                        console.log(`Initial Lease Info for Interest ID ${interest.interestID}:`, leaseInfo);
                                        if (leaseInfo && leaseInfo.tenantID === interest.tenantID) { // Ensure it's for the correct tenant
                                            setLeases(prev => ({ ...prev, [interest.interestID]: leaseInfo }));
                                            console.log('Leases State after initial fetch:', leases);
                                        }
                                    }
                                } catch (leaseError) {
                                    console.error('Error fetching initial lease data:', leaseError);
                                }

                                if (!propertyNameHeader && propertyResponse.data.success && propertyResponse.data.data.propertyName) {
                                    setPropertyNameHeader(propertyResponse.data.data.propertyName);
                                }

                                return {
                                    ...interest,
                                    tenantName: tenantResponse.data.success ? tenantResponse.data.data.name : 'N/A',
                                    tenantContact: tenantResponse.data.success ? tenantResponse.data.data.contactInfo : 'N/A',
                                    propertyName: propertyResponse.data.success ? propertyResponse.data.data.name : 'N/A',
                                    propertyAddress: propertyResponse.data.success ? propertyResponse.data.data.address : 'N/A',
                                };
                            } catch (detailError) {
                                console.error('Error fetching details:', detailError);
                                return { ...interest, tenantName: 'N/A', tenantContact: 'N/A', propertyName: 'N/A', propertyAddress: 'N/A' };
                            }
                        })
                    );
                    setPropertyInterests(interestsWithDetails);
                } else {
                    setError(interestsResponse.data.message || 'Failed to fetch interests.');
                }
            } catch (err) {
                setError(err.message || 'An unexpected error occurred.');
                console.error('Error fetching interests:', err);
            } finally {
                setLoading(false);
            }
        };

        fetchInterestsWithDetails();
    }, [propertyId]);

    const handleUpdateInterestStatus = async (interestID, status) => {
        try {
            const response = await axios.put(`http://localhost:8083/interest/update/${ownerId}`, {
                interestID: interestID,
                status: status,
            });
            console.log(`Update Interest Status Response for ID ${interestID} to ${status}:`, response);
            if (response.data.success) {
                setPropertyInterests(prevInterests =>
                    prevInterests.map(interest =>
                        interest.interestID === interestID ? { ...interest, status: status } : interest
                    )
                );
            } else {
                setError(response.data.message || `Failed to ${status.toLowerCase()} interest.`);
            }
        } catch (err) {
            setError(`Failed to ${status.toLowerCase()} interest. Please try again.`);
            console.error(`Error ${status.toLowerCase()} interest:`, err);
        }
    };

    const handleAcceptInterest = (interestID) => {
        handleUpdateInterestStatus(interestID, 'accepted');
    };

    const handleRejectInterest = (interestID) => {
        handleUpdateInterestStatus(interestID, 'rejected');
    };

    const openLeaseCreationModal = (interest) => {
        setSelectedInterest(interest);
        setShowLeaseCreationModal(true);
        console.log('Opening Lease Creation Modal for Interest:', interest);
    };

    const closeLeaseCreationModal = () => {
        setShowLeaseCreationModal(false);
        setSelectedInterest(null);
        console.log('Closing Lease Creation Modal');
        
    };

    const handleLeaseCreated = async (leaseDetails) => {
        console.log('Lease Created:', leaseDetails);
        setPropertyInterests(prevInterests =>
            prevInterests.map(interest =>
                interest.interestID === selectedInterest?.interestID
                    ? { ...interest, leaseID: leaseDetails.leaseID }
                    : interest
            )
        );
        // Fetch lease details by property ID after lease creation
        try {
            console.log('Fetching lease for property ID:', selectedInterest?.propertyID);
            const leaseResponse = await axios.get(`http://localhost:8069/lease/property/${selectedInterest?.propertyID}`);
            console.log('Lease API Response after creation:', leaseResponse);
            if (leaseResponse.data.success && leaseResponse.data.data) { 
                const specificLease = leaseResponse.data.data;
                console.log('Found Specific Lease after creation:', specificLease);
                if (specificLease && specificLease.tenantID === selectedInterest?.tenantID) { 
                    setLeases(prev => ({ ...prev, [selectedInterest?.interestID]: specificLease }));
                    console.log('Leases State after lease creation:', leases);
                }
            }
        } catch (error) {
            console.error('Error fetching lease details after creation:', error);
        }
        closeLeaseCreationModal();
    };

    const handleUpdatePayment = (leaseID) => {
        
        console.log('Navigating to update payment for Lease ID:', leaseID);
        
        window.location.href = `/owner/lease/${leaseID}/payment/update`;
    };

    const goBack = () => {
        navigate(-1); 
    };

    if (loading) {
        return <div>Loading interests...</div>;
    }

    if (error) {
        return <div>Error loading interests: {error}</div>;
    }

    return (
        <div className="owner-interests-page">
            <button onClick={goBack} className="back-button">Back</button>
            <h2>Interests for Property: {propertyNameHeader || propertyId}</h2>
            <div className="property-list">
                {propertyInterests.map(interest => (
                    <div key={interest.interestID} className="property-card">
                        <h3>{interest.propertyName}</h3>
                        <p>Address: {interest.propertyAddress}</p>
                        <p>Interest Date: {new Date(interest.interestDate).toLocaleDateString()}</p>
                        {leases[interest.interestID] ? (
                            <>
                                <p>Tenant: {leases[interest.interestID]?.tenantName} ({leases[interest.interestID]?.tenantContactNo})</p>
                                <div className="card-actions">
                                    <button
                                        className="update-payment-button action-button accepted"
                                        onClick={() => handleUpdatePayment(leases[interest.interestID]?.leaseID)}
                                    >
                                        Update Payment
                                    </button>
                                </div>
                            </>
                        ) : (
                            <>
                                <p>Tenant: {interest.tenantName} ({interest.tenantContact})</p>
                                <p>Status: {interest.status}</p>
                                <div className="card-actions">
                                    {interest.status === 'submitted' && (
                                        <>
                                            <button className="accept-button action-button" onClick={() => handleAcceptInterest(interest.interestID)}>Accept</button>
                                            <button className="reject-button action-button" onClick={() => handleRejectInterest(interest.interestID)}>Reject</button>
                                        </>
                                    )}
                                    {interest.status === 'accepted' && !leases[interest.interestID] && (
                                        <button className="create-lease-button action-button accepted" onClick={() => openLeaseCreationModal(interest)}>Create Lease</button>
                                    )}
                                    {interest.status === 'rejected' && (
                                        <button className="create-lease-button action-button rejected" disabled>Rejected</button>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                ))}
                {propertyInterests.length === 0 && !loading && <p>No interest requests for this property yet.</p>}
            </div>

            {showLeaseCreationModal && selectedInterest && (
                <LeaseCreation
                    interest={selectedInterest}
                    onClose={closeLeaseCreationModal}
                    onLeaseCreated={handleLeaseCreated}
                />
            )}
        </div>
    );
};

export default OwnerInterestsPage;