import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const RaiseMaintenanceRequestPage = () => {
    const { userId: tenantId, token } = useContext(AuthContext);
    const { propertyId } = useParams();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        propertyID: propertyId || '',
        category: '',
        issueDescription: '',
    });
    const [submissionStatus, setSubmissionStatus] = useState(null);
    const [errorMessage, setErrorMessage] = useState('');
    const [propertyName, setPropertyName] = useState('Loading...');

    useEffect(() => {
        const fetchPropertyName = async () => {
            if (propertyId) {
                try {
                    const response = await axios.get(`http://localhost:8084/properties/${propertyId}`);
                    if (response.status >= 200 && response.data?.data?.propertyName) {
                        setPropertyName(response.data.data.propertyName);
                    } else {
                        setPropertyName('Property Not Found');
                        console.error(`Failed to fetch property name for ID: ${propertyId}`);
                    }
                } catch (error) {
                    setPropertyName('Error Loading Property');
                    console.error('Error fetching property name:', error);
                }
            } else {
                setPropertyName('No Property Selected');
            }
        };

        fetchPropertyName();
    }, [propertyId]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmissionStatus('loading');
        setErrorMessage('');

        if (!tenantId) {
            setErrorMessage('Tenant ID not found. Please ensure you are logged in.');
            setSubmissionStatus('error');
            return;
        }

        if (!formData.propertyID) {
            setErrorMessage('Property ID is required.');
            setSubmissionStatus('error');
            return;
        }

        if (!formData.issueDescription) {
            setErrorMessage('Issue description is required.');
            setSubmissionStatus('error');
            return;
        }

        if (formData.issueDescription.length < 10 || formData.issueDescription.length > 200) {
            setErrorMessage('Issue description must be between 10 and 200 characters.');
            setSubmissionStatus('error');
            return;
        }

        if (!formData.category) {
            setErrorMessage('Category is required.');
            setSubmissionStatus('error');
            return;
        }

        try {
            const requestBody = {
                tenantID: tenantId,
                propertyID: formData.propertyID,
                issueDescription: formData.issueDescription,
                status: 'REQUEST_SUBMITTED', // Corrected status
                category: formData.category,
            };

            console.log('Request Payload:', requestBody);

            const response = await axios.post(
                'http://localhost:8081/api/maintenance-requests/create',
                requestBody,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            );

            console.log('Maintenance request submitted:', response.data);
            setSubmissionStatus('success');
            setFormData({ propertyID: '', category: '', issueDescription: '' });
        } catch (error) {
            console.error('Error submitting maintenance request:', error);
            setSubmissionStatus('error');
            // Check for response and data
            if (error.response && error.response.data) {
                setErrorMessage(error.response.data.message || 'Failed to submit request.');
                console.error("Server Response Data:", error.response.data);
            } else {
                setErrorMessage(error.message || 'Failed to submit request.');
            }
        }
    };

    const handleGoBack = () => {
        navigate(-1); // This navigates to the previous page in history
    };

    return (
        <div className="container mt-5">
            <button className="btn btn-secondary mb-3" onClick={handleGoBack}>
                Back
            </button>
            <h1>Raise a Maintenance Request</h1>
            {propertyName && <p>Property: {propertyName}</p>}
            {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}
            {submissionStatus === 'success' && <div className="alert alert-success">Request submitted successfully!</div>}
            <form onSubmit={handleSubmit}>
                {!propertyId && (
                    <div className="mb-3">
                        <label htmlFor="propertyID" className="form-label">Property ID:</label>
                        <input
                            type="text"
                            className="form-control"
                            id="propertyID"
                            name="propertyID"
                            value={formData.propertyID}
                            onChange={handleChange}
                            required
                        />
                        <div className="form-text">Enter the ID of the property.</div>
                    </div>
                )}
                <div className="mb-3">
                    <label htmlFor="category" className="form-label">Type of Service:</label>
                    <select
                        className="form-select"
                        id="category"
                        name="category"
                        value={formData.category}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select Type of Service</option>
                        <option value="plumbing">Plumbing</option>
                        <option value="electrical">Electrical</option>
                        <option value="appliance">Appliance Repair</option>
                        <option value="hvac">HVAC (Heating, Ventilation, Air Conditioning)</option>
                        <option value="pest_control">Pest Control</option>
                        <option value="cleaning">Cleaning</option>
                        <option value="painting">Painting</option>
                        <option value="landscaping">Landscaping</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div className="mb-3">
                    <label htmlFor="issueDescription" className="form-label">Description of Issue:</label>
                    <textarea
                        className="form-control"
                        id="issueDescription"
                        name="issueDescription"
                        rows="5"
                        value={formData.issueDescription}
                        onChange={handleChange}
                        required
                    ></textarea>
                </div>
                <button type="submit" className="btn btn-primary" disabled={submissionStatus === 'loading'}>
                    {submissionStatus === 'loading' ? 'Submitting...' : 'Submit Request'}
                </button>
                {submissionStatus === 'error' && <p className="mt-2 text-danger">{errorMessage}</p>}
            </form>
        </div>
    );
};

export default RaiseMaintenanceRequestPage;