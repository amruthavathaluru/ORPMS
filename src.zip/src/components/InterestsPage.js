import React, { useState, useEffect, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../css/PropertyListingPage.css'; // Assuming your CSS file path
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import LeaseAgreementSign from '../components/LeaseAgreementSign';
import LeaseDetailsDisplay from '../components/LeaseDisplay';


const InterestsPage = () => {
  
  const [interests, setInterests] = useState([]);

 
  const [loading, setLoading] = useState(true);

  
  const [error, setError] = useState(null);

 
  const { userId, token } = useContext(AuthContext);

 
  const [popupMessage, setPopupMessage] = useState(null);

 
  const [showPopup, setShowPopup] = useState(false);

  
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);

  
  const [interestToDelete, setInterestToDelete] = useState(null);

  
  const [propertyNameToDelete, setPropertyNameToDelete] = useState('');

  
  const [showLeaseSignModal, setShowLeaseSignModal] = useState(false);

  
  const [selectedInterestForLease, setSelectedInterestForLease] = useState(null);

  
  const [leaseDetailsForSign, setLeaseDetailsForSign] = useState(null);

  
  const [agreed, setAgreed] = useState(false);

  
  const [paymentInitiating, setPaymentInitiating] = useState(false);

  
  const [paymentError, setPaymentError] = useState(null);

 
  const navigate = useNavigate();

 
  const fetchInterests = async () => {
    setLoading(true);
    setError(null);
    try {
      if (!userId) {
        setError('User ID not found. Please log in again.');
        setLoading(false);
        return;
      }
      const response = await axios.get(`http://localhost:8083/interest/tenant/${userId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (response.status >= 200 && response.status < 300 && response.data && response.data.data) {
        const interestsWithDetails = await Promise.all(
          response.data.data.map(async (interest) => {
            let property = null;
            let leaseStatus = null;
            let leaseDetails = null;
            try {
              const propertyResponse = await axios.get(
                `http://localhost:8084/properties/${interest.propertyID}`
              );
              if (propertyResponse.status >= 200 && propertyResponse.status < 300 && propertyResponse.data && propertyResponse.data.data) {
                property = propertyResponse.data.data;
              }
            } catch (propertyError) {
              console.error('Error fetching property details:', propertyError);
            }

            try {
              // Fetch lease based on property ID
              const leaseResponse = await axios.get(
                `http://localhost:8069/lease/property/${interest.propertyID}`,
                {
                  headers: { Authorization: `Bearer ${token}` },
                }
              );
              if (leaseResponse.data && leaseResponse.data.data) {
                leaseStatus = leaseResponse.data.data.leaseStatus;
                leaseDetails = leaseResponse.data.data;
              }
            } catch (leaseError) {
              console.error('Error fetching lease details:', leaseError);
            }

            return { ...interest, property, leaseStatus, lease: leaseDetails };
          })
        );
        setInterests(interestsWithDetails);
        setLoading(false);
      } else {
        setError(`Failed to fetch interests: Status ${response.status}`);
        setLoading(false);
      }
    } catch (err) {
      setError(`Error fetching interests: ${err.message}`);
      setLoading(false);
    }
  };

 
  useEffect(() => {
    fetchInterests();
  }, [userId, token]);

  
  const handleDeleteClick = (interestID, propertyName) => {
    setInterestToDelete(interestID);
    setPropertyNameToDelete(propertyName);
    setShowDeleteConfirmation(true);
  };

  
  const confirmDeleteInterest = async () => {
    setShowDeleteConfirmation(false);
    setPopupMessage(null);
    setShowPopup(false);

    if (!interestToDelete) return;

    try {
      const response = await axios.delete(
        `http://localhost:8083/interest/<span class="math-inline">\{interestToDelete\}/tenant/</span>{userId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (response.status >= 200 && response.status < 300 && response.data && response.data.success) {
        setPopupMessage(`Successfully removed interest for "${propertyNameToDelete}".`);
        setShowPopup(true);
        fetchInterests();
      } else {
        setPopupMessage(`Failed to remove interest for "${propertyNameToDelete}": Status ${response.status}`);
        setShowPopup(true);
      }
    } catch (err) {
      console.error('Error deleting interest:', err);
      setPopupMessage(`Error removing interest for "${propertyNameToDelete}": ${err.message}`);
      setShowPopup(true);
    } finally {
      setInterestToDelete(null);
      setPropertyNameToDelete('');
    }
  };


  const cancelDeleteInterest = () => {
    setShowDeleteConfirmation(false);
    setInterestToDelete(null);
    setPropertyNameToDelete('');
  };

  
  const closePopup = () => {
    setShowPopup(false);
    setPopupMessage(null);
  };

  
  const handleSignLeaseClick = async (interest) => {
    setSelectedInterestForLease(interest);
    setLeaseDetailsForSign(interest.lease); // Use the lease data fetched earlier
    setShowLeaseSignModal(true);
  };

 
  const closeLeaseSignModal = () => {
    setShowLeaseSignModal(false);
    setSelectedInterestForLease(null);
    setLeaseDetailsForSign(null);
    setAgreed(false);
    setPaymentError(null);
    setPaymentInitiating(false);
  };

 
  const handleAgreementChange = (event) => {
    setAgreed(event.target.checked);
  };

  
  const handleInitiatePayment = () => {
    if (!agreed) {
      setPaymentError('Please agree to all the terms and conditions.');
      return;
    }

    if (!leaseDetailsForSign?.leaseID) {
      setPaymentError('Lease ID is missing, cannot proceed to payment.');
      return;
    }

    setPaymentInitiating(true);
    setPaymentError(null);

    const paymentUrl = `/tenant/payment/create/${leaseDetailsForSign.leaseID}`;
    navigate(paymentUrl);
  };

  const logoImageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1XTI8gu469dLlP3P-h8yFNdqjQ8ymadjMDQ&s'; // Replace with your logo URL

  return (
    <div className="property-listings-page interests-page">
      {/* Navigation bar */}
      <nav className="navigation-bar">
        <ul>
          <li>
            <Link to="/tenant/home" className="navbar-logo">
              <img src={logoImageUrl} alt="Logo" style={{ height: '30px', width: 'auto', verticalAlign: 'middle' }} />
            </Link>
          </li>
          <li><Link to="/tenant/home">Home</Link></li>
          <li><Link to="/tenant/rentals">Rentals</Link></li>
          <li><Link to="/tenant/interests" className="active-link">Interests</Link></li>
          <li><Link to="/tenant/maintenance">Maintenance Requests</Link></li>
          <li><Link to="/tenant/notifications">Notifications</Link></li>
          <li><Link to="/tenant/profile">Profile</Link></li>
        </ul>
      </nav>

      <h2>Your Expressed Interests</h2>
      <div className="property-list">
        {loading ? (
          <p>Loading Interests...</p>
        ) : error ? (
          <p>Error: {error}</p>
        ) : interests.map(interest => (
          <div key={interest.interestID} className="property-card">
            <h3>{interest.property ? interest.property.propertyName : 'Loading...'}</h3>
            <p>Address: {interest.property ? interest.property.address : 'Loading...'}</p>
            <p>Interest Date: {interest.interestDate ? new Date(interest.interestDate).toLocaleDateString() : 'Date Not Available'}</p>
            <p>Interest Status: {interest.status}</p>
            <div className="card-actions">
              {(interest.status === 'submitted' || interest.status === 'rejected') && (
                <button
                  className="delete-button"
                  onClick={() => handleDeleteClick(interest.interestID, interest.property ? interest.property.propertyName : 'this property')}
                >
                  Delete
                </button>
              )}
              {interest.status === 'accepted' && interest.leaseStatus === 'agreement_initiated' && (
                <button
                  className="sign-lease-button"
                  onClick={() => handleSignLeaseClick(interest)}
                >
                  Sign Lease
                </button>
              )}
              {interest.leaseStatus === 'agreement_accepted' && (
                <span className="rented-out-indicator">Rented Out</span>
              )}
            </div>
          </div>
        ))}
        {interests.length === 0 && !loading && <p>No interests expressed yet.</p>}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirmation && (
        <div className="modal">
          <div className="modal-content">
            <h3>Confirm Delete</h3>
            <p>Do you want to delete interest for "{propertyNameToDelete}"?</p>
            <div className="modal-actions">
              <button className="confirm-button" onClick={confirmDeleteInterest}>Yes</button>
              <button className="cancel-button" onClick={cancelDeleteInterest}>No</button>
            </div>
          </div>
        </div>
      )}

      {/* Popup Notification */}
      {showPopup && popupMessage && (
        <div className="modal">
          <div className="modal-content">
            <p>{popupMessage}</p>
            <button className="close-button" onClick={closePopup}>Close</button>
          </div>
        </div>
      )}

      {/* Lease Agreement Signing Modal */}
      {showLeaseSignModal && selectedInterestForLease && (
        <div style={styles.modal}>
          <div style={styles.modalContent}>
            <h3>Lease Agreement</h3>
            {loading ? (
              <p>Loading lease details...</p>
            ) : error ? (
              <p style={styles.error}>{error}</p>
            ) : leaseDetailsForSign ? (
              <>
                <LeaseDetailsDisplay leaseDetails={leaseDetailsForSign} />
                <LeaseAgreementSign
                  agreed={agreed}
                  onAgreementChange={handleAgreementChange}
                  onInitiatePayment={handleInitiatePayment}
                  paymentError={paymentError}
                  paymentInitiating={paymentInitiating}
                />
              </>
            ) : (
              <p>No lease agreement found.</p>
            )}
            <div style={styles.modalActions}>
              <button style={styles.closeButton} onClick={closeLeaseSignModal}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modalContent: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '5px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    maxWidth: '600px',
    width: '90%',
    overflowY: 'auto',
    maxHeight: '80vh',
  },
  modalActions: {
    display: 'flex',
    justifyContent: 'flex-end',
    marginTop: '15px',
  },
  closeButton: {
    backgroundColor: '#dc3545',
    color: 'white',
    padding: '8px 12px',
    border: 'none',
    borderRadius: '3px',
    cursor: 'pointer',
    fontSize: '0.9em',
  },
  error: {
    color: 'red',
    marginTop: '10px',
    fontSize: '0.9em',
  },
};

export default InterestsPage;