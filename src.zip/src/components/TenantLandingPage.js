import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../css/TenantLandingPage.css';


const TenantLandingPage = () => {
  
  const logoImageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1XTI8gu469dLlP3P-h8yFNdqjQ8ymadjMDQ&s';

  const [propertyNameSearch, setPropertyNameSearch] = useState('');

  
  const [locationFilter, setLocationFilter] = useState('');

  
  const [propertyTypeFilter, setPropertyTypeFilter] = useState('');

  
  const [minPriceFilter, setMinPriceFilter] = useState('');

  
  const [maxPriceFilter, setMaxPriceFilter] = useState('');

  const navigate = useNavigate();

  const handlePropertyNameSearchChange = (event) => {
    setPropertyNameSearch(event.target.value);
  };

  
  const handleFilterChange = (event) => {
    const { name, value } = event.target;
    switch (name) {
      case 'location':
        setLocationFilter(value);
        break;
      case 'propertyType':
        setPropertyTypeFilter(value);
        break;
      case 'minPrice':
        setMinPriceFilter(value);
        break;
      case 'maxPrice':
        setMaxPriceFilter(value);
        break;
      default:
        break;
    }
  };

  
  const handleSearchSubmit = (event) => {
    event.preventDefault();
    const searchParams = new URLSearchParams();
    // Append search parameters to the URL if they have a value
    if (propertyNameSearch) searchParams.append('propertyName', propertyNameSearch);
    if (locationFilter) searchParams.append('location', locationFilter);
    if (propertyTypeFilter) searchParams.append('type', propertyTypeFilter);
    if (minPriceFilter) searchParams.append('minPrice', minPriceFilter);
    if (maxPriceFilter) searchParams.append('maxPrice', maxPriceFilter);

    // Navigate to the listings page with the constructed search parameters
    navigate(`/tenant/listings?${searchParams.toString()}`);
  };

  return (
    <div className="tenant-landing-page">
      {/* Navigation bar for tenant section */}
      <nav className="navigation-bar">
        <ul>
          <li>
            <Link to="/" className="navbar-logo">
              <img
                src={logoImageUrl}
                alt="Logo"
              />
            </Link>
          </li>
          <li><Link to="/tenant/home">Home</Link></li>
          <li><Link to="/tenant/rentals">Rentals</Link></li>
          <li><Link to="/tenant/interests">Interests</Link></li>
          <li><Link to="/tenant/maintenance">Maintenance Requests</Link></li>
          <li><Link to="/tenant/notifications">Notifications</Link></li>
          <li><Link to="/tenant/profile">Profile</Link></li>
        </ul>
      </nav>

      {/* Search section for finding rental properties */}
      <div className="search-section">
        <h2>Find Your Perfect Rental</h2>
        {/* Search form */}
        <form onSubmit={handleSearchSubmit} className="search-form">
          <div className="search-input-group">
            {/* Input field for searching by property name */}
            <input
              type="text"
              className="search-input"
              placeholder="Search by Property Name..."
              value={propertyNameSearch}
              onChange={handlePropertyNameSearchChange}
            />
            {/* Search button */}
            <button type="submit" className="search-button primary-button">Search</button>
          </div>

          {/* Filters section for refining search results */}
          <div className="filters-section">
            {/* Location filter dropdown */}
            <select name="location" className="filter-dropdown" value={locationFilter} onChange={handleFilterChange}>
              <option value="">Any Location</option>
              <option value="Coimbatore">Coimbatore</option>
              <option value="Bangalore">Bangalore</option>
              <option value="Chennai">Chennai</option>
              <option value="Hyderabad">Hyderabad</option>
            </select>

            {/* Property type filter dropdown */}
            <select name="propertyType" className="filter-dropdown" value={propertyTypeFilter} onChange={handleFilterChange}>
              <option value="">Any Type</option>
              <option value="Residential">Residential</option>
              <option value="Commercial">Commercial</option>
              <option value="Industrial">Industrial</option>
            </select>

            {/* Minimum price filter dropdown */}
            <select name="minPrice" className="filter-dropdown" value={minPriceFilter} onChange={handleFilterChange}>
              <option value="">Min Price</option>
              <option value="1000">₹1,000</option>
              <option value="2000">₹2,000</option>
              <option value="5000">₹5,000</option>
              <option value="10000">₹10,000</option>
            </select>

            {/* Maximum price filter dropdown */}
            <select name="maxPrice" className="filter-dropdown" value={maxPriceFilter} onChange={handleFilterChange}>
              <option value="">Max Price</option>
              <option value="5000">₹5,000</option>
              <option value="10000">₹10,000</option>
              <option value="20000">₹20,000</option>
              <option value="50000">₹50,000</option>
            </select>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TenantLandingPage;