import React, { createContext, useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const getStoredToken = () => localStorage.getItem('token');
    const [token, setToken] = useState(getStoredToken());
    const [userId, setUserId] = useState(null);
    const [userRole, setUserRole] = useState(null);
    const [loadingAuth, setLoadingAuth] = useState(true);

    useEffect(() => {
        const storedToken = getStoredToken();
        if (storedToken) {
            const userInfo = getUserInfoFromToken(storedToken);
            setToken(storedToken);
            setUserId(userInfo.userId);
            setUserRole(userInfo.userRole);
        }
        setLoadingAuth(false);
    }, []);

    const getUserInfoFromToken = (currentToken) => {
        try {
            if (currentToken) {
                const decodedToken = jwtDecode(currentToken);
                return {
                    userId: decodedToken?.userId,
                    userRole: decodedToken?.role,
                };
            }
            return { userId: null, userRole: null };
        } catch (error) {
            console.error("Error decoding token:", error);
            return { userId: null, userRole: null };
        }
    };

    const login = (newToken) => {
        setToken(newToken);
        localStorage.setItem('token', newToken);
        const userInfo = getUserInfoFromToken(newToken);
        setUserId(userInfo.userId);
        setUserRole(userInfo.userRole);
    };

    const logout = () => {
        setToken(null);
        setUserId(null);
        setUserRole(null);
        localStorage.removeItem('token');
    };

    // Add a clearAuth function for explicit logout
    const clearAuth = () => {
        setToken(null);
        setUserId(null);
        setUserRole(null);
        localStorage.removeItem('token');
    };

    return (
        <AuthContext.Provider value={{ token, login, logout, userId, userRole, loadingAuth, clearAuth }}>
            {children}
        </AuthContext.Provider>
    );
};